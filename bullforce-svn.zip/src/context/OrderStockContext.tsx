import React, { createContext, useContext } from "react";
import { OrderStockPayload } from "../types/watchlist.types";

const OrderStockContext = createContext<{
  orderStock: OrderStockPayload | null;
  setOrderStock: React.Dispatch<React.SetStateAction<OrderStockPayload | null>>;
} | null>(null);

export const OrderStockProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [orderStock, setOrderStock] = React.useState<OrderStockPayload | null>(
    null
  );

  return (
    <OrderStockContext.Provider value={{ orderStock, setOrderStock }}>
      {children}
    </OrderStockContext.Provider>
  );
};

export const useOrderStock = () => {
  const context = useContext(OrderStockContext);
  if (!context) {
    throw new Error(
      "useWatchlistContext must be used within a WatchlistProvider"
    );
  }
  return context;
};
