import React, { createContext, useContext, useState, useEffect } from 'react';
import { onBoardingFormDataType, defaultFormData } from '../types/types'; // Your form data type definition
import { useSelector } from "react-redux";
import { RootState } from "../store/store";
import { makeApiRequest } from '../backendapi/apiutils';

// Define the types for form context
interface FormContextProps {
  formData: onBoardingFormDataType | null; // Allow for null if not yet initialized
  updateFormData: (data: Partial<onBoardingFormDataType>) => void;
}

// Create the context with default empty values
const FormContext = createContext<FormContextProps | undefined>(undefined);

// FormProvider to wrap your components and manage form data
export const FormProvider = ({ children }: { children: React.ReactNode }) => {
    const [formData, setFormData] = useState<onBoardingFormDataType>(defaultFormData); // Initialize with default form data
    const token = useSelector((state: RootState) => state.payload?.registerapiPayload?.token); // Fetch token from Redux
  
    // Correctly type the updateFormData function
    const updateFormData = (newData: Partial<onBoardingFormDataType>) => {
        setFormData((prevData) => ({
            ...prevData, // Keep the previous data
            ...newData,  // Update with new data
        }));
    };

    useEffect(() => {
        const getPersonalDetails = async () => {
            if (!token) return; // Ensure token is available before making the request

            try {
                const response = await makeApiRequest<any>("getQuestionsAnswers",{});

                if (response?.success) {
                    // If formData is null, use defaultFormData
                    setFormData((prevData) => ({
                        ...defaultFormData, // Always start with default values
                        ...prevData,        // Then merge with existing data
                        ...response.payload, // Finally merge with API response
                    }));
                } else {
                    console.error('API response failure:', response);
                }
            } catch (error) {
                console.error('Error fetching personal details:', error);
            }
        };

        getPersonalDetails(); // Call the API
    }, [token]); // Fetch data whenever the token changes

    return (
        <FormContext.Provider value={{ formData, updateFormData }}>
            {children}
        </FormContext.Provider>
    );
};

// Custom hook to access form context
export const useForm = () => {
    const context = useContext(FormContext);
    if (!context) {
        throw new Error('useForm must be used within a FormProvider');
    }
    return context;
};
