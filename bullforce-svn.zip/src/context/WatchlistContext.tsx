import { StockData } from "../components/Trading/DialogBox/DialogBox";
import { BrokerageChargePayload, GetCompanyDetails, IndicesPayload, MarginDataPayload, OrderStockPayload, SearchResultPayload, SubscriptionPayload, WatchlistDetail, WatchlistPayload } from "../types/watchlist.types";
import { useWatchlists } from "../hooks/useWatchlists";
import { createContext, useContext } from "react";

// type WatchlistContextProps = {
//     watchlists: WatchlistPayload[];
//     watchlistDetails: WatchlistDetail[];
//     fetchWatchlistDetails: (index: number) => void;
//     fetchCompanyDetails: (stockList: WatchlistDetail) => void
//     fetchMarginRequirement: (stockData: StockData) => void;
//     fetchBrokerageCharge: (stockData: StockData) => void;
//     fetchOrderStock: (stockData: StockData) => void;
//     companyDetails: GetCompanyDetails;
//     marginData: MarginDataPayload;
//     charges: BrokerageChargePayload;
//     orderStock: OrderStockPayload;
//     searchResults: SearchResultPayload[];
//     indicesData: IndicesPayload[];
//     itemsToShow: number;
//     setItemsToShow: (value: number) => void;
//     searchStocks: (query: string) => void;
//     loading: boolean;
//     addStock: (selectedWatchlist: string, stockList: WatchlistDetail) => void;
//     getIndices: () => void;
//     currentSubscription: any[];
//     subscribeToInstruments: (instrumentIds: SubscriptionPayload[]) => void;
//     unsubscribeFromInstruments: (instruments: any) => void;
// }

interface WatchlistProviderProps {
    token: string;
    socketToken?: string;
    children: React.ReactNode;
}

const WatchlistContext = createContext<ReturnType<typeof useWatchlists> | null>(null);

export const WatchlistProvider = ({
    children,
    token,
    socketToken,
}: WatchlistProviderProps) => {
    const watchlistData = useWatchlists(token, socketToken);

    return (
        <WatchlistContext.Provider value={watchlistData}>
            {children}
        </WatchlistContext.Provider>
    )
}

// Custom hook to access the WatchlistContext
export const useWatchlistContext = () => {
    const context = useContext(WatchlistContext);
    if (!context) {
      throw new Error(
        "useWatchlistContext must be used within a WatchlistProvider"
      );
    }
    return context;
  };