import React,{useEffect} from "react";
import axios from "axios";

interface Instrument {
    exchangeSegment: number;
    exchangeInstrumentID: number;
  }
  
  interface SubscriptionRequest {
    instruments: Instrument[];
    xtsMessageCode: number;
  }

  const SubscribeSocket = ()=>{
    // const token ="";

    const subscribeToInstruments= async()=>{
        const requestBody: SubscriptionRequest = {
            instruments: [
              {
                exchangeSegment: 1,
                exchangeInstrumentID: 22
              }
            ],
            xtsMessageCode: 1502
          };
          try {
            const response = await axios.post('https://developers.symphonyfintech.in/apimarketdata/instruments/subscription', requestBody, {
              headers: {
                'Content-Type': 'application/json',
                // 'Authorization': `Bearer ${token}`  
              }
            });
      
            console.log('Subscription successful:', response.data);
          } catch (error) {
            if (axios.isAxiosError(error)) {
              console.error('Axios error:', error.message);
            } else {
              console.error('Unexpected error:', error);
            }
          }
         
    };
    useEffect(() => {
        subscribeToInstruments();
      }, []);

     
  }

  export default SubscribeSocket;

