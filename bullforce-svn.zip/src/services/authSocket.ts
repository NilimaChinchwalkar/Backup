import axios from "axios";
// import { initializeSocket,connectSocket } from "./socket";


interface AuthResponse{
    token: string;
}
export const authenticateAndInitializeSocket = async () => {
    // try {
    //   // Make the API call to get the token
    //   const response = await axios.post<AuthResponse>('http://localhost:5000/api/authenticate', {
    //     username: 'user123',
    //     password: 'password123'
    //   });
  
    //   const { token } = response.data;
  
    //   // Initialize socket with the token
    //   const socket = initializeSocket(token);
  
    //   // Connect socket
    //   connectSocket();
  
    //   // Listen to socket events
    //   socket?.on('connect', () => {
    //     console.log('Socket connected');
    //   });
  
    //   socket?.on('message', (message) => {
    //     console.log('Received message:', message);
    //   });
  
    //   socket?.on('disconnect', () => {
    //     console.log('Socket disconnected');
    //   });
  
    // } catch (error) {
    //   console.error('Error initializing socket:', error);
    // }
  };