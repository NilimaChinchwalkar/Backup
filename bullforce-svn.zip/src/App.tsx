import React from "react";
import "@fontsource/roboto/300.css";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import Register from "./components/OnBoarding/Register";
import OTPForm from "./components/OnBoarding/OTPVerifications";
import Aadharverification from "./components/OnBoarding/AadharVerification"; //
import PersonalDetail from "./components/OnBoarding/PersonalDetail";
import PanCard from "./components/OnBoarding/PanCard";
import CaptureImage from "./components/OnBoarding/CaptureImage";
import Qualification from "./components/OnBoarding/Qualification";
import AnnualIncome from "./components/OnBoarding/AnnualIncome";
import Occupation from "./components/OnBoarding/Occupation";
import TradingInvestment from "./components/OnBoarding/TradingInvestment";
import DISDepository from "./components/OnBoarding/DISDepository";
import { Container, Card } from "@mui/material";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FormProvider } from "./context/FormContext"; // Assuming you have this provider
import BankDetails from "./components/OnBoarding/BankDetails";
import BankLinkedSuccess from "./components/OnBoarding/BankLinkedSuccess";
import LinkBankAccount from "./components/OnBoarding/LinkBankAccount";
import SegmentDetails from "./components/OnBoarding/SegmentDetails";
import Onemoney from "./components/OnBoarding/Onemoney";
import AddNominee from "./components/OnBoarding/AddNominee";
import SignaturePad from "./components/OnBoarding/SignaturePad";
import SignatureCapture from "./components/OnBoarding/SignatureCapture";
import SubscriptionPlan from "./components/OnBoarding/SubscriptionPlan";
import PayAccountOpeningFee from "./components/OnBoarding/PayAccountOpeningFee";
import UpiConfirmDetails from "./components/OnBoarding/UpiConfirmDetails";
import Congratulations from "./components/OnBoarding/Congratulations";
import DigiLockerDoc from "./components/OnBoarding/DigiLockerDoc";
import UploadBankDetails from "./components/OnBoarding/UploadBankDetails";
import CancelCheque from "./components/OnBoarding/CancelCheque";
import UserProfile from "./components/OnBoarding/UserProfile";
import SideWatchlist from "./components/SideWatchlist";
import Login from "./pages/Trading/Login";
import CompanyDetails from "./components/Trading/CompanyDetails";
import WatchlistPage from "./pages/Trading/WatchlistPage";
import ExportExcelSheet from "./components/OnBoarding/ExportExcelSheet";

//import SignatureCapture from './components/OnBoarding/SignatureCapture';

const App: React.FC = () => {
  //const initialFormData = useSelector((state: RootState) => state.payload?.getQuesAnswer) as onBoardingFormDataType;

  return (
    <div className="App">
      <Container sx={{ marginTop: 10 }} maxWidth="sm">
        <Card variant="outlined">
          <BrowserRouter>
            <Routes>
            <Route path="/export-excel" element={<ExportExcelSheet/>} />
              <Route path="/" element={<Register />}></Route>
              <Route path="otp-verifications" element={<OTPForm />} />
              <Route
                path="aadhar-verifications"
                element={<Aadharverification />}
              />
              <Route path="pancard-verifications" element={<PanCard />} />
              <Route path="upload-photo" element={<CaptureImage />} />

              {/* Wrap routes that need FormProvider around these specific steps */}
              <Route
                path="/personal-details"
                element={
                  <FormProvider>
                    <PersonalDetail />
                  </FormProvider>
                }
              />
              <Route
                path="/qualification"
                element={
                  <FormProvider>
                    <Qualification />
                  </FormProvider>
                }
              />
              <Route
                path="/occupation"
                element={
                  <FormProvider>
                    <Occupation />
                  </FormProvider>
                }
              />
              <Route
                path="/annual-income"
                element={
                  <FormProvider>
                    <AnnualIncome />
                  </FormProvider>
                }
              />
              <Route
                path="/trading-investment"
                element={
                  <FormProvider>
                    <TradingInvestment />
                  </FormProvider>
                }
              />
              <Route
                path="/dis-depository"
                element={
                  <FormProvider>
                    <DISDepository />
                  </FormProvider>
                }
              />
              <Route path="link-bank-account" element={<LinkBankAccount />} />
              <Route path="cancel-cheque" element={<CancelCheque />} />
              <Route path="bank-linked" element={<BankLinkedSuccess />} />
              <Route path="get-bank-details" element={<BankDetails />} />
              <Route
                path="upi-confirm-details"
                element={<UpiConfirmDetails />}
              />
              <Route path="segment-details" element={<SegmentDetails />} />
              <Route path="onemoney" element={<Onemoney />} />
              <Route path="digi-locker" element={<DigiLockerDoc />} />
              <Route
                path="upload-bank-details"
                element={<UploadBankDetails />}
              />
              <Route path="add-nominee" element={<AddNominee />} />
              <Route path="signature-pad" element={<SignaturePad />} />
              <Route path="capture-signature" element={<SignatureCapture />} />
              <Route path="subscription-plan" element={<SubscriptionPlan />} />
              <Route path="capture-photo" element={<CaptureImage />} />
              <Route
                path="pay-account-opening-fee"
                element={<PayAccountOpeningFee />}
              />
              <Route path="congratulations" element={<Congratulations />} />
              <Route path="user-profile" element={<UserProfile />} />

              {/* Trading Routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/watchlist" element={<WatchlistPage />} />
              <Route path="/sidewatchlist" element={<SideWatchlist/>} />
              <Route
                path="/company-details"
                element={<CompanyDetails />}
              />
            </Routes>
          </BrowserRouter>
        </Card>
      </Container>
    </div>
  );
};

export default App;
