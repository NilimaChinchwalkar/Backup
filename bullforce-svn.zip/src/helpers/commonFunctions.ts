export function areQuestionsWithAnswersInStoredArray<T extends { questionId: number, answerId: number }>(
    targetArray: T[],
    storedArray: T[]
  ): boolean {
    if (!targetArray || !storedArray) {
        return false;
      }
    return targetArray.every(targetItem =>
      storedArray.some(storedItem =>
        storedItem.questionId === targetItem.questionId
      )
    );
}
