import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { LoginForm, LoginState } from "../types/Login.types";

const savedFormData: LoginForm = JSON.parse(
  localStorage.getItem("loginToken") || "{}"
) || {
  error: null,
};

const initialState: LoginState = {
  loginData: savedFormData,
};

const LoginSlice = createSlice({
  name: "loginFormData",
  initialState,
  reducers: {
    loginResponse: (state, action: PayloadAction<Partial<LoginForm>>) => {
      state.loginData = { ...state.loginData, ...action.payload };
      localStorage.setItem(
        "loginToken",
        JSON.stringify(state.loginData)
      );
    }
  },
});

export const { loginResponse } = LoginSlice.actions;
export default LoginSlice.reducer;
