import { createSlice,PayloadAction } from "@reduxjs/toolkit";

interface PayloadState {
    userId: number;
    stepId: number;
    token: string;
    refreshToken: string;
}
interface SegmentState {
    segmentName: string[]; // Allow multiple segment Names
    segmentId: number[]; // Allow multiple segment IDs
}
 interface RegisterFormData {
    EmailAddress: string;
    MobileNumber: string;
    ReferralCode: string;
    ResidenceStatus: "";
}
interface UpiFormData {
    requestid: string | null;
    shortUrl: string;
    upiLink: string;
}
interface BankConfirmationFormData {
    message: string;
}
interface Step {
    StepID: number
}

interface BankDetailsState {
    userId: number | null;
    bankName: string;
    branchName: string;
    bankAddress: string;
    accountType: string;
    ifsc_Code: string;
    name: string;
    accountNumber: number;
    requestId?: string;
}

interface BankDetailsConfirmData {
    bank_name?: string;
    branch?: string;
    bank_addr?: string;
    acc_type: string;
    ifsc_code: string;
    name?: string;
    acc_no: number;
}
const payloadInitialState: PayloadState = {
    userId: 0,
    stepId: 0,
    token: '',
    refreshToken: '',
};
const segmentInitialState: SegmentState = {
    segmentName: [], // Initialize as an empty array
    segmentId: [], // Initialize as an empty array
};

const registerFormInitialState: RegisterFormData = {
    EmailAddress: "",
    MobileNumber: "",
    ReferralCode: "",
    ResidenceStatus: "", 
};
const upiFormInitialState: UpiFormData = {
    requestid: null,
    shortUrl: '',
    upiLink: '',
};

const bankConfirmFormInitialState: BankConfirmationFormData = {
    message: '',
};
const bankDetailsConfirmInitialState: BankDetailsConfirmData = {
    bank_name: '',
    branch: '',
    bank_addr: '',
    acc_type: '',
    ifsc_code: '',
    name: '',
    acc_no: 0,
};

const stepIntialState: Step = {
    StepID: 0
}
const bankDetailsInitialState: BankDetailsState = {
    userId:  null,
    bankName: '',
    branchName: '',
    bankAddress: '',
    accountType: '',
    ifsc_Code: '',
    name: '',
    accountNumber: 0,
    requestId: '',
};
interface UserState {
    registerFormData: RegisterFormData | null;
    registerapiPayload: PayloadState | null;
    stepIDPayload: Step | 0;
    upiApiPayload: UpiFormData | null;  
    bankConfirmApiPayload: BankConfirmationFormData | null;
    bankDetailsPayload: BankDetailsState | null;
    bankDetailsConfirmPayload: BankDetailsConfirmData | null;    
    segmentDetailsPayload: SegmentState | null;
}
const initialState: UserState = {
    registerFormData: registerFormInitialState,
    registerapiPayload: payloadInitialState, 
    stepIDPayload: stepIntialState,
    upiApiPayload: upiFormInitialState,
    bankConfirmApiPayload: bankConfirmFormInitialState,
    bankDetailsPayload: bankDetailsInitialState,
    bankDetailsConfirmPayload: bankDetailsConfirmInitialState,
    segmentDetailsPayload: segmentInitialState, 
    
};
const payloadSlice = createSlice({
    name:'payload',
    initialState,
    reducers:{
        setPayload:(state,action:PayloadAction<PayloadState>)=>{
            if (state.registerapiPayload) {
                state.registerapiPayload.token = action.payload.token;
                state.registerapiPayload.refreshToken = action.payload.refreshToken;
                state.registerapiPayload.stepId = action.payload.stepId;
                state.registerapiPayload.userId = action.payload.userId;
            } else {
                state.registerapiPayload = action.payload; // Initialize it if it's null
            }
        },
        saveUserData: (state, action: PayloadAction<RegisterFormData>) => {
            state.registerFormData = action.payload; // Set the state with the payload data
          },
        setStepsID: (state, action: PayloadAction<Step>) => {
            state.stepIDPayload = action.payload;
        },
         setUpiPayload:(state,action:PayloadAction<UpiFormData>)=>{
            if (state.upiApiPayload) {
                state.upiApiPayload.requestid = action.payload.requestid;
                state.upiApiPayload.shortUrl = action.payload.shortUrl;
                state.upiApiPayload.upiLink = action.payload.upiLink;
            } else {
                state.upiApiPayload = action.payload; // Initialize it if it's null
            }
        },      
        setBankConfirmPayload:(state,action:PayloadAction<BankConfirmationFormData>)=>{
            if (state.bankConfirmApiPayload) {                
                state.bankConfirmApiPayload.message = action.payload.message;
            } else {
                state.bankConfirmApiPayload = action.payload; 
            }
        },
        clearRequestId(state) {
            if (state.upiApiPayload) {
                state.upiApiPayload.requestid = null;
            }
        },
        setBankDetailsPayload:(state,action:PayloadAction<BankDetailsState>)=>{
            if (state.bankDetailsPayload) {
                state.bankDetailsPayload.bankName = action.payload.bankName;
                state.bankDetailsPayload.branchName = action.payload.branchName;
                state.bankDetailsPayload.bankAddress = action.payload.bankAddress;
                state.bankDetailsPayload.accountType = action.payload.accountType;
                state.bankDetailsPayload.ifsc_Code = action.payload.ifsc_Code;
                state.bankDetailsPayload.name = action.payload.name;
                state.bankDetailsPayload.accountNumber = action.payload.accountNumber;
            } else {
                state.bankDetailsPayload = action.payload; // Initialize it if it's null
            }
        },
        setBankDetailsConfirmPayload: (state, action: PayloadAction<BankDetailsConfirmData>) => {
            state.bankDetailsConfirmPayload = action.payload;
        },
        setSegmentPayload: (state, action: PayloadAction<SegmentState>) => {
                state.segmentDetailsPayload = action.payload; // Pass the payload as a string
        },
        
    },

});

export const {setPayload, saveUserData, setStepsID, setUpiPayload, clearRequestId, setBankConfirmPayload, setBankDetailsPayload, setBankDetailsConfirmPayload, setSegmentPayload} = payloadSlice.actions;
export default payloadSlice.reducer;
