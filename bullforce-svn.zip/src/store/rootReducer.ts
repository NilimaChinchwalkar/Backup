import { combineReducers } from '@reduxjs/toolkit';
import payloadReducer from './payloadSlice';
import loginReducer from './LoginSlice';

const rootReducer = combineReducers({
    payload: payloadReducer,
    login: loginReducer
    // someOther: someOtherReducer,
  });
  
  export default rootReducer;