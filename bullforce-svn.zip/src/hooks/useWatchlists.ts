import React from "react";
import { makeApiRequest } from "../backendapi/ApiService";
import {
  BrokerageChargePayload,
  GetCompanyDetails,
  IndicesPayload,
  MarginDataPayload,
  OrderStockPayload,
  SearchResultPayload,
  SubscriptionPayload,
  SubscriptionResponsePayload,
  WatchlistDetail,
  WatchlistPayload,
} from "../types/watchlist.types";
import { toast } from "react-toastify";
import axios from "axios";
import { StockData } from "../components/Trading/DialogBox/DialogBox";

export const useWatchlists = (
  token: string | null,
  socketToken?: string | null
) => {
  const [watchlists, setWatchlists] = React.useState<WatchlistPayload[]>([]);
  const [watchlistDetails, setWatchlistDetails] = React.useState<
    WatchlistDetail[]
  >([]);
  const [indicesData, setIndicesData] = React.useState<IndicesPayload[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [searchResults, setSearchResults] = React.useState<
    SearchResultPayload[]
  >([]);
  const [itemsToShow, setItemsToShow] = React.useState(5); // Number of items to show initially
  const [messages, setMessages] = React.useState<string[]>([]);
  const [connectionStatus, setConnectionStatus] =
    React.useState<string>("Disconnected");
  const [companyDetails, setCompanyDetails] =
    React.useState<GetCompanyDetails>();
  const [marginData, setMarginData] = React.useState<MarginDataPayload>();
  const [charges, setCharges] = React.useState<BrokerageChargePayload>();
  const [orderStock, setOrderStock] = React.useState<OrderStockPayload | null>(
    null
  );
  const [currentSubscription, setCurrentSubscription] = React.useState<any[]>(
    []
  );
  const [webSocketInitialized, setWebSocketInitialized] = React.useState(false);

  const getUserWatchlist = async () => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const response = await makeApiRequest<WatchlistPayload[]>(
        "/api/v1/Trading/watchlist",
        "GET",
        null,
        headers
      );
      if (response.status) {
        const sortedWatchlists = response.payload.sort((a, b) =>
          a.watchlistName.localeCompare(b.watchlistName)
        );
        const filteredWatchlists = sortedWatchlists.filter(
          (watchlist) =>
            ["BANK_NIFTY", "NIFTY_50", "watchlist1"].includes(
              watchlist.watchlistName
            ) || watchlist.isEditable
        );
        setWatchlists(filteredWatchlists);
      } else {
        toast.error(`Error: ${response.message}`, {
          position: "bottom-center",
          autoClose: 5000, // 5 seconds
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "colored",
        });
      }
    } catch (error) {
      toast.error("Something went wrong while fetching watchlists", {
        position: "bottom-center",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  const searchStocks = async (query: string) => {
    let isMounted = true;
    if (query.length < 3) {
      setSearchResults([]);
      return;
    }
    try {
      setLoading(true);
      const headers = {
        accept: "*/*",
        Authorization: `Bearer ${token}`,
      };
      const response = await makeApiRequest<SearchResultPayload[]>(
        `/api/v1/marketdata/search?name=${query}`,
        "GET",
        null,
        headers
      );
      if (isMounted && response.status) {
        const instruments = response.payload.map(
          ({ exchangeSegmentId, exchangeInstrumentId }) => ({
            exchangeSegmentId,
            exchangeInstrumentId,
          })
        );
        setSearchResults(response.payload);
        console.log(instruments);
        await subscribeToInstruments(instruments);
      }
    } catch (error) {
      console.error("Error fetching stock lists:", error);
    } finally {
      if (isMounted) setLoading(false);
    }
    return () => {
      isMounted = false;
    };
  };

  const getIndices = async () => {
    try {
      const url = "/api/v1/marketdata/indices";
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const response = await makeApiRequest<IndicesPayload[]>(
        url,
        "GET",
        null,
        headers
      );
      if (response.status && response.payload) {
        const instruments = response.payload.map((indices) => ({
          exchangeSegmentId: indices.exchangeSegmentId,
          exchangeInstrumentId: indices.exchangeInstrumentId,
        }));
        setIndicesData(response.payload);
        await subscribeToInstruments(instruments);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const addStock = async (
    selectedWatchlist: string,
    stockList: WatchlistDetail
  ) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const data = {
        exchangeSegment: stockList.exchangeSegmentId,
        exchangeInstrumentId: stockList.exchangeInstrumentId,
      };
      const response = await makeApiRequest<WatchlistDetail[]>(
        `/api/v1/Trading/watchlist/${selectedWatchlist}`,
        "POST",
        data,
        headers
      );
      if (response.status) {
        const updatedIndex = watchlists.findIndex(
          (watchlist) => watchlist.watchlistName === selectedWatchlist
        );
        await fetchWatchlistDetails(updatedIndex);
        return { status: response.status, message: response.message };
      }
    } catch (error) {
      console.error(error);
    }
    return { status: false, message: "Failed to add stock" };
  };

  const fetchWatchlistDetails = async (index: number) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const selectedWatchlist = watchlists[index]?.watchlistName;
      if (!selectedWatchlist) return;
      const response = await makeApiRequest<WatchlistDetail[]>(
        `/api/v1/Trading/watchlist/${selectedWatchlist}`,
        "GET",
        null,
        headers
      );
      if (response.status) {
        if (response.payload.length === 0) {
          toast.info(`No records found for ${selectedWatchlist}`, {
            position: "bottom-center",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            theme: "colored",
          });
        } else {
          const sortedWatchlistData = response.payload.sort((a, b) =>
            a.fullName.localeCompare(b.fullName)
          );
          setWatchlistDetails(sortedWatchlistData);
          await subscribeToInstruments(sortedWatchlistData);
        }
      } else {
        toast.error(`Error: ${response.message}`, {
          position: "bottom-center",
          autoClose: 5000, // 5 seconds
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "colored",
        });
        setWatchlistDetails([]);
      }
    } catch (error) {
      toast.error("Something went wrong while fetching watchlists", {
        position: "bottom-center",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  const fetchCompanyDetails = async (stockList: WatchlistDetail) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const data = {
        exchangeInstrumentID: stockList.exchangeInstrumentId.toString(),
        exchangeSegment: stockList.exchangeSegmentId,
      };
      const response = await makeApiRequest<GetCompanyDetails>(
        "/api/v1/marketdata/GetCompanyDetails",
        "POST",
        data,
        headers
      );
      if (response.status) {
        console.log(response);
        setCompanyDetails(response.payload);
        // console.log(companyDetails)
      }
    } catch (error) {
      console.error(error);
    }
  };

  const fetchMarginRequirement = async (stockData: StockData) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const data = [
        {
          marginType: 1,
          exchangeInstrumentId: stockData.exchangeInstrumentId,
          exchangeSegmentId: stockData.exchangeSegmentId,
          productType: "NRML",
          orderType: stockData.orderType || "MARKET",
          orderSide: "BUY",
          quantity: stockData.quantity || 1,
          price: stockData.price || 0,
          stopPrice: 0,
        },
      ];
      console.log(data);
      const response = await makeApiRequest<MarginDataPayload>(
        "/api/v1/Trading/MarginRequirement",
        "POST",
        data,
        headers
      );
      if (response.status) {
        console.log(response.payload);
        setMarginData(response.payload);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const fetchBrokerageCharge = async (stockData: StockData) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const data = {
        exchangeSegment: stockData.exchangeSegmentId,
        exchangeInstrumentID: stockData.exchangeInstrumentId,
        entityId: "AK35",
        entityType: 1,
        productType: 8,
        orderSide: "BUY",
        orderQty: stockData.quantity,
        orderPrice: stockData.price,
      };
      console.log(data);
      const response = await makeApiRequest<BrokerageChargePayload>(
        "/api/v1/user/CalculateBrokerage",
        "POST",
        data,
        headers
      );
      if (response.status) {
        console.log(response.payload);
        setCharges(response.payload);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const fetchOrderStock = async (stockData: StockData) => {
    try {
      const headers = { accept: "*/*", Authorization: `Bearer ${token}` };
      const data = {
        exchangeInstrumentID: stockData.exchangeInstrumentId,
        exchangeSegment: "NSECM",
        productType: "NRML",
        orderType: stockData.orderType?.toUpperCase(),
        orderSide: "BUY",
        timeInForce: "DAY",
        disclosedQuantity: 0,
        orderQuantity: stockData.quantity,
        limitPrice: stockData.price,
        stopPrice: 0,
        variety: "REGULAR",
      };
      const response = await makeApiRequest<OrderStockPayload>(
        "/api/v1/Trading/Order",
        "POST",
        data,
        headers
      );
      if (response.status) {
        setOrderStock(response.payload);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const subscribeToInstruments = async (
    instrumentIds: SubscriptionPayload[]
  ) => {
    const url = "/api/v1/Trading/Subscription";
    const instruments = instrumentIds.map((detail) => ({
      exchangeSegment: detail.exchangeSegmentId,
      exchangeInstrumentID: detail.exchangeInstrumentId,
    }));
    const subscriptionRequestBody = {
      instruments,
      xtsMessageCode: 1502,
    };
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    try {
      const subscriptionResponse = await makeApiRequest(
        url,
        "POST",
        subscriptionRequestBody,
        headers
      );
      const subscriptionResponsePayload =
        subscriptionResponse.payload as SubscriptionResponsePayload;
      if (
        subscriptionResponsePayload &&
        subscriptionResponsePayload.stocksDetails
      ) {
        const subscribeStockDetails = subscriptionResponsePayload.stocksDetails;
        console.log("Subscription successful", subscribeStockDetails);
        console.log(searchResults);

        // set subscription details and stock information
        setCurrentSubscription(instruments);
        // setStockDetails(subscribeStockDetails);

        const updatedStockData = (prevData: any[]) =>
          prevData.map((item) => {
            const matchingDetail = subscribeStockDetails.find(
              (detail) =>
                detail.exchangeInstrumentID == item.exchangeInstrumentId
            );
            console.log(subscribeStockDetails);
            console.log(item);
            console.log(matchingDetail);
            if (matchingDetail) {
              const { lastTradedPrice, close } = matchingDetail;
              const percentChange = isNaN(
                ((lastTradedPrice - close) * 100) / close
              )
                ? 0
                : (((lastTradedPrice - close) * 100) / close).toFixed(2);
              return {
                ...item,
                LTP: lastTradedPrice ?? item.LTP,
                close: close ?? item.close,
                percentChange: percentChange,
                increaseChange: (lastTradedPrice - close).toFixed(2),
              };
            }
            return item;
          });
        if (subscribeStockDetails && subscribeStockDetails.length > 0) {
          setSearchResults((prevSearchResults) =>
            updatedStockData(prevSearchResults)
          );
          setIndicesData((prevIndices) => updatedStockData(prevIndices));
          setWatchlistDetails((prevDetails) => updatedStockData(prevDetails));
        }
      } else {
        console.error("Subscription failed:", subscriptionResponse.message);
      }
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.error("Axios network error:", error.message);
      } else {
        console.error("Unexpected error:", error);
      }
    }
  };

  const unsubscribeFromInstruments = async (instruments: any) => {
    if (!instruments || instruments.length === 0) return;

    const url = "/api/v1/Trading/Subscription";
    const requestBody = {
      instruments,
      xtsMessageCode: 1502,
    };

    const headers = {
      Authorization: `Bearer ${token}`,
    };
    try {
      await makeApiRequest(url, "PUT", requestBody, headers);
      console.log("Unsubscription successful:", instruments);
    } catch (error) {
      console.error("Failed to unsubscribe:", error);
    }
  };

  const initializeWebSocketWorker = () => {
    if (webSocketInitialized) return;
    const worker = new Worker(
      new URL("../workers/EnterpriseSocketWorker.ts", import.meta.url),
      { type: "module" }
    );

    worker.onmessage = (event) => {
      const { type, message } = event.data;

      switch (type) {
        case "connect":
          setConnectionStatus("Connected");
          setMessages((prevMessages) => [...prevMessages, message]);

          // Subscribe to instrument data
          worker.postMessage({
            action: "subscribe",
            payload: { xtsMessageCode: 1502 },
          });
          break;

        case "joined":
          setMessages((prevMessages) => [
            ...prevMessages,
            `Joined: ${message}`,
          ]);
          break;

        case "data":
          if (message.MessageCode === 1502) {
            const lastTradedPrice =
              message.LastTradedPrice || message.Touchline?.LastTradedPrice;
            const exchangeInstrumentID = message.ExchangeInstrumentID;
            const pClose = message.Close || message.Touchline?.Close;

            if (lastTradedPrice && exchangeInstrumentID && pClose) {
              const percentage = (
                ((lastTradedPrice - pClose) * 100) /
                pClose
              ).toFixed(2);
              const percentChange = isNaN(Number(percentage))
                ? 0
                : Number(percentage);
              const increaseBy = (lastTradedPrice - pClose).toFixed(2);

              setSearchResults((prevSearchResult) =>
                prevSearchResult.map((result) =>
                  result.exchangeInstrumentId == exchangeInstrumentID
                    ? {
                        ...result,
                        LTP: lastTradedPrice,
                        percentChange: percentChange,
                        increaseChange: increaseBy,
                      }
                    : result
                )
              );

              setIndicesData((prevIndicesData) =>
                prevIndicesData.map((data) =>
                  data.exchangeInstrumentId == exchangeInstrumentID
                    ? {
                        ...data,
                        LTP: lastTradedPrice,
                        percentChange: percentChange,
                      }
                    : data
                )
              );

              setWatchlistDetails((prevDetails) =>
                prevDetails.map((detail) =>
                  detail.exchangeInstrumentId == exchangeInstrumentID
                    ? {
                        ...detail,
                        LTP: lastTradedPrice,
                        percentChange: percentChange,
                        increaseChange: increaseBy,
                      }
                    : detail
                )
              );
            }
          }

          setMessages((prevMessages) => [
            ...prevMessages,
            `1502 Data: ${JSON.stringify(message)}`,
          ]);
          break;

        case "disconnect":
          setConnectionStatus("Disconnected");
          setMessages((prevMessages) => [...prevMessages, message]);
          break;

        case "error":
          setMessages((prevMessages) => [...prevMessages, message]);
          break;

        default:
          console.log(`Unknown event type: ${type}`);
      }
    };

    // Connect WebSocket
    worker.postMessage({
      token: socketToken,
      userID: "TEST003", // Replace with actual userID
      action: "connect",
    });
    setWebSocketInitialized(true);

    // Clean up on component unmount
    return () => {
      worker.postMessage({ action: "disconnect" });
      worker.terminate();
    };
  };

  React.useEffect(() => {
    if (!webSocketInitialized && socketToken) {
      initializeWebSocketWorker();
    }
  }, [socketToken, webSocketInitialized]);

  return {
    watchlists,
    watchlistDetails,
    fetchWatchlistDetails,
    fetchCompanyDetails,
    fetchMarginRequirement,
    fetchBrokerageCharge,
    fetchOrderStock,
    getUserWatchlist,
    companyDetails,
    marginData,
    charges,
    orderStock,
    searchResults,
    itemsToShow,
    setItemsToShow,
    searchStocks,
    loading,
    addStock,
    indicesData,
    getIndices,
    currentSubscription,
    subscribeToInstruments,
    unsubscribeFromInstruments,
  };
};
