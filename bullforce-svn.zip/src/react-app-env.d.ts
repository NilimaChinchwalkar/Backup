/// <reference types="react-scripts" />
declare namespace NodeJS {
    interface ProcessEnv {
      REACT_APP_API_PATH: string;
      REACT_APP_REGISTER: string;
      REACT_APP_X_API_KEY: string;
    }
  }
