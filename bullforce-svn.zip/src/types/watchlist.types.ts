export interface WatchlistPayload {
  isDefault: boolean;
  isEditable: boolean;
  watchlistName: string;
}

export interface SubscriptionPayload {
  exchangeInstrumentId: number;
  exchangeSegmentId: number;
}

export interface WatchlistDetail {
  length?: number;
  symbol: string;
  fullName: string;
  exchange: string;
  high: number;
  exchangeInstrumentId: number;
  exchangeSegmentId: number;
  LTP?: number;
  close?: number;
  exchangeSegment?: string;
  percentChange?: number;
  increaseChange?: string;
}

export interface SearchResultPayload {
  fullName: string;
  exchange: string;
  expiryDate: string;
  exchangeInstrumentId: number;
  exchangeSegmentId: number;
  exchangeSegment?: string;
  LTP?: number;
  close?: number;
  percentChange?: number;
  increaseChange?: string;
  high: number;
  symbol: string;
}

export interface BidAsk {
  size: number;
  price: number;
  totalOrders: number;
  buyBackMarketMaker: number;
}

export interface StockDetail {
  exchangeSegment: number;
  exchangeInstrumentID: number;
  lastTradedPrice: number;
  close: number;
  bids: BidAsk[];
  asks: BidAsk[];
  high: number;
  low: number;
  open: number;
  percentChange: number;
  totalTradedQuantity: number;
  lastTradedTime: number;
  totalBuyQuantity: number;
  totalSellQuantity: number;
  lastUpdateTime: number;
}
export interface SubscriptionResponsePayload {
  stocksDetails: StockDetail[]; // Assuming this is an array of stock details
  xtsCode: number;
  quotesList: any[];
}

export interface IndicesPayload {
  LTP: number;
  close: number;
  percentChange: number;
  indiceName: string;
  expiryDate: string;
  symbol: string;
  exchange: string;
  exchangeSegment: string;
  exchangeSegmentId: number;
  exchangeInstrumentId: number;
}

export interface GetCompanyDetails {
  exchangeSegment: number;
  exchangeInstrumentID: number;
  touchline: StockDetail;
  bids: BidAsk[];
  asks: BidAsk[];
}

export interface MarginDataPayload {
  marginRequired: number;
  marginAvailable: number;
  marginShortfall: number;
  errorMessage: string;
}

export interface BrokerageChargePayload {
  brokerage: number;
  clearingCharges: number;
  dpCharges: number;
  exchangeCharges: number;
  exchangeTurnoverCharges: number;
  gst: number;
  sebiCharges: number;
  stampDuty: number;
  sttOrCTT: number;
  total: number;
}

export interface OrderStockPayload {
  appOrderID: number;
  clientID: string;
  isin: string;
  orderType: string;
}
