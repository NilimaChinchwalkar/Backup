export interface LoginForm {
    token: string
    refreshToken: string
    socketToken: string
}

export interface LoginState {
    loginData: LoginForm
}