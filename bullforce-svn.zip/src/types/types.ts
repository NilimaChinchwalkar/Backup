export interface UserData {
    EmailAddress: string;
    MobileNumber: string;
    ReferralCode: string;
    ResidenceStatus: string;
    // Add other fields if necessary
  }
  export interface RegisterapiPayload {
    refreshToken: string
    stepId: number;
    token: string;
  }
  export interface UserState {
    userData: UserData | null;
    registerapiPayload: RegisterapiPayload | null;
  }
  export interface onBoardingFormDataType {
    genderDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    maritalDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    qualificationDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    occupationDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    annualIncomeDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    tradingExperienceDetails: { questionId: number; title: string; subtitle: string; options: { answerId: number; answerName: string; isSelected: boolean }[] };
    disDepositoryDetails: {
      questionId: number;
      title: string;
      subtitle: string;
      grouptId: string; // Add groupId field
      options: {
        answerId: number;
        answerName: string;
        isSelected: boolean;
      }[];
    }[];
    // Add other fields as needed...
  }
  export const defaultFormData: onBoardingFormDataType = {
    genderDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    maritalDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    qualificationDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    occupationDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    annualIncomeDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    tradingExperienceDetails: {
      questionId: 0,
      title: '',
      subtitle: '',
      options: [
        { answerId: 0, answerName: '', isSelected: false }
      ]
    },
    disDepositoryDetails: [
      {
        questionId: 0,
        title: '',
        subtitle: '',
        grouptId: '',
        options: [
          { answerId: 0, answerName: '', isSelected: false }
        ]
      }
    ]
  };
  
