import { createSlice, PayloadAction  } from "@reduxjs/toolkit";
import type { RootState } from '../app/store'
import {UserData, RegisterapiPayload, UserState} from "../types/types"

  // Define the initial state using that type
const initialState: UserState = {
  userData: null, // Initial value is null before the user data is saved
  registerapiPayload: null
};

export const userStateSlice = createSlice({
    name: 'userData',
    initialState,
    reducers: {
      saveUserData: (state, action: PayloadAction<UserData>) => {
        state.userData = action.payload; // Set the state with the payload data
      },
      setUserToken: (state, action: PayloadAction<RegisterapiPayload>) => {
        state.registerapiPayload = action.payload;
       
      },
    },
})
export const { saveUserData, setUserToken } = userStateSlice.actions
// Other code such as selectors can use the imported `RootState` type
export const getUser = (state: RootState) => state.userdetail.userData
export const getUserToken = (state: RootState) => state.userdetail.registerapiPayload

export default userStateSlice.reducer
