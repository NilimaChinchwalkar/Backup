// backend.ts
export const apiConfigurations = {
    Login:{
        url:"/v1/auth/login",
        method:"POST",
        withToken:false,
        xkey:true
    },
    getWatchlist:{
        url:"/v1/Trading/watchlist",
        method:"GET",
        withToken:true,
        xkey:false
    },
    fetchWatchlistData:{
         url:"/v1/Trading/watchlist/params",
         method:"GET",
         withToken:true,
         xkey:false

    },
    digiLockerRequest: {
        url: "/v1/OnBoarding/getkycdocumentrequest",
        method: "POST",
        withToken: true,
        xkey:false
      },
    digiLockerStatus: {
      url: "/v1/OnBoarding/getkycdocumentstatus",
      method: "POST",
      withToken: true,
      xkey:false
    },
    getOnboardingMaster: {
      url: "/v1/OnBoarding/GetOnBoardingMaster",
      method: "POST",
      withToken: false,
      xkey:true
    },
    Register: {
      url: "/v1/OnBoarding/register",
      method: "POST",
      withToken: false,
      xkey:true
    },
    verifyEmailOtp: {
      url: "/v1/OnBoarding/VarifyEmailOTP",
      method: "POST",
      withToken: false,
      xkey:true
    },
    verifyMobOtp: {
      url: "/v1/OnBoarding/VarifyMobileOTP",
      method: "POST",
      withToken: false,
      xkey:true
    },
    generateAadharOtp: {
      url: "/v1/OnBoarding/AadhaarGenerateOtp",
      method: "POST",
      withToken: true,
      xkey:true,
    },
    verifyAadharOtp: {
      url: "/v1/OnBoarding/AadharVerifyOtp",
      method: "POST",
      withToken: true,
      xkey:true
    },
    verifyPan: {
      url: "/v1/OnBoarding/VerifyPan",
      method: "POST",
      withToken: true,
      xkey:true
    },
    submitQuestionAnswer: {
      url: "/v1/OnBoarding/SubmitQuestionAnswer",
      method: "POST",
      withToken: true,
      xkey:true
    },
    upiDetailSubmit: {
      url: "/v1/OnBoarding/upidetailsubmit",
      method: "POST",
      withToken: true,
      xkey:true
    },
    bankDetailSubmit: {
      url: "/v1/OnBoarding/bankdetailsubmit",
      method: "POST",
      withToken: true,
      xkey:true
    },
    upiPaymentConfirmation: {
      url: "/v1/OnBoarding/upipaymentconfirmation",
      method: "POST",
      withToken: true,
      xkey:true
    },
    bankConfirmation: {
      url: "/v1/OnBoarding/bankconfirmation",
      method: "POST",
      withToken: true,
      xkey:true
    },
    selfieSubmit: {
      url: "/v1/OnBoarding/SelfieSubmit",
      method: "POST",
      withToken: true,
      xkey:true
    },
    selfieMatch: {
      url: "/v1/OnBoarding/SelfieMatch",
      method: "POST",
      withToken: true,
      xkey:true
    },
    getkycDocumentStatus: {
      url: "/v1/OnBoarding/getkycdocumentstatus",
      method: "POST",
      withToken: true,
      xkey:true
    },
    getkycDocumentRequest: {
      url: "/v1/OnBoarding/getkycdocumentrequest",
      method: "POST",
      withToken: true,
      xkey:true
    },
    submitSegment: {
      url: "/v1/OnBoarding/SubmitSegment",
      method: "POST",
      withToken: true,
      xkey:true
    },
    addNominee: {
      url: "/v1/OnBoarding/AddNominee",
      method: "POST",
      withToken: true,
      xkey:true
    },
    submitSignature: {
      url: "/v1/OnBoarding/SubmitSignature",
      method: "POST",
      withToken: true,
      xkey:true
    },
    subscriptionPlans: {
      url: "/v1/OnBoarding/SubscriptionPlans",
      method: "POST",
      withToken: true,
      xkey:true
    },
    submitSubscriptionPlans: {
      url: "/v1/OnBoarding/SubmitSubscriptionPlans",
      method: "POST",
      withToken: true,
      xkey:true
    },
    cancelCheckSubmit: {
      url: "/v1/OnBoarding/CancelCheckSubmit",
      method: "POST",
      withToken: true,
      xkey:true
    },
    getSubscriptionStatus: {
      url: "/v1/OnBoarding/GetSubscriptionStatus",
      method: "POST",
      withToken: true,
      xkey:true
    },
    getbankstatementprovider: {
      url: "/v1/OnBoarding/getbankstatementprovider",
      method: "POST",
      withToken: true,
      xkey:true
    },    
    uploadbankstatement: {
      url: "/v1/OnBoarding/uploadbankstatement",
      method: "POST",
      withToken: true,
      xkey:true
    },  
    getbankstatement: {
      url: "/v1/OnBoarding/getbankstatement",
      method: "POST",
      withToken: true,
      xkey:true
    },
    getQuestionsAnswers: {
      url: "/v1/OnBoarding/GetQuestionsAnswers",
      method: "POST",
      withToken: true,
      xkey:true
    }
  };
  