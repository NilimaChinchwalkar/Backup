
import axios, { AxiosRequestConfig } from 'axios';



// Define the type for API response structure
interface ApiResponse<T> {
  success: boolean;
  status: string;
  message: string;
  httpStatusCode: number;
  payload: T;
}

// Generic API request handler
export const makeApiRequest = async <T>(
  url: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  data?: any,
  headers?: Record<string, string>
): Promise<ApiResponse<T>> => {
  const config: AxiosRequestConfig = {
    method,
    url,
    headers,
    data,
  };

  try {
    const response = await axios(config);
    return handleApiResponse<T>(response.data);
  } catch (error: any) {
    return {
      success: false,
      status: 'error',
      message: error.response.data.Message,
      httpStatusCode: error.response?.status || 500,
      payload: null as unknown as T,
    };
  }
};

// Handle the API response
const handleApiResponse = <T>(response: any): ApiResponse<T> => {
  const { success, status, message, httpStatusCode, payload } = response;
  return success && httpStatusCode === 200
    ? { success: true, status, message, httpStatusCode, payload }
    : { success: false, status, message, httpStatusCode, payload: null as unknown as T };
};

