import axios, { AxiosRequestConfig } from 'axios';
import { apiConfigurations } from './backend';


const BASE_URL = process.env.REACT_APP_URL_BULLFORCE || '';
const key = process.env.REACT_APP_XAPI_KEY || '';
interface ApiResponse<T> {
  success: boolean;
  status: string;
  message: string;
  httpStatusCode: number;
  payload: T;
}
const buildUrl = (url: string, params?: Record<string, string>): string => {
    if (!params) return url;
    return url.replace(/\${(.*?)}/g, (_, key) => params[key] || '');
  };

// API request handler
// export const makeApiRequest = async <T>(
//   endpointKey: keyof typeof apiConfigurations,
//   data?: any
// ): Promise<ApiResponse<T>> => {
//   const config = apiConfigurations[endpointKey];

//   const axiosConfig: AxiosRequestConfig = {
//     baseURL: BASE_URL,
//     url: config.url,
//     method: config.method,
//     headers: {
//         ...(config.withToken && { Authorization: `Bearer ${getToken()}` }),
//         ...(config.xkey && { 'x-api-key': key })
//       },
//     data,
//   };
export const makeApiRequest = async <T>(
    endpointKey: keyof typeof apiConfigurations,
    data?: any,
    params?: Record<string, string> 
  ): Promise<ApiResponse<T>> => {
    const config = apiConfigurations[endpointKey];
  
    const axiosConfig: AxiosRequestConfig = {
      baseURL: BASE_URL,
      url: buildUrl(config.url, params), // Pass params to build dynamic URL
      method: config.method,
      headers: {
        ...(config.withToken && { Authorization: `Bearer ${getToken()}` }),
        ...(config.xkey && { 'X-Api-Key': key }),
      },
      data,
    };

  try {
    const response = await axios(axiosConfig);
    return handleApiResponse<T>(response.data);
  } catch (error: any) {
    console.error('API request error:', error.message);
    return {
      success: false,
      status: 'error',
      message: error.message,
      httpStatusCode: error.response?.status || 500,
      payload: null as unknown as T,
    };
  }
};

const handleApiResponse = <T>(response: any): ApiResponse<T> => {
  const { success, status, message, httpStatusCode, payload } = response;
  return success && httpStatusCode === 200
    ? { success: true, status, message, httpStatusCode, payload }
    : { success: false, status, message, httpStatusCode, payload: null as unknown as T };
};

const getToken = () => {
   const token= localStorage.getItem('JWT')?.replace(/"/g, '');
  return token;
};
