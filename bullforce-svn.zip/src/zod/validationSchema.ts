import { z } from 'zod';

export const emailValidation = (EmailAddress: string) => {
  const schema = z.string().email('Invalid email address');
  return schema.safeParse(EmailAddress);
};

export const mobileValidation = (MobileNumber: string) => {
  const phoneValidation = new RegExp(/^[0-9]{10}$/);
  const schema = z
    .string()
    .min(10, 'Phone number must be at least 10 digits')
    .max(15, 'Phone number must be no more than 15 digits')
    .regex(phoneValidation, 'Phone number must contain only digits');
  return schema.safeParse(MobileNumber);
};
export const emailOTPValidation = (emotp: string) => {
  const schema = z.string()
  .length(1, 'Please enter otp')
  .length(2 | 3 | 4, 'OTP must be 4 digits');
  return schema.safeParse(emotp)
}
export const mobileOTPValidation = (motp: string) => {
  const schema = z.string()
  .length(1, 'Please enter otp');
  return schema.safeParse(motp)
}

export const formSchema = z.object({
  EmailAddress: z.string().min(1, { message: "Email is required" }).email({ message: "Invalid email address" }),
  MobileNumber: z.string().min(1, { message: "Mobile number is required" })
  .min(10, { message: 'Phone number must be at least 10 digits' })
  .regex(/^[0-9]{10}$/, { message: "Invalid mobile number, must be 10 digits" }),
});

export type EmailMobileForm = z.infer<typeof formSchema>;
export const otpSchema = z.object({
  emailOtp: z
    .string()
    .length(4, { message: 'Email OTP must be exactly 4 digits' })
    .regex(/^\d+$/, { message: 'Email OTP must contain only numbers' }),
  mobileOtp: z
    .string()
    .length(4, { message: 'Mobile OTP must be exactly 4 digits' })
    .regex(/^\d+$/, { message: 'Mobile OTP must contain only numbers' }),
});

export type OtpFormType = z.infer<typeof otpSchema>;

export const aadhaarOTPSchema = z.object({
  aadharNumber: z.string()
  .min(1, { message: "Aadhar number required" })
  .max(12, { message: "Aadhar number must be exactly 12 digits" }),
  aadharOTP: z.string().length(6, { message: "OTP must be 6 digits" }).optional(),
});

export const getSchema = (isOtpStep: boolean) => {
  if (isOtpStep) {
    return aadhaarOTPSchema.refine((data) => data.aadharOTP !== undefined, {
      message: "OTP is required",
      path: ["aadharOTP"],
    });
  }
  return aadhaarOTPSchema.omit({ aadharOTP: true });
};
export type AadhaarOTPFormData = z.infer<typeof aadhaarOTPSchema>;

export const PanCardSchema = z.object({
  panNumber: z
    .string()
    .regex(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, {
      message: "Invalid PAN number format. It should be 5 uppercase letters, 4 digits, and 1 uppercase letter."
    })
    .length(10, { message: "PAN number must be exactly 10 characters." })
});
export type PanCardFormData = z.infer<typeof PanCardSchema>;

// No need to use `z.infer` on a function, use it on the schema itself


export const otpValidationSchema = z.string().length(4, 'OTP must be exactly 4 digits');

export const validateEmailOtp = (otp: string) => otpValidationSchema.safeParse(otp);

export const validateMobileOtp = (otp: string) => otpValidationSchema.safeParse(otp);
