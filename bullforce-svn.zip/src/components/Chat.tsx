import React,{useEffect} from "react";
// import initializeSocket from "../services/socket";

const Chat = () => {
  useEffect(() => {
    // const socket = initializeSocket();
// console.log('socket connected',socket.connected, socket.io.engine.transport.name);
    // Clean up the socket connection when the component unmounts
    return () => {
      // socket?.disconnect();
    };
  }, []);

  return (
  <div>Socket Component</div>
);
};


export default Chat;