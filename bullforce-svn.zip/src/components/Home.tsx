import {useState,useEffect} from "react";


const Game = ()=>{
    const [wins, setWins] = useState(()=>{
        const storagewins = localStorage.getItem('wins');
        return storagewins ? parseInt(storagewins):0;
    });

    const [losses,setLosses] = useState(()=>{
        const storagelosses = localStorage.getItem('losses');
        return storagelosses ? parseInt(storagelosses):0;
    });

    useEffect(()=>{
        localStorage.setItem('wins',wins.toString())
    },[wins]);

    useEffect(()=>{
        localStorage.setItem('losses',losses.toString())
    },[losses]);

    const handleWin = ()=>{
        setWins((preWins)=>preWins+1);
    };

    const handleLoss = ()=>{
        setLosses((preLosses)=>preLosses+1);
    };

    return (
        <div className="game">
          <p>Wins: {wins} | Losses: {losses}</p>
          
          <button onClick={handleWin}>Increment Win</button>&nbsp;
          <button onClick={handleLoss}>Increment Loss</button>
        </div>
      );
}

export default Game;