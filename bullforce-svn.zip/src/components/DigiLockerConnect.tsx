import React,{useState, useCallback } from "react";
import { Button } from "@mui/material";
import { makeApiRequest } from "../backendapi/apiutils";
import { useNavigate } from "react-router-dom";

interface Payload{
    request_id:string;
    kycDocAuthenticationURL:string;
    kycDocRedirectURL:string;
}
interface digiPayload{
    stepId:number;
    message:string;
}
const DigiLockerConnect:React.FC= () =>{
    const navigate = useNavigate();
    const handleSubmit = useCallback(async () => {
        const postData = {
            KycProviderType: "DIGILOCKER_SETU",
        };

        try {
            const digidata = await makeApiRequest<Payload>("digiLockerRequest", postData);
            if (digidata.success) {
                const res = digidata.payload;
                openPopup(res.kycDocAuthenticationURL, res.kycDocRedirectURL);
                localStorage.setItem('reqID',res.request_id);
            }
        } catch (error) {
            console.error("Error fetching DigiLocker data:", error);
        }
    },[]);
   const digiLockerSuccess = useCallback(async (requestId: string)=>{
  
    const postData = {
        "request_id": requestId,
    };
      try {
        const digiStatus = await makeApiRequest<digiPayload>("digiLockerStatus",postData);
        if(digiStatus.httpStatusCode==200){
            const msg = digiStatus.payload.message;
            alert(msg);
            navigate('/watch');
        }
      } catch (error) {
        
      }
   },[navigate]);
    const openPopup = (authURL: string, redirectURL: string) => {
        const popup = window.open(authURL, 'DigiLockerPopup', 'width=600,height=700');
        
        if (!popup) {
            console.error("Popup blocked or failed to open");
            return;
        }

        const pollForSuccess = setInterval(() => {
            try {
                if (popup.location.href.includes(redirectURL)) {
                    const urlParams = new URLSearchParams(popup.location.search);
                    if (urlParams.get('success') === 'True') {
                        console.log("DigiLocker authentication successful!");
                        popup.close();
                        clearInterval(pollForSuccess);

                        digiLockerSuccess(urlParams.get('id') || '');
                        // Perform any actions after successful redirect
                    }
                }
            } catch (err) {
                console.log("Waiting for redirect...");
            }
        }, 1000);

        setTimeout(() => {
            if (!popup.closed) {
                popup.close();
                clearInterval(pollForSuccess);
                const id= localStorage.getItem('reqID') || '';
                 digiLockerSuccess(id);
            }
        }, 120000);
    };
 return (
    <div>
  <Button fullWidth variant="contained" onClick={handleSubmit}>
         Digi Locker Documents
        </Button>
    </div>
 )

}

export default DigiLockerConnect;