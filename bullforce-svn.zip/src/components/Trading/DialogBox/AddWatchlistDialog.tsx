import React from "react";
import DialogBox, { FormDialogProps } from "./DialogBox";
import { Button, TextField, Typography } from "@mui/material";

const AddWatchlistDialog = ({ open, handleClose, handleSubmit }: FormDialogProps) => {
  const [watchlistName, setWatchlistName] = React.useState("");
  return (
    <DialogBox
      open={open}
      handleClose={handleClose}
      handleSubmit={handleSubmit}
      width="xs"
      title="Create Watchlist"
      content={
        <>
          <Typography color="white">
            Please enter a name for the new watchlist.
          </Typography>
          <TextField
            autoFocus
            margin="dense"
            label="Watchlist name"
            type="text"
            size="small"
            fullWidth
            value={watchlistName}
            onChange={(e) => setWatchlistName(e.target.value)}
            sx={{
              "& .MuiOutlinedInput-root": {
                backgroundColor: "#0c1622",
              },
              "& .MuiInputBase-root": {
                color: "white",
              },
              "& .MuiFormLabel-root": {
                color: "#9ca3af",
                fontSize: 16,
              },
            }}
          />
        </>
      }
      actions={
        <>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={() => {
            handleSubmit?.(watchlistName);
            handleClose();
            setWatchlistName("");
          }} color="primary" variant="contained">
            Create Watchlist
          </Button>
        </>
      }
    />
  );
};

export default AddWatchlistDialog;
