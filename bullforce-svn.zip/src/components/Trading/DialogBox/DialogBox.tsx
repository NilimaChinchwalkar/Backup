import React from "react";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  DialogProps,
} from "@mui/material";
import { Close } from "@mui/icons-material";
import { MarginDataPayload, WatchlistDetail } from "../../../types/watchlist.types";

export interface FormDialogProps {
  open: boolean;
  handleClose: () => void;
  handleSubmit?: (watchlistName?: string,  stockList?: StockData[], stockData?: StockData) => void;
  stockName?: WatchlistDetail[] | null;
  stockList?: WatchlistDetail | null;
  width?: DialogProps["maxWidth"] | "xs";
  title?: React.ReactNode | string;
  content?: React.ReactNode;
  actions?: React.ReactNode;
  children?: React.ReactNode;
}

export interface StockData {
  fullName?: string;
  exchangeInstrumentId?: number;
  exchangeSegmentId?: number;
  exchangeSegment?: string;
  price?: number,
  quantity?: number,
  orderType?: string;
}

const DialogBox = ({
  open,
  handleClose,
  width,
  title,
  content,
  actions,
  children
}: FormDialogProps) => {
  return (
    <Dialog
      fullWidth
      maxWidth={width}
      open={open}
      onClose={handleClose}
      sx={{
        "& .MuiDialog-paper": {
          bgcolor: "#162334",
          color: "white",
        },
      }}
    >
      <DialogTitle>{title}</DialogTitle>
      <IconButton
        aria-label="close"
        onClick={handleClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: "#9f9f9f",
        }}
      >
        <Close />
      </IconButton>
      {children}
      <DialogContent
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "6px",
        }}
      >
        {content}
      </DialogContent>
      <DialogActions
        sx={{
          padding: "8px 24px 20px 24px",
        }}
      >
        {actions}
      </DialogActions>
    </Dialog>
  );
};

export default DialogBox;
