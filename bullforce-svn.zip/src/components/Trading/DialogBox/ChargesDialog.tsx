import DialogBox, { FormDialogProps } from "./DialogBox";
import { Box, Chip, Divider, Typography } from "@mui/material";
import { useWatchlistContext } from "../../../context/WatchlistContext";

const ChargesDialog = ({ open, handleClose, stockList }: FormDialogProps) => {
    const { charges } = useWatchlistContext();
  return (
    <DialogBox
      open={open}
      handleClose={handleClose}
      width="xs"
      title={
        <>
          <Typography variant="body1" fontSize={18} fontWeight={600} textAlign="center">
            Transaction Charges
          </Typography>
          <Box display="flex" alignItems="center" gap={2} marginTop={1}>
            <Typography variant="body1" color="primary" fontWeight={600}>{stockList?.fullName}</Typography>
            <Chip
              label={stockList?.exchange}
              size="small"
              sx={{ color: "#0266ef", border: "1px solid #0266ef" }}
            />
          </Box>
        </>
      }
      children={
        <Divider orientation="horizontal" sx={{ borderWidth: "2px" }} />
      }
      content={
        <>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    Brokerage
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.brokerage.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    Clearing Charges
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.clearingCharges.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    DP Charges
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.dpCharges.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    Exchange Charges
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.exchangeCharges.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                Exchange Turnover Charges
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.exchangeTurnoverCharges.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    GST
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.gst.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    SEBI Charges
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.sebiCharges.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    Stamp Duty
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.stampDuty.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" gutterBottom>
                    STT/CTT
                </Typography>
                <Typography variant="body2" gutterBottom>&#8377; {charges?.sttOrCTT.toFixed(2)}</Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Typography variant="body2" fontWeight={600} gutterBottom>
                    Total Charges
                </Typography>
                <Typography variant="body2" fontWeight={600} gutterBottom>&#8377; {charges?.total.toFixed(2)}</Typography>
            </Box>
        </>
      }
    />
  );
};

export default ChargesDialog;
