import DialogBox, { FormDialogProps } from "./DialogBox";
import { Button } from "@mui/material";

const DeleteStockDialog = ({
  open,
  handleClose,
  handleSubmit,
  stockName,
}: FormDialogProps) => {
  const stock = stockName?.map((stock) => stock?.fullName);

  return (
    <DialogBox
      open={open}
      handleClose={handleClose}
      handleSubmit={handleSubmit}
      title="Delete Stock from Watchlist"
      content={
        <>
          Are you sure you want to delete the stock "{stock?.length! > 2 ? stock?.join(" | ") : stock?.join(" & ")}" ? This action
          cannot be undone.
        </>
      }
      actions={
        <>
          <Button onClick={handleClose}>Cancel</Button>
          <Button
            onClick={() => {
              handleSubmit?.(undefined, { ...stockName! }, undefined);
              handleClose();
            }}
            color="error"
            variant="contained"
          >
            Delete Stock
          </Button>
        </>
      }
    />
  );
};

export default DeleteStockDialog;
