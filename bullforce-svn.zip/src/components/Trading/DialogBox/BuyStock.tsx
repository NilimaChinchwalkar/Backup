import React from "react";
import DialogBox, { FormDialogProps, StockData } from "./DialogBox";
import {
  Box,
  Button,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  IconButton,
  InputAdornment,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";
import {
  Add,
  KeyboardArrowDownRounded,
  KeyboardArrowUpRounded,
  Remove,
} from "@mui/icons-material";
import ChargesDialog from "./ChargesDialog";
import { useWatchlistContext } from "../../../context/WatchlistContext";

const BuyStock = ({
  open,
  handleClose,
  handleSubmit,
  stockList,
}: FormDialogProps) => {
    const { fetchBrokerageCharge, fetchMarginRequirement, marginData } = useWatchlistContext();
  const [quantity, setQuantity] = React.useState<number>(1);
  const [price, setPrice] = React.useState<number>(0);
  const [priceType, setPriceType] = React.useState<"market" | "limit">(
    "market"
  );
  const [advancedSettingOpen, setAdvancedSettingOpen] = React.useState(false);
  const [chargesDialogOpen, setChargesDialogOpen] = React.useState(false);

  React.useEffect(() => {
    if (open && priceType === "limit") {
      setPrice(stockList?.LTP!);
    }
  }, [open]);

  const handleBuyStockClick = async (stockData: StockData) => {
    await fetchMarginRequirement(stockData);
  };

  const handleBrokerageCharge = async (stockData: StockData) => {
    await fetchBrokerageCharge(stockData);
    setChargesDialogOpen(true);
  }

  const handleIncrement = () => {
    setQuantity((prev) => {
      const newQuantity = prev + 1;
      if (priceType === "limit") {
        const newLimitPrice = stockList?.LTP! * newQuantity;
        setPrice(newLimitPrice);
        handleBuyStockClick?.({
          ...stockList,
          quantity: newQuantity,
          price: newLimitPrice,
          orderType: priceType,
        });
      } else {
        handleBuyStockClick?.({ ...stockList, quantity: newQuantity });
      }
      return newQuantity;
    });
  };

  const handleDecrement = () => {
    setQuantity((prev) => {
      const newQuantity = Math.max(prev - 1, 1);
      if (priceType === "limit") {
        const newLimitPrice = stockList?.LTP! * newQuantity;
        setPrice(newLimitPrice);
        handleBuyStockClick?.({
          ...stockList,
          quantity: newQuantity,
          price: newLimitPrice,
          orderType: priceType,
        });
      } else {
        handleBuyStockClick?.({ ...stockList, quantity: newQuantity });
      }
      return newQuantity;
    });
  };

  const handlePriceTypeChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const selectedPriceType = event.target.value as "market" | "limit";
    setPriceType(selectedPriceType);

    if (selectedPriceType === "limit") {
      setPrice(stockList?.LTP || 0);
    } else {
      setPrice(0);
    }
  };

  const handleAdvancedSettingClick = () => {
    setAdvancedSettingOpen(!advancedSettingOpen);
  };
  return (
    <DialogBox
      open={open}
      handleClose={() => {
        handleClose();
        setPriceType("market");
        setPrice(0);
      }}
      handleSubmit={handleSubmit}
      width="sm"
      title={
        <>
          <Typography variant="body1" color="primary" fontWeight={600}>{stockList?.fullName}</Typography>
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
          >
            <Box>
              <Typography
                variant="body2"
                fontWeight={600}
                color={
                  Number(stockList?.increaseChange) >= 0 ? "#10aa14" : "error"
                }
              >
                {stockList?.LTP} {stockList?.increaseChange} (
                {stockList?.percentChange}%)
              </Typography>
              <Button
                variant="outlined"
                size="small"
                sx={{
                  marginTop: "8px",
                  color: "#0266ef",
                  borderRadius: "8px",
                  border: "1px solid #0266ef",
                  fontWeight: "400",
                }}
              >
                {stockList?.exchange}
              </Button>
            </Box>
            <Box textAlign="end">
              <Typography variant="body2" fontSize="13px" fontWeight="400">
                Cash Avl : &#8377; {marginData?.marginAvailable.toFixed(2)}
              </Typography>
              <Typography variant="body2" fontSize="13px" fontWeight="400">
                Margin Req &#8377; {marginData?.marginRequired.toFixed(2)}
              </Typography>
              <Typography
                variant="body2"
                fontSize="13px"
                fontWeight="400"
                onClick={() => handleBrokerageCharge({...stockList!, quantity: quantity, price: price})}
                sx={{ textDecoration: "underline", cursor: "pointer" }}
              >
                + Charges
              </Typography>
            </Box>
            <ChargesDialog open={chargesDialogOpen} handleClose={() => setChargesDialogOpen(false)} stockList={stockList} />
          </Box>
        </>
      }
      children={
        <Divider orientation="horizontal" sx={{ borderWidth: "2px" }} />
      }
      content={
        <>
          <Box display="flex" alignItems="center" gap={2} width="100%">
            <TextField
              type="number"
              label="Quantity"
              variant="standard"
              size="small"
              value={quantity}
              onChange={(e) => {
                const value = Math.max(Number(e.target.value), 1);
                setQuantity(value);
              }}
              slotProps={{
                input: {
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={handleDecrement}
                        sx={{
                          color: "#9ca3af",
                          "&:hover": {
                            bgcolor: "red",
                            color: "white",
                          },
                        }}
                        size="small"
                      >
                        <Remove />
                      </IconButton>
                      <IconButton
                        onClick={handleIncrement}
                        sx={{
                          marginLeft: "8px",
                          color: "#9ca3af",
                          "&:hover": {
                            bgcolor: "#c2a02f",
                            color: "white",
                          },
                        }}
                        size="small"
                      >
                        <Add />
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
              sx={{
                width: "25%",
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "#0c1622",
                },
                "& .MuiInputBase-root": {
                  color: "white",
                },
                "& .MuiFormLabel-root": {
                  color: "#9ca3af",
                  fontSize: 16,
                },
                "& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button":
                  {
                    WebkitAppearance: "none",
                    margin: 0,
                  },
              }}
            />
            <TextField
              type="number"
              label="Price"
              variant="standard"
              size="small"
              value={price}
              onChange={(e) => {
                if (priceType === "limit") {
                  setPrice(Number(e.target.value) || 0);
                } else {
                  setPrice(0);
                }
              }}
              disabled={priceType === "market"}
              sx={{
                width: "25%",
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "#0c1622",
                },
                "& .MuiInputBase-root": {
                  color: priceType === "market" ? "#d5b843" : "white",
                },
                "& .MuiInputBase-Root.Mui-disabled": {
                  color: "#d5b843",
                },
                "& .css-1wd3yy0-MuiInputBase-input-MuiInput-input.Mui-disabled":
                  {
                    WebkitTextFillColor: "currentcolor",
                  },
                "& .MuiFormLabel-root": {
                  color: "#9ca3af",
                  fontSize: 16,
                },
                "& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button":
                  {
                    WebkitAppearance: "none",
                    margin: 0,
                  },
              }}
            />
            <FormControl sx={{ width: "58%" }}>
              <RadioGroup
                value={priceType}
                onChange={handlePriceTypeChange}
                aria-label="price-type"
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  flexWrap: "nowrap",
                }}
              >
                <FormControlLabel
                  value="market"
                  control={<Radio />}
                  label="Market Price"
                  sx={{
                    "& .MuiRadio-root": { color: "white" },
                  }}
                />
                <FormControlLabel
                  value="limit"
                  control={<Radio />}
                  label="Limit Price"
                  sx={{
                    "& .MuiRadio-root": { color: "white" },
                  }}
                />
              </RadioGroup>
            </FormControl>
          </Box>
          <Button
            endIcon={
              advancedSettingOpen ? (
                <KeyboardArrowUpRounded />
              ) : (
                <KeyboardArrowDownRounded />
              )
            }
            size="small"
            onClick={handleAdvancedSettingClick}
            sx={{
              display: "flex",
              justifyContent: "center",
              margin: "8px auto auto",
              width: "20%",
            }}
          >
            Advanced
          </Button>
          {advancedSettingOpen && (
            <Box>
              <TextField
                type="number"
                label="Disclosed Quantity"
                variant="standard"
                size="small"
                value="0"
                disabled
                sx={{
                  width: "35%",
                  "& .MuiOutlinedInput-root": {
                    backgroundColor: "#0c1622",
                  },
                  "& .MuiInputBase-root": {
                    color: "white",
                  },
                  "& .MuiInputBase-Root.Mui-disabled": {
                    color: "white",
                  },
                  "& .css-1wd3yy0-MuiInputBase-input-MuiInput-input.Mui-disabled":
                    {
                      WebkitTextFillColor: "currentcolor",
                    },
                  "& .MuiFormLabel-root": {
                    color: "#9ca3af",
                    fontSize: 16,
                  },
                  "& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button":
                    {
                      WebkitAppearance: "none",
                      margin: 0,
                    },
                }}
              />
              <Box display="flex" alignItems="center" gap={2} marginTop="8px">
                <Typography variant="body2" fontSize="13px">
                  Order Type
                </Typography>
                <Chip
                  label="Regular"
                  size="small"
                  sx={{ color: "#0266ef", border: "1px solid #0266ef" }}
                />
              </Box>
              <Box display="flex" alignItems="center" gap={2} marginTop="8px">
                <Typography variant="body2" fontSize="13px">
                  Validity
                </Typography>
                <Chip
                  label="Day"
                  size="small"
                  sx={{ color: "#0266ef", border: "1px solid #0266ef" }}
                />
              </Box>
            </Box>
          )}
        </>
      }
      actions={
        <>
          <Button
            variant="contained"
            fullWidth
            type="submit"
            size="large"
            onClick={() => {
              handleSubmit?.(undefined, undefined, {
                fullName: stockList?.fullName,
                exchangeInstrumentId: stockList?.exchangeInstrumentId,
                exchangeSegment: stockList?.exchange,
                price: price,
                quantity: quantity,
                orderType: priceType,
              });
              handleClose();
              setPriceType("market");
            }}
            sx={{
              textTransform: "capitalize",
              fontWeight: 600,
              borderRadius: "4px",
              color: "white",
              bgcolor: "#10aa14",
              "&:hover": {
                opacity: 0.75,
              },
            }}
          >
            Buy
          </Button>
        </>
      }
    />
  );
};

export default BuyStock;
