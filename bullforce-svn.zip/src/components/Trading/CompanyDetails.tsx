import { Box, Divider, Typography } from "@mui/material";
import { useLocation } from "react-router-dom";
import { GetCompanyDetails } from "../../types/watchlist.types";

const CompanyDetails = () => {
    const location = useLocation();
    const companyDetails = location.state as GetCompanyDetails
    console.log(companyDetails)
  return (
    <Box
      display={{ md: "flex" }}
      justifyContent="center"
      alignItems="center"
      bgcolor="#011222"
      height="100vh"
    >
      <Box
        bgcolor="#162334"
        padding="24px"
        color="white"
        marginY="48px"
        width="100%"
        height="30%"
        border="1px solid #1d324c"
        borderRadius="24px"
        sx={{ maxWidth: "448px" }}
      >
        <Typography variant="h4">Detail</Typography>
            <Box display="flex" alignItems="center" gap={3} marginTop="16px">
                <Box >
                    <Typography variant="body2">Open</Typography>
                    <Typography fontWeight={600}>{companyDetails?.touchline.open}</Typography>
                </Box>
                <Divider orientation="vertical" flexItem sx={{ borderColor: "white" }} />
                <Box >
                    <Typography variant="body2">High</Typography>
                    <Typography fontWeight={600}>{companyDetails?.touchline.high}</Typography>
                </Box>
                <Divider orientation="vertical" flexItem sx={{ borderColor: "white" }} />
                <Box >
                    <Typography variant="body2">Low</Typography>
                    <Typography fontWeight={600}>{companyDetails?.touchline.low}</Typography>
                </Box>
                <Divider orientation="vertical" flexItem sx={{ borderColor: "white" }} />
                <Box >
                    <Typography variant="body2">Prev Close</Typography>
                    <Typography fontWeight={600}>{companyDetails?.touchline.close}</Typography>
                </Box>    
            </Box>
      </Box>
    </Box>
  );
};

export default CompanyDetails;
