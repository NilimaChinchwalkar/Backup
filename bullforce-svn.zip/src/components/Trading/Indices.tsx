import { Box, Typography } from "@mui/material";
import { IndicesPayload } from "../../types/watchlist.types";
import React from "react";

interface indicesProps {
  indicesData: IndicesPayload[];
}

const Indices: React.FC<indicesProps> = React.memo(({ indicesData }) => {
  // const { subscribeToInstruments, unsubscribeFromInstruments} = useWatchlists(token)
  const today = new Date();
  const convertExpiryDate = (dateString: string) => {
    const date = new Date(dateString);

    // Check if the given date matches today's date
    if (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    ) {
      return "Today";
    }
    return date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
    });
  };

  return (
    <Box
      marginTop="8px"
      display="flex"
      alignItems="center"
      gap="12px"
      overflow="hidden" // Hides scrollbar
      padding="8px"
      sx={{
        overflowX: "auto", // Allows horizontal scroll without scrollbar
        "&::-webkit-scrollbar": { display: "none" }, // Hides scrollbar for WebKit browsers
      }}
    >
      {indicesData.map((data, index) => (
        <Box
          key={index}
          padding="16px"
          width="250px" // Fixed width for equal sizing
          height="100px" // Fixed height for equal sizing
          border="1px solid #1d324c"
          borderRadius="8px"
          flexShrink={0} // Prevents shrinking when scrolling horizontally
          display="flex"
          flexDirection="column"
          justifyContent="space-between"
        >
          <Box display="flex" alignItems="center" marginBottom="8px">
            <Typography variant="body1" noWrap>
              {data.symbol}
            </Typography>
            <Typography
              variant="body2"
              fontSize="10px"
              fontWeight="500"
              color="error"
              padding="2px 8px"
              marginLeft="8px"
              borderRadius="12px"
              bgcolor="#43474d"
              sx={{ whiteSpace: "nowrap" }}
            >
              Expiry {convertExpiryDate(data.expiryDate)}
            </Typography>
          </Box>
          <Typography variant="body2" noWrap>
            {/* -65.60 (-0.27%) 24258.85 */}
            {data.LTP} ({data.percentChange})%
          </Typography>
        </Box>
      ))}
    </Box>
  );
});

export default Indices;
