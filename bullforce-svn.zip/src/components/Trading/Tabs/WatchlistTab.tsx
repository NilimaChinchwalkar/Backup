import { Add } from "@mui/icons-material";
import { Box, Fab, Tab, Tabs } from "@mui/material";
import { WatchlistPayload } from "../../../types/watchlist.types";

interface WatchlistTabProps {
  activeWatchlistIndex: number;
  watchlists: WatchlistPayload[];
  onWatchlistTabChange: (event: React.SyntheticEvent, newIndex: number) => void;
  handleAddModalOpen: () => void;
  handleWatchlistClick: (watchlistName: string) => void;
}

const WatchlistTab: React.FC<WatchlistTabProps> = ({
  activeWatchlistIndex,
  watchlists,
  onWatchlistTabChange,
  handleAddModalOpen,
  handleWatchlistClick,
}) => (
  <Box
    position="relative"
    boxShadow={3}
    padding="0 12px 12px"
    bgcolor="#121e2e"
    borderRadius="8px"
  >
    <Tabs
      value={activeWatchlistIndex}
      onChange={onWatchlistTabChange}
      variant="scrollable"
      scrollButtons={false}
      textColor="primary"
      indicatorColor="primary"
      sx={{ width: "86%" }}
    >
      {watchlists.map((item, index) => (
        <Tab
          key={index}
          label={item.watchlistName}
          onClick={() => handleWatchlistClick(item.watchlistName)}
          sx={{ color: "#9ca3af" }}
        />
      ))}
    </Tabs>
    {/* Create new Watchlist Button */}
    <Fab
      color="primary"
      onClick={handleAddModalOpen}
      sx={{
        position: "absolute",
        bottom: 10,
        right: 10,
        bgcolor: "#121e2e",
        borderRadius: "12%",
        width: 40,
        height: 40,
        "&:hover": {
          bgcolor: "#0c1622",
        },
      }}
    >
      <Add sx={{ color: "white" }} />
    </Fab>
  </Box>
);
export default WatchlistTab;
