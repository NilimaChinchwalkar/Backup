import React from "react";
import { Box } from "@mui/material";

interface TabPanelProps {
  children: React.ReactNode;
  value: number;
  index: number;
}

const TabPanel: React.FC<TabPanelProps> = ({ children, value, index }) => {
  return value === index ? <Box mt="16px">{children}</Box> : null;
};

export default TabPanel;