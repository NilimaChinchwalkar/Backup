import React from "react";
import { FilterAltOutlined, SearchOutlined } from "@mui/icons-material";
import { Box, Fab, Tab, Tabs } from "@mui/material";
import SearchStocks from "../Search/SearchStocks";

interface HeaderProps {
  activeTab: number;
  handleTabChange: (event: React.SyntheticEvent, newValue: number) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (value: boolean) => void;
}

const WatchlistHeader = (props: HeaderProps) => {
  return (
    <>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        marginBottom="20px"
      >
        {/* Parent Tabs (Equity / Fno) */}
        <Tabs
          value={props.activeTab}
          onChange={props.handleTabChange}
          textColor="primary"
          indicatorColor="primary"
          sx={{
            bgcolor: "#0c1622",
            borderRadius: "8px",
            padding: "4px 12px",
            minHeight: "40px",
            "& .MuiTabs-indicator": {
              display: "none",
            },
            "& .MuiTabs-flexContainer": {
              height: "30px",
            },
          }}
        >
          <Tab
            label="Equity"
            sx={{
              color: "#9ca3af",
              minHeight: "0",
              "&.Mui-selected": {
                bgcolor: "#162334",
                borderRadius: "8px",
                minHeight: "0px",
              },
            }}
          />
          <Tab
            label="Fno"
            sx={{
              color: "#9ca3af",
              minHeight: "0",
              "&.Mui-selected": {
                bgcolor: "#162334",
                borderRadius: "8px",
                minHeight: "0px",
              },
            }}
          />
        </Tabs>
        <Box display="flex" alignItems="center" gap={1}>
          <Fab
            sx={{
              border: "1px solid #1d324c",
              borderRadius: "8px",
              color: "#e0e0e0",
              bgcolor: "#121e2e",
              height: "40px",
            }}
          >
            <FilterAltOutlined />
          </Fab>
          <Fab
            onClick={() => props.setIsSearchOpen(!props.isSearchOpen)}
            sx={{
              border: "1px solid #1d324c",
              borderRadius: "8px",
              color: "#e0e0e0",
              bgcolor: "#121e2e",
              height: "40px",
            }}
          >
            <SearchOutlined />
          </Fab>
        </Box>
      </Box>
      {props.isSearchOpen && (
        <Box>
          <SearchStocks
            onStockSelect={() => props.setIsSearchOpen(false)}
          />
        </Box>
      )}
    </>
  );
};

export default WatchlistHeader;
