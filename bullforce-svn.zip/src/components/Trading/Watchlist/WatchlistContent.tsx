import React from "react";
import TabPanel from "../Tabs/TabPanel";
import WatchlistTab from "../Tabs/WatchlistTab";
import AddWatchlistDialog from "../DialogBox/AddWatchlistDialog";
import defaultData from "../../../backendapi/data.json";
import Indices from "../Indices";
import StockList from "../StockList";
import DeleteStockDialog from "../DialogBox/DeleteStockDialog";
import { Tab, Tabs } from "@mui/material";
import { WatchlistDetail } from "../../../types/watchlist.types";
import { useWatchlistContext } from "../../../context/WatchlistContext";

interface ContentProps {
  activeTab: number;
  activeWatchlistIndex: number;
  addModalOpen: boolean;
  deleteModalOpen: boolean;
  handleWatchlistTabChange: (
    event: React.SyntheticEvent,
    newValue: number
  ) => void;
  handleWatchlistClick: (watchlistName: string) => Promise<void>;
  handleAddWatchlist: (watchlistName?: string) => Promise<void>;
  handleDeleteStock: (watchlistName?: string) => Promise<void>;
  handleAddModalOpen: () => void;
  handleDeleteModalOpen: (stock: WatchlistDetail[]) => void;
  handleAddModalClose: () => void;
  handleDeleteModalClose: () => void;
  selectedStock: WatchlistDetail[];
  setIsSearchOpen: (value: boolean) => void;
}

interface WatchlistItem {
  watchlistName: string;
}

const WatchlistContent = (props: ContentProps) => {
  const [fnoWatchlists] = React.useState<WatchlistItem[]>(
    defaultData.fnoWatchlistData
  );
  const { watchlists, indicesData } = useWatchlistContext();
  return (
    <>
      {/* Child Tabs Of Equity */}
      <TabPanel value={props.activeTab} index={0}>
        <WatchlistTab
          activeWatchlistIndex={props.activeWatchlistIndex}
          watchlists={watchlists}
          onWatchlistTabChange={props.handleWatchlistTabChange}
          handleAddModalOpen={props.handleAddModalOpen}
          handleWatchlistClick={props.handleWatchlistClick}
        />
        <AddWatchlistDialog
          open={props.addModalOpen}
          handleClose={props.handleAddModalClose}
          handleSubmit={props.handleAddWatchlist}
        />
        <Indices indicesData={indicesData} />
        {/* Render Watchlist Data for Equity */}
        <StockList
          activeWatchlistIndex={props.activeWatchlistIndex}
          handleDeleteModalOpen={props.handleDeleteModalOpen}
          isSearchOpen={props.setIsSearchOpen}
        />
        <DeleteStockDialog
          open={props.deleteModalOpen}
          handleClose={props.handleDeleteModalClose}
          handleSubmit={props.handleDeleteStock}
          stockName={props.selectedStock}
        />
      </TabPanel>

      {/* Child Tabs of FNO */}
      <TabPanel value={props.activeTab} index={1}>
        <Tabs
          value={props.activeWatchlistIndex}
          onChange={props.handleWatchlistTabChange}
          variant="scrollable"
          scrollButtons={false}
          textColor="primary"
          indicatorColor="primary"
          sx={{ boxShadow: 3, bgcolor: "#121e2e", p: "12px" }}
        >
          {fnoWatchlists.map((item, index) => (
            <Tab
              key={index}
              label={item.watchlistName}
              sx={{ color: "#9ca3af" }}
            />
          ))}
        </Tabs>
      </TabPanel>
    </>
  );
};

export default WatchlistContent;
