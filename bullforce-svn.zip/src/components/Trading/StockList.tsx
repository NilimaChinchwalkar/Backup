import React from "react";
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Divider,
  Snackbar,
  Tooltip,
  Typography,
} from "@mui/material";
import { Delete } from "@mui/icons-material";
import { WatchlistDetail } from "../../types/watchlist.types";
import BuyStock from "./DialogBox/BuyStock";
import { StockData } from "./DialogBox/DialogBox";
import { useWatchlistContext } from "../../context/WatchlistContext";
import { useNavigate } from "react-router-dom";

interface StockListProps {
  activeWatchlistIndex: number;
  isSearchOpen: (value: boolean) => void;
  handleDeleteModalOpen: (stock: WatchlistDetail[]) => void;
}

const StockList: React.FC<StockListProps> = ({
  activeWatchlistIndex,
  isSearchOpen,
  handleDeleteModalOpen,
}) => {
  const {
    watchlistDetails,
    watchlists,
    companyDetails,
    marginData,
    fetchCompanyDetails,
    fetchOrderStock,
    fetchMarginRequirement,
    orderStock,
  } = useWatchlistContext();
  const [selectedStockIds, setSelectedStockIds] = React.useState<string[]>([]);
  const [isCheckboxVisible, setIsCheckboxVisible] = React.useState(false);
  const [deleteMode, setDeleteMode] = React.useState(false);
  const [hoveredStockId, setHoveredStockId] = React.useState<string | null>(
    null
  );
  const [buyStockModalOpen, setBuyStockModalOpen] = React.useState(false);
  const [activeStockForModal, setActiveStockForModal] =
    React.useState<WatchlistDetail | null>(null);

  const [snackbarOpen, setSnackbarOpen] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState("");

  const generateStockId = (stock: WatchlistDetail) =>
    `${stock.fullName}-${stock.exchange}`;

  const navigate = useNavigate();

  const handleCheckboxChange = (data: WatchlistDetail, checked: boolean) => {
    const stockId = generateStockId(data);
    setSelectedStockIds((prevSelected) =>
      checked
        ? [...prevSelected, stockId]
        : prevSelected.filter((id) => id !== stockId)
    );
  };

  const handleSelectAll = () => {
    setSelectedStockIds(watchlistDetails.map(generateStockId));
    if (watchlists[activeWatchlistIndex].isEditable === true)
      setIsCheckboxVisible(true); // Show checkboxes and select all
  };

  const handleDeleteAll = () => {
    if (!deleteMode) {
      // First click: Enter delete mode and select all stocks
      handleSelectAll();
      setDeleteMode(true);
    } else {
      // Second click: Pass only selected stocks to handleDeleteModalOpen
      const stocksToDelete = watchlistDetails.filter((details) =>
        selectedStockIds.includes(generateStockId(details))
      );
      handleDeleteModalOpen(stocksToDelete);
      // Reset state after modal is opened
      setSelectedStockIds([]);
      setIsCheckboxVisible(false);
      setDeleteMode(false);
    }
  };

  const handleStockClick = React.useCallback(
    async (stock: WatchlistDetail) => {
      await fetchCompanyDetails(stock);
    },
    [fetchCompanyDetails]
  );

  const handleBuyStockModalOpen = async (
    event: React.MouseEvent<HTMLButtonElement>,
    stock: WatchlistDetail
  ) => {
    event.stopPropagation();
    setActiveStockForModal(stock);
    await fetchMarginRequirement(stock);
    setBuyStockModalOpen(true);
  };

  const handleBuyStockModalClose = () => {
    setBuyStockModalOpen(false);
    setActiveStockForModal(null);
  };

  const handleSnackbarClose = (
    event?: React.SyntheticEvent | Event,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }
    setSnackbarOpen(false);
  };

  const handleBuyStockSubmit = async (
    watchlistName?: string,
    stockList?: StockData[],
    stockData?: StockData
  ) => {
    await fetchOrderStock(stockData!);
    setBuyStockModalOpen(false);
  };

  React.useEffect(() => {
    if (companyDetails) {
      navigate("/company-details", { state: companyDetails });
    }
  }, [companyDetails]);

  React.useEffect(() => {
    if (orderStock) {
      setSnackbarMessage("Order placed successfully!");
      setSnackbarOpen(true);
    }
  }, [orderStock]);

  return (
    <Box marginTop="16px" overflow="auto" maxHeight="422px">
      {watchlistDetails.length > 0 &&
        watchlists[activeWatchlistIndex]?.isEditable && (
          <Box
            display="flex"
            justifyContent="end"
            alignItems="center"
            gap={2}
            marginBottom={2}
          >
            <Tooltip
              title={
                deleteMode
                  ? "Click to delete selected stocks"
                  : "Select stocks to delete"
              }
              arrow
            >
              <Button
                variant="outlined"
                color="error"
                onClick={handleDeleteAll}
                startIcon={<Delete />}
              >
                {deleteMode ? "Delete Selected" : "Select to Delete"}
              </Button>
            </Tooltip>
          </Box>
        )}
      {watchlistDetails.length > 0
        ? watchlistDetails.map((details) => {
            const stockId = generateStockId(details);
            const isSelected = selectedStockIds.includes(stockId);
            return (
              <Box
                key={stockId}
                bgcolor={isSelected ? "#121e2e" : "#1c2a3a"}
                onMouseEnter={() => setHoveredStockId(stockId)}
                onMouseLeave={() => setHoveredStockId(null)}
                sx={{
                  "&:hover": {
                    bgcolor: `${isSelected ? "#121e2e" : "#1b2c43"}`,
                  },
                }}
              >
                <Box padding="20px">
                  <Box display="flex" justifyContent="space-between">
                    <Box display="flex" gap={2} width="100%">
                      {/* Conditionally render the checkbox based on isCheckboxVisible */}
                      {isCheckboxVisible &&
                        watchlists[activeWatchlistIndex].isEditable && (
                          <Checkbox
                            checked={isSelected}
                            onChange={(e) =>
                              handleCheckboxChange(details, e.target.checked)
                            }
                            sx={{
                              "& .MuiSvgIcon-root": {
                                fill: `${
                                  isSelected ? "currentColor" : "white"
                                }`,
                              },
                            }}
                          />
                        )}
                      <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        width="100%"
                        onClick={() => {
                          watchlists[activeWatchlistIndex]?.isEditable ===
                            false && handleStockClick(details);
                        }}
                      >
                        <Typography variant="body1" fontWeight="500">
                          {details.fullName}
                        </Typography>
                        <Typography
                          variant="body1"
                          fontWeight="500"
                          color={
                            Number(details?.increaseChange) >= 0
                              ? "#10aa14"
                              : "error"
                          }
                        >
                          {details.LTP} | {details.increaseChange} (
                          {details.percentChange}%)
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  <Box
                    display="flex"
                    alignItems={hoveredStockId === stockId ? "center" : "start"}
                    justifyContent="space-between"
                    marginTop="8px"
                  >
                    <Typography
                      marginLeft={
                        watchlists[activeWatchlistIndex]?.isEditable &&
                        isCheckboxVisible
                          ? 7
                          : 0
                      }
                      variant="body2"
                      color="#9ca3af"
                      fontWeight="400"
                    >
                      {details.exchange}
                    </Typography>
                    {hoveredStockId === stockId && (
                      <>
                        <Box display="flex" gap={2}>
                          <Button
                            size="small"
                            variant="contained"
                            color="success"
                            onClick={(e) => handleBuyStockModalOpen(e, details)}
                          >
                            Buy
                          </Button>
                          <Button
                            size="small"
                            variant="contained"
                            color="error"
                          >
                            Sell
                          </Button>
                        </Box>
                      </>
                    )}
                  </Box>
                </Box>
                <Divider orientation="horizontal" />
              </Box>
            );
          })
        : watchlists[activeWatchlistIndex]?.isEditable && (
            <Box
              display="flex"
              paddingY="16px"
              justifyContent="center"
              alignItems="center"
              flexDirection="column"
              gap="16px"
            >
              <Typography variant="body2" color="white" width="50%">
                Watchlist is empty, tap to add stocks to watchlist.
              </Typography>
              <Button
                onClick={() => isSearchOpen(true)}
                sx={{
                  border: "1px solid #d5b843",
                  borderRadius: "8px",
                  fontWeight: "600",
                  width: "140px",
                }}
              >
                Add Stocks
              </Button>
            </Box>
          )}
      <BuyStock
        open={buyStockModalOpen}
        handleClose={handleBuyStockModalClose}
        handleSubmit={handleBuyStockSubmit}
        stockList={
          activeStockForModal
            ? watchlistDetails.find(
                (stock) =>
                  stock.fullName === activeStockForModal.fullName &&
                  stock.exchange === activeStockForModal.exchange
              )
            : null
        }
      />
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity="success"
          sx={{ width: "100%" }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default StockList;
