import React, { useState } from "react";
import {
  Box,
  CircularProgress,
  debounce,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import { Add, Done } from "@mui/icons-material";
import {
  SearchResultPayload,
  WatchlistDetail,
} from "../../../types/watchlist.types";
import { useWatchlistContext } from "../../../context/WatchlistContext";

interface SearchStockProps {
  onStockSelect: (stock: any) => void;
}

const SearchStocks: React.FC<SearchStockProps> = ({
  onStockSelect
}) => {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const {
    watchlists,
    searchResults,
    searchStocks,
    addStock,
    loading,
    itemsToShow,
    setItemsToShow
  } = useWatchlistContext();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedStock, setSelectedStock] = useState<WatchlistDetail | null>(
    null
  );
  const [addedStockSymbols, setAddedStockSymbols] = useState<string>("");

  const debouncedSearch = React.useCallback(
    debounce((query: string) => searchStocks(query), 300),
    [searchStocks]
  );

  React.useEffect(() => {
    if (searchQuery.length >= 3) {
      setItemsToShow(5); // Reset itemsToShow when a new search is initiated
      debouncedSearch(searchQuery);
    }
  }, [searchQuery]);

  // const itemRefs = React.useRef<(HTMLDivElement)[]>([]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (!loading) {
      const bottomReached =
        e.currentTarget.scrollHeight - e.currentTarget.scrollTop <=
        e.currentTarget.clientHeight + 1; //Allow slight margin
      if (bottomReached && itemsToShow <= searchResults.length) {
        const newItemsToShow = itemsToShow + 5;
        setItemsToShow(newItemsToShow);
      }
    }
  };

  const handleOpenMenu = (
    event: React.MouseEvent<HTMLElement>,
    stock: SearchResultPayload
  ) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
    setSelectedStock(stock);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
    setSelectedStock(null);
  };

  const handleAddStockToWatchlist = React.useCallback(
    async (watchlistName: string) => {
      if (selectedStock) {
        const response = await addStock(watchlistName, selectedStock);
        console.log(response);
        if (response?.status) {
          setAddedStockSymbols(selectedStock.symbol); // Efficiently add symbol to Set
          setSearchQuery("");
        }
        handleCloseMenu();
      }
    },
    [selectedStock, addStock]
  );

  const editableWatchlists = watchlists.filter(
    (watchlist) => watchlist.isEditable
  );

  return (
    <Box position="relative">
      <TextField
        label="Search for a company or a Stock"
        variant="outlined"
        fullWidth
        autoFocus
        size="small"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        sx={{
          "& .MuiOutlinedInput-root": {
            backgroundColor: "#0c1622",
          },
          "& .MuiInputBase-root": {
            color: "white",
          },
          "& .MuiFormLabel-root": {
            color: "#9ca3af",
            fontSize: 16,
          },
        }}
      />
      {loading && <CircularProgress />}
      <Box
        onScroll={handleScroll}
        sx={{
          position: "absolute",
          bgcolor: "#121e2e",
          border: "1px solid #1d324c",
          margin: "8px 0",
          zIndex: "1060",
          width: "100%",
          maxHeight: `${searchQuery.length > 2 ? "265px" : "auto"}`,
          overflowY: "auto",
        }}
      >
        {searchResults.slice(0, itemsToShow).map((stock, index) => (
          <React.Fragment key={index}>
            <Box
              onClick={() => onStockSelect(stock)}
              display="flex"
              alignItems="start"
              justifyContent="space-between"
              padding="12px"
              width="100%"
              sx={{
                "&:hover": {
                  bgcolor: "#0c1622",
                },
              }}
            >
              <Box width="70%">
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Typography variant="body1" color="white">
                    {stock.symbol}
                  </Typography>
                  <Typography
                    variant="body2"
                    fontSize="14px"
                    color={
                      Number(stock.increaseChange) >= 0 ? "#10aa14" : "error"
                    }
                  >
                    {stock.LTP} ({stock.percentChange}%)
                  </Typography>
                </Box>
                <Typography variant="body2" color="#9ca3af" fontSize="0.75rem">
                  {stock.fullName}
                </Typography>
              </Box>
              <IconButton
                onClick={(event) => handleOpenMenu(event, stock)}
                sx={{
                  border: "1px solid #1d324c",
                  borderRadius: "8px",
                  padding: "2px",
                  bgcolor: `${
                    addedStockSymbols.includes(stock.symbol)
                      ? "#d5b843"
                      : "#0c1622"
                  }`,
                }}
              >
                {addedStockSymbols.includes(stock.symbol) ? (
                  <Done sx={{ color: "#162334" }} />
                ) : (
                  <Add color="primary" />
                )}
              </IconButton>
            </Box>
            <Divider variant="fullWidth" />
          </React.Fragment>
        ))}
      </Box>

      {/* Menu for selecting a watchlist */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseMenu}
      >
        {editableWatchlists.length > 0 ? (
          editableWatchlists.map((watchlist, index) => (
            <MenuItem
              key={index}
              onClick={() => handleAddStockToWatchlist(watchlist.watchlistName)}
            >
              {watchlist.watchlistName}
            </MenuItem>
          ))
        ) : (
          <MenuItem disabled>No editable watchlists</MenuItem>
        )}
      </Menu>
    </Box>
  );
};

export default SearchStocks;
