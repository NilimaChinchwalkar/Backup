import React, { useState } from "react";
import { Box, Card, Typography, TextField, Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../store/store";

interface PostData {
  AdharNumber: Number;
}
const AdharDetails = () => {
  const [adharNumber, setAdharNumber] = useState("");
  const token = useSelector((state: RootState) => state.payload.registerapiPayload?.token);
  console.log("JWT", token);
  const handleSubmit = async () => {
    if (!adharNumber) {
      alert("Please fill the text box");
    } else {
      const postData: PostData = {
        AdharNumber: Number(adharNumber),
      };
      console.log("Submitting:", postData);
      setAdharNumber("0");
    }
  };
  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      height="100vh"
    >
      <Card elevation={10}>
        <Typography variant="h5" align="center" gutterBottom>
          Enter Adhar Number
        </Typography>
        {/* <p style={{ color: 'blue' }}>Token:{token}</p> */}
        <TextField fullWidth label="Enter your Adhar Number" variant="filled" />

        <Button fullWidth variant="contained" onClick={handleSubmit}>
          Continue
        </Button>
      </Card>
    </Box>
  );
};

export default AdharDetails;
