import React,{useEffect} from "react";
import axios from "axios";
// import initializeSocket from "../services/socket";
// import EnterpriseSocketIO from "../services/EnterpriseSocketIO";


interface Instrument {
    exchangeSegment: number;
    exchangeInstrumentID: number;
  }
  
interface SubscriptionRequest {
    instruments: Instrument[];
    xtsMessageCode: number;
  }
  const SubscribeSocket = () => {
    const validatePinAndSubscribe = async () => {
      try {
        // Step 1: Validate PIN
        const pinValidationResponse = await axios.post(
          "http://103.177.180.205:10151/enterprise/auth/validatepin",
          {
            userID: "TEST003",
            pin: "123456",
            source: "Web",
          },
          {
            headers: {
              "Content-Type": "application/json",
            },
            timeout: 10000,
          }
        );
  
        console.log("PIN validated:", pinValidationResponse.data);
  
        // Step 2: Subscribe to Instruments
        const token = pinValidationResponse.data.result.token; // Assuming the token is in the response
  
        const subscriptionRequestBody: SubscriptionRequest = {
          instruments: [
            {
              exchangeSegment: 1,
              exchangeInstrumentID: 22,
            },
          ],
          xtsMessageCode: 1502,
        };
  
        const subscriptionResponse = await axios.post(
          "http://103.177.180.205:10151/apimarketdata/instruments/subscription",
          subscriptionRequestBody,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: token, // Use the token from PIN validation
            },
            timeout: 10000,
          }
        );
  
        console.log("Subscription successful:", subscriptionResponse.data);
  
        // // After subscription, initialize WebSocket connection
        // const socket = initializeSocket(token);
  
        // // WebSocket event handling for market data
        // socket.on("marketDataEvent", (marketData) => {
        //   console.log("Received market data:", marketData);
        // });
        const userId ='TEST003';
        // const socket = new EnterpriseSocketIO(token,userId);
        // socket.connect();
       
        //   const mockJoinedData = { message: 'Socket joined successfully', id: '12345' };
        //     socket.onJoined(mockJoinedData);
      } catch (error) {
        if (axios.isAxiosError(error)) {
          console.error("Axios network error:", error.message);
          console.error("Axios error details:", error);
        } else {
          console.error("Unexpected error:", error);
        }
      }
    };
  
    useEffect(() => {
      validatePinAndSubscribe();
    }, []);
  
    return (
      <div>
        <h1>Subscribing to Market Data</h1>
      </div>
    );
  };
  

export default SubscribeSocket;