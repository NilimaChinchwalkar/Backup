import React, { useState, useEffect } from 'react'
import { Button, Box, Typography, FormLabel, FormControlLabel, FormGroup, Checkbox} from '@mui/material';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate, useLocation } from 'react-router-dom';
import { makeApiRequest } from '../../backendapi/apiutils';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';


interface Payload {
    planId: number;
    planName: string;
    planCost: number;
    planDescription: null;  
    mandatory: string;
    available: null;
    durationYears: null;
  }

  interface ApiResponse<T> {
    payload: T;
    success: Boolean
  }
  interface PayloadOrder {
    amount: number,
    currency: string,
    orderId: string
}
interface Response {
    success: boolean;
    payload: PayloadOrder;
  }
  
const SubscriptionPlan = () => {

    const navigate = useNavigate()
    const location = useLocation()
    const [loading, setLoading] = useState<boolean>(false)
    const [loader, setLoader] = useState<boolean>(false)
    const [totalCost, setTotalCost] = useState<number>(0);

    const [planList, setPlanList] = useState<Payload[]>([]);
    const [selectedPlans, setSelectedPlans] = useState<number[]>(location.state?.selectedPlans || []);

    useEffect(() => {
        const fetchSubscriptionPlans = async () => {
          setLoading(true);
          const postBody = {}
          try {
            const response: ApiResponse<Payload[]> = await makeApiRequest<Payload[]>("subscriptionPlans",postBody);
            if(response.success) {
                setPlanList(response.payload)
            } else {
                navigate("/")
            }
           
          } catch (error) {
            setLoading(false);
          } finally {
            setLoading(false);
          }
        };
     
        fetchSubscriptionPlans();
    }, [navigate]);

    // Calculate total cost on initial load based on selectedPlans
    useEffect(() => {
        const initialTotal = selectedPlans.reduce((acc, planId) => {
            const plan = planList.find(p => p.planId === planId);
            return plan ? acc + plan.planCost : acc;
        }, 0);
        setTotalCost(initialTotal);
    }, [selectedPlans, planList]);

    // Handle checkbox change
    const handleCheckboxChange = (plan: Payload) => {
      setSelectedPlans((prevSelected) => {
        if (prevSelected.includes(plan.planId)) {
          setTotalCost((prevTotal) => prevTotal - plan.planCost);
          return prevSelected.filter((id) => id !== plan.planId);
        } else {
          setTotalCost((prevTotal) => prevTotal + plan.planCost);
          return [...prevSelected, plan.planId];
        }
      });    
    };

  // Handle form submit
  const handleSubmit = async () => {
    setLoader(true)
    try {
        const body = {
            subscriptionPlans: selectedPlans
        } 
        const response: Response =  await makeApiRequest("submitSubscriptionPlans",body);
        setLoader(false)       

        if(response.success) {            
            const dataToSend = { orderId: response.payload.orderId, amount: response.payload.amount, currency: response.payload.currency, selectedPlans: selectedPlans};
            navigate('/pay-account-opening-fee', { state: dataToSend })
        }        
    } catch (error) {
      console.error('Submission error:', error);
    }
  };
    
  const goBack = () => {
      navigate('/user-profile')
  }
    
  return (
    <Box sx={{ padding: 4 }}>
      <Box sx={{mb:4}}>
          <Button variant='contained' color='primary' onClick={goBack}>
          <KeyboardBackspaceIcon/>
          </Button>
      </Box>
      <Box sx={{mb: 5}}>
          <LinearProgress color='success' value={8} variant='determinate' />
      </Box>
      <Box textAlign='left' sx={{mb: 2}}>
          <Typography variant='h5' sx={{mb:2}} >Subscription Plan</Typography>
          <Typography variant='body2'>Pay using</Typography>
      </Box>     
      
      {planList && planList.length > 0 ? (
        <FormGroup
          aria-label="position"
          row
          sx={{
            padding: '5px',
            marginBottom: '10px',
            alignItems: 'center', 
          }}
        >
          {/* Loop through each item in planList */}
          {planList.map((plan) => (
            <Box
              key={plan.planId}
              sx={{ display: 'flex', alignItems: 'center', gap: '10px', ml: 1, border: '1px solid #010101',  borderRadius: '5px', padding: '5px 20px', marginBottom: '10px'}}
            >
              <FormLabel component="legend" id={`account-label-${plan.planId}`}>
                {plan.planName} {/* Dynamic plan name as the header */}
              </FormLabel>

              <CloudUploadIcon />

              <FormControlLabel
                value={plan.planId}
                control={<Checkbox 
                checked={selectedPlans.includes(plan.planId)}
                onChange={() => handleCheckboxChange(plan)}/>}
                label={`${plan.planCost} ₹`}
                labelPlacement="start"
                aria-labelledby={`account-label-${plan.planId}`} // Unique ID for accessibility
              />
            </Box>
          ))}
        </FormGroup>
      ) : (
        <p>No plans available</p>
      )}

      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
        <Box>
          <Typography variant="body1">Charge: ₹{totalCost}</Typography>
        </Box>

        <Box>
          <Typography variant="body1">Total Cost: ₹{totalCost}</Typography>
        </Box>
      </Box>
      <Button 
        variant='contained' 
        onClick={handleSubmit} 
        disabled={loading || selectedPlans.length === 0} 
        sx={{mt: 2}} 
        fullWidth>
          {loader ? 'Continue...': 'Pay & Continue'}
      </Button>
    </Box>
  )
}

export default SubscriptionPlan