import React, { useState } from 'react'
import { TextField, Button, Typography, Box  } from "@mui/material";
import { zodResolver } from '@hookform/resolvers/zod';
import LinearProgress from '@mui/material/LinearProgress';
import { PanCardFormData, PanCardSchema } from "../../zod/validationSchema"; 
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { makeApiRequest } from '../../backendapi/apiutils';

    const Pancard: React.FC = () => {

    const [isAPIsuccess, setIsAPIsuccess] = useState<boolean>(false)
    const navigate = useNavigate(); 
    const {
        register,
        handleSubmit,
        setError,
        formState: { errors },
      } = useForm<PanCardFormData>({
        resolver: zodResolver(PanCardSchema),
      });


    const onSubmit = async (data: PanCardFormData) => { 
        const postData = {
            pan_number: data.panNumber 
        }
        setIsAPIsuccess(true)
        try {
            const response = await makeApiRequest("verifyPan",postData);
            if(response?.success && response.httpStatusCode === 200) {
                setIsAPIsuccess(false)
                setError("panNumber", {
                    type: "manual",
                    message: response?.message,
                });
                navigate('/personal-details')
            } else {
                setIsAPIsuccess(false)
                setError("panNumber", {
                type: "manual",
                message: response?.message || "API request failed",
                });
            }   
        } catch (error) {
            setError("panNumber", {
                type: "manual",
                message: "Something went wrong, please try again.",
            });
        }
    }

    return (
        <Box sx={{padding: 4}}>
            <form onSubmit={handleSubmit(onSubmit)}>
                <Box>
                    <Box sx={{mb: 5}}>
                        <LinearProgress color='success' value={6} variant='determinate' />
                    </Box>
                    <Box textAlign='left' sx={{mb: 2}}> 
                        <Typography variant= 'h6'>PAN Card Details</Typography>
                    </Box>
                    
                    <Box>
                        <TextField 
                        label="Enter permanent account number" 
                        color="secondary" 
                        fullWidth size="small" 
                        sx={{mb: 1}} 
                        type="text"
                        {...register('panNumber')}
                        error={!!errors.panNumber} 
                        helperText={errors.panNumber?.message}
                        onChange={(e) => e.target.value = e.target.value.toUpperCase()}
                        />
                        <Typography sx={{mb: 5}}  variant='subtitle2'>Your name will be takem as per ITD (Income Tax Department)</Typography>
                        <Button fullWidth type="submit" variant='contained' color='primary' disabled={isAPIsuccess}>{isAPIsuccess ? 'Verifying PAN...' : 'Continue'}</Button>
                    </Box>
                </Box>
            </form>
        </Box>
    )

    }

export default Pancard