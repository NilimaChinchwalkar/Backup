import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Button, Box, Typography } from '@mui/material';
import Cropper from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useDispatch } from "react-redux";
import { setStepsID } from  '../../store/payloadSlice';
import { useNavigate } from 'react-router-dom';

interface MediaDeviceInfoExtended extends MediaDeviceInfo {
  label: string;
}
type Payload = any

interface ApiMessage {
  success: boolean;
  message: string;
}

const WebcamCapture: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const webcamRef = useRef<Webcam>(null);
  const cropperRef = useRef<any>(null); 
  const [image, setImage] = useState<string | null>(null);
  const [croppedImage, setCroppedImage] = useState<string | null>(null);
  const [selfiMatch, setSelfieMatch] = useState<boolean>(false)
  const [isCalledSelfieAPI, setSsCalledSelfie] = useState<boolean>(false)
  const [isCalledSubmitAPI, setisCalledSubmitAPI] = useState<boolean>(false)

  
  const [deviceName, setDeviceName] = useState<string>(''); 
  const [cameraAvailable, setCameraAvailable] = useState<boolean>(true); 
  const [apiMessage, setApiMessage] = useState<ApiMessage>({ success: false, message: '' });
  const [selieMatchError, setSelieMatchError] = useState<string>('');
  
  useEffect(() => {
    navigator.mediaDevices.enumerateDevices().then((deviceInfos) => {
      const videoDevices = deviceInfos.filter(
        (device: MediaDeviceInfo) => device.kind === 'videoinput'
      ) as MediaDeviceInfoExtended[];
      
      if (videoDevices.length === 0) {
        setCameraAvailable(false);  // No camera found
      } else {
        setDeviceName(videoDevices[0].label);  // Set default camera device name
      }
    });
  }, []);

  // Capture the image from the webcam
  const capture = () => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) setImage(imageSrc);
    }
  };

  // Handle file upload from the PC
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (reader.result) setImage(reader.result as string);  
      };
      reader.readAsDataURL(file);
      event.target.value = '';
    }
  };

  // Helper function to remove the Base64 prefix
  const getBase64ImageWithoutPrefix = (base64String: string) => {
    return base64String.replace(/^data:image\/[a-z]+;base64,/, '');
  };
  const cropImage = () => {
    
    if (!image) {
        console.error('No image available to upload');
        return;
      }
      const cropper = cropperRef.current?.cropper; // Access the actual Cropper instance
     
      if (!cropper) {
        console.error("Cropper instance not found");
        return;
      }

      // Get cropped image from Cropper
      setCroppedImage(cropper.getCroppedCanvas().toDataURL('image/png'))
     
  }

  // Handle form submission
  const handleSubmit = async () => {
    try {
      setisCalledSubmitAPI(true)
      const base64Image = croppedImage ? getBase64ImageWithoutPrefix(croppedImage) : null;
      if (!base64Image) return;

      const formData = {
        deviceName: deviceName || 'upload',  // Use device name or fallback
        image: base64Image,
        latitude:"1",
        logitude:"2"
      };
      const result = await makeApiRequest<Payload>("selfieSubmit",formData);
      if (result.success) {
        setisCalledSubmitAPI(false)
        dispatch(setStepsID(result.payload.stepId));
        setApiMessage({
          success: result.success,
          message: 'Photo uploaded successfully'
        });
        setTimeout(() => {
          navigate('/segment-details')
        }, 2000);
      
      } else {
        setisCalledSubmitAPI(false)
        setApiMessage({
          success: result.success,
          message: 'Failed to upload'
        });
      }
    } catch (error) {
      setisCalledSubmitAPI(false)
      console.error('Error uploading image:', error);
    }
  };
  const handleSelfieMatchAPI = async () => {
    try {
      setSsCalledSelfie(true)
      const base64Image = croppedImage ? getBase64ImageWithoutPrefix(croppedImage) : null;
      if (!base64Image) return;

      const formData = {
        deviceName: deviceName || 'upload',  // Use device name or fallback
        image: base64Image,
      };
      const result = await makeApiRequest<Payload>("selfieMatch",formData);
      if (result.success) {
        setSsCalledSelfie(false)
        
        dispatch(setStepsID(result.payload.stepId));
        if(result.payload.aadharRatio > 2 && result.payload.livelinessRatio > 90) {
          setSelfieMatch(true)
        }
        
        setApiMessage({
          success: result.success,
          message: 'Matched'
        });
      } else {
        setSsCalledSelfie(false)
        setSelieMatchError(result.message)
      }
      
    } catch (error) {
      console.error('Error uploading image:', error);
      setSsCalledSelfie(false)
    }
  };
  const refresh = () => {
    setImage(null)
    setCroppedImage(null)
    setApiMessage({ success: false, message: '' })
    setSelieMatchError('')

  }

  return (
    <>
    <Box
     sx={{
       display: 'flex',
       flexWrap: 'wrap',
       justifyContent: 'center',
       gap: 3,
       padding: 2,
     }}
    >
      <Typography variant="h5" align="center" sx={{ marginBottom: 3 }}>
        Capture and Upload Your Photo
      </Typography>
      {/* Webcam or Upload Section */}
      <Box
        sx={{
          flex: '1 1 300px', // Responsive width (min 300px)
          maxWidth: '400px', // Optional max width
          border: '1px solid #ccc',
          borderRadius: '8px',
          padding: 2,
        }}
      >
      {cameraAvailable ? (
        <>
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/png"
            style={{ width: '100%', height: 'auto' }}
          />
          <Button fullWidth variant="contained" color="primary" onClick={capture}>
            Capture Photo
          </Button>
        </>
      ) : (
        <>
          <Typography>No camera detected. Please upload a photo.</Typography>
          <Button variant="contained" component="label">
            Upload Photo
            <input type="file" accept="image/*" hidden onChange={handleFileChange} />
          </Button>
        </>
      )}
      </Box>

      {/* Crop Section */}
      {image && (
        <Box
          sx={{
            flex: '1 1 300px',
            maxWidth: '400px',
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: 2,
          }}
        >
          <Typography variant="h6">Crop Your Image</Typography>
          <Cropper
            src={image}
            style={{ width: '100%', maxHeight: '300px' }}
            aspectRatio={1}
            guides={false}
            ref={cropperRef}
          />
          <Button fullWidth variant="contained" sx={{ mt: 2 }} onClick={cropImage}>
            Crop Image
          </Button>
        </Box>
      )}

      {/* Cropped Image Preview */}
      {croppedImage && (
        <Box
          sx={{
            flex: '1 1 300px',
            maxWidth: '400px',
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: 2,
          }}
        >
          <Typography variant="h6">Cropped Image</Typography>
          <img
            src={croppedImage}
            alt="Cropped"
            style={{
              width: '100%',
              maxHeight: '500px',
              objectFit: 'cover',
              borderRadius: '8px',
            }}
          />
          <Button fullWidth variant="outlined" onClick={refresh}>
            Reset
          </Button>
        </Box>
      )}
    </Box>
    <Box sx={{ marginTop: 4, textAlign: 'center', padding: 2 }}>
      {croppedImage && (
          <>
            {selfiMatch ? (
              <Button
                fullWidth
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                disabled={isCalledSubmitAPI}
              >
                {isCalledSubmitAPI ? 'Saving...' : 'Save Photo'}
              </Button>
            ) : (
              <Button
              fullWidth
                variant="contained"
                color="secondary"
                onClick={handleSelfieMatchAPI}
                disabled={isCalledSelfieAPI}
              >
                {isCalledSelfieAPI ? 'Matching...' : 'Match Selfie'}
              </Button>
            )}
          </>
      )}

      {/* Status Messages */}
      {apiMessage && (
        <Typography
          style={{ color: apiMessage.success ? 'green' : 'red', marginTop: '16px' }}
        >
          {apiMessage.message}
        </Typography>
      )}
      {selieMatchError && (
        <Typography style={{ color: 'red', marginTop: '16px' }}>
          {selieMatchError}
        </Typography>
      )}
    </Box>
  </>
  );
};


export default WebcamCapture;
