import React, { useState } from 'react'
import { Button, Box, Typography, Dialog, DialogActions, DialogContent, DialogContentText, CircularProgress} from '@mui/material';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import LockIcon from '@mui/icons-material/Lock';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useDispatch } from "react-redux";
import { setStepsID } from  '../../store/payloadSlice';


type Payload = any

const DigiLockerDoc = () => {

    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [request_id, setRequest_id] = useState<string | null>('')

    const [isClickDisable, setIsClickDisable] = useState<boolean>(false)
    const [open, setOpen] = useState<boolean>(false)
    const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string>('')

    const fetchDocumentsFromDigiLocker = async () => {
      try {
       
        const formData = {
            request_id : request_id
        }
        const result = await makeApiRequest<Payload>("getkycDocumentStatus",formData);
        if(result) {
            if (result.success) {
              console.log('Success Check')
              setIsClickDisable(false)
                setOpen(true)
                setUploadSuccessMsg(result.payload.message)
                setTimeout(() => {
                    handleCloseSuccessPopup() 
                }, 10000);
            
            } else {
              setOpen(true)
              setUploadSuccessMsg("Documents Not Provided.")
              console.log('failed check')
              console.log(result)
            }
        }
        
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    }
    const goBack = () => {
        navigate('/upload-photo')
    }
    const fnContinue = async () => {
       setIsClickDisable(true)
       try {
        const formData = {
            "KycProviderType" : "DIGILOCKER_SETU"
        }
        const result = await makeApiRequest<Payload>("getkycDocumentRequest",formData);
        if(result) {
          if (result.success && result.payload) {
              setRequest_id(result.payload.request_id)
              const screenWidth = window.screen.width;
              const screenHeight = window.screen.height;

              // Customize the popup window dimensions based on the device
              const width = Math.min(900, screenWidth * 0.9);  // Popup will take 80% of the screen width or max 900px
              const height = Math.min(800, screenHeight * 0.9);  // Popup will take 80% of the screen height or max 800px
              const left = (screenWidth - width) / 2;
              const top = (screenHeight - height) / 2;

              // Open the popup window with custom size
              const popup = window.open(result.payload.kycDocAuthenticationURL,  // Replace with the actual DigiLocker URL
              'DigiLockerPopup',
              `width=${width},height=${height},top=${top},left=${left}`
              );
              const closeTimeout = setTimeout(() => {
                if (popup && !popup.closed) {
                    popup.close();
                    
                    console.log('Popup closed automatically after 30 seconds.');
                    fetchDocumentsFromDigiLocker();
                }
              }, 120000);
            const popupInterval = setInterval(() => {
              if (popup && popup.closed) {
                  clearInterval(popupInterval);
                  clearTimeout(closeTimeout);
                  fetchDocumentsFromDigiLocker();
                  console.log('Popup closed by the user before the timeout.');
              }
          }, 500);

          dispatch(setStepsID(result.payload.stepId));
          } else {
              navigate('/')
          }
        }
        
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    }
    const handleClose = () => {
        setOpen(false)
    }
    const handleCloseSuccessPopup = () => {
        setOpen(false)
        navigate('/segment-details')
    }

  return (
    <>
    <Box sx={{ padding: 4 }}>
        <Box sx={{mb:4}}>
            <Button variant='contained' color='primary' onClick={goBack}>
            <KeyboardBackspaceIcon/>
            </Button>
        </Box>
        <Box sx={{mb: 5}}>
            <LinearProgress color='success' value={8} variant='determinate' />
        </Box>
        <Box textAlign='left' sx={{mb: 2}}>
            <Typography variant='h5' >Digilocker - Documents for KYC</Typography>
            <Typography variant='body2'>Digilocker automatically verifies your documents needed for KYC & account opening on Bullforce</Typography>
        </Box>
        <Box sx={{mb: 5}}>
        <img src='' alt='DigiLocker logo' />
        </Box>
        <Box sx={{mb: 5}}>
        <Typography variant='body2'>I provide my consent to share my Aadhar Number, date of Birth an Name from My Aadhar eKYC information with the income Tax Department, AL State for the purpose of fetching my PAN Verification Record into Dig Locker.</Typography>
        </Box>
        <Box>
            <Typography sx={{pb:1}}>
                <LockIcon fontSize='small' />
                Your data is safe and secured with us
            </Typography>
        <Button variant='contained' fullWidth onClick={fnContinue} sx={{padding:2}}>
          {!isClickDisable ? (
        'Agree & Proceed for KYC'
    ) : (
        <>
            Upload docs within 2 min
            <CircularProgress size={24} sx={{ pr: 2, color:'#fff' }} />
        </>
    )}
          </Button>
        </Box>
        <Box sx={{mt:2}}>
            {open && (
                <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
              >
                <DialogContent>
                  <DialogContentText id="alert-dialog-description">
                    
                    <Typography>{uploadSuccessMsg}</Typography>
                    you will be redirect to next step
                  </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={handleCloseSuccessPopup}>Continue</Button>
                </DialogActions>
              </Dialog>
            )}
        
        </Box>   
    </Box>

    </>
  )
}

export default DigiLockerDoc