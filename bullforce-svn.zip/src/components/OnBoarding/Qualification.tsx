import React, {useState} from "react";
import { Button, Typography, Box, FormControl, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from '../../context/FormContext';
 

const Qualification: React.FC = () => {

    const { formData, updateFormData } = useForm();
    const navigate = useNavigate();
    const [qualificationErr, setQualificationErr] =useState<string>()
    const goBack = () => {
        navigate('/personal-details')
    }
    const fnContinue = () => { 
        if(!formData?.qualificationDetails.options.find((o) => o.isSelected)) {
            setQualificationErr("Please select qualification")
            return
        }
        navigate('/occupation')
    }
    const handleQualificationChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedqualifiaction = event.target.value;
        if (!formData?.qualificationDetails?.options) {
            console.error('Gender details options are not available.');
            return; 
          }
          setQualificationErr("")
        const updatedOptions = formData.qualificationDetails.options.map((option) =>
          option.answerName === selectedqualifiaction ? { ...option, isSelected: true } : { ...option, isSelected: false }
        );
        updateFormData({ qualificationDetails: { ...formData.qualificationDetails, options: updatedOptions } });
      };
    return (
        <Box sx={{padding:4}}>
            <Box sx={{mb:4}}>
                <Button variant='contained' color='primary' onClick={goBack}>
                <KeyboardBackspaceIcon/>
                </Button>
            </Box>
            <Box sx={{mb: 5}}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb: 2}}>
                <Typography variant='h6' >{formData?.qualificationDetails.title}</Typography>
                <Typography variant='subtitle2'>{formData?.qualificationDetails.subtitle}</Typography>
            </Box>
 
            <Box sx={{mb:4}}>
                {formData?.qualificationDetails ? (
                <FormControl>
               
                <RadioGroup
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    value={formData?.qualificationDetails.options.find((o) => o.isSelected)?.answerName} 
                    onChange={handleQualificationChange}
                    name="radio-row-buttons-group"
                >
                   
                    {formData.qualificationDetails.options.map((qualification:any, index:number) => (
                    <FormControlLabel
                    key={qualification.answerId}
                    sx={{
                        border: '1px solid #f0f0f0',
                        borderRadius: 2,
                        padding: '5px 100px',
                        margin: '2px',
                        '&.Mui-checked': {
                            border: '1px solid #1976d2',
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2',
                        },
                        }}
                    value={qualification.answerName}
                    control={<Radio sx={{
                        color: '#1976d2',
                        '&.Mui-checked': {
                            color: '#1976d2',
                        },
                        }}
                        />}
                    label={
                        <span>
                            {qualification.answerName}
                        </span>
                    }
                    labelPlacement="start"
                    />
                    ))}
                   
                    </RadioGroup>
                    {qualificationErr && (
                <Typography color="error">{qualificationErr}</Typography>
                )}
                </FormControl>            
                ) : (
                <p>Loading gender details...</p>
                )}
            </Box>
            <Button variant='contained' fullWidth onClick={fnContinue}>Continue</Button>
 
        </Box>
    )
}
export default Qualification;