import React, { useState, useEffect, useCallback } from "react";
import { TextField, Button, Checkbox, Radio, RadioGroup, FormControlLabel, FormGroup, Box, Typography  } from "@mui/material";
import { setPayload, saveUserData } from '../../store/payloadSlice';
import { useDispatch } from 'react-redux';
import { makeApiRequest } from "../../backendapi/apiutils";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import Drawer from '@mui/material/Drawer';
import { useNavigate } from 'react-router-dom';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { EmailMobileForm, formSchema } from "../../zod/validationSchema"
 
 
interface Payload {
  userId: number;
  stepId: number;
  token: string;
  refreshToken: string;  
  id: number;
  name: string;
  parentId: string;
}
 
interface OnboardingMasterPayload {
  success: boolean;
  payload: Array<{ id: number; name: string; parentId?: string }>;
}
 
 
interface ResidentType {
  id: number;
  name: string;
}
 
const Register: React.FC = () => {
 
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [loading, setLoading] = useState(true);
 
  const dispatch = useDispatch()
  const navigate = useNavigate();
 
  const [ReferralCode, setRefferalCode] =useState<any>('')
  const [IsVerified, setIsVerified] =useState<boolean>(false)
  const [residenceStatus, setResidenceStatus] = useState<any>(1)
 
  // State to hold validation errors
  const [infoModal, setInfoModal] = useState<boolean>(false)
  const [htmlContent, setHtmlContent] = useState<string>('');
  const [infoError, setInfoError] = useState<string>('')
  const [apiErrorMessage, setApiErrorMessage] = useState<string | null>(null);
 
  const [residentTypes, setResidentTypes] = useState<ResidentType[]>([]);

  const getONBoardingMaster = useCallback(async (code: string): Promise<OnboardingMasterPayload | null> => {      
      const postData = {
          "code": code,
      };
      try {
        const response = await makeApiRequest<OnboardingMasterPayload>("getOnboardingMaster",postData);
        return response.payload;
      }
      catch (error) {
          console.error('Error making API request:', error);
          return null;
      }
  },[]);

  useEffect(() => {
    const fetchResidentType = async () => {
      setLoading(true);
      try {
        const response = await getONBoardingMaster('RD');
 
        if (Array.isArray(response)) {
          setResidentTypes(response); 
        } else {
          setInfoError('Unexpected response forma');
        }
      } catch (error) {
        setInfoError('Error fetching resident types');
      } finally {
        setLoading(false);
      }
    };
 
    fetchResidentType();
  }, [getONBoardingMaster]);
 
  const toggleDrawer = async (newOpen: boolean) => {
    setInfoModal(newOpen);
    if(newOpen) {
      const onboardingResponse = await getONBoardingMaster('DI')
     
      if (onboardingResponse) {
 
        if (Array.isArray(onboardingResponse)) {
            onboardingResponse.forEach(payload => {
                setHtmlContent(`${payload.name}`);
            });
        } else {
            console.error("Expected an array in the response payload.");
        }
      } else {
        console.log("No onboarding data found.");
      }
    }
  };
  const {
    register,       
    handleSubmit,  
    formState: { errors },  
  } = useForm<EmailMobileForm>({
    resolver: zodResolver(formSchema), 
  });
 
    const submitRegister = async (data: EmailMobileForm) => {
          const postData = {
            EmailAddress: data.EmailAddress,
            MobileNumber: data.MobileNumber,
            ReferralCode: ReferralCode,
            IsVerified: false,
            ResidenceStatus: residenceStatus,
            AllowDublicateMobile: false,
        };
         dispatch(saveUserData(postData));
          setIsSubmitting(true)
          try {
            const apiResult = await makeApiRequest<Payload>("Register", postData);
            if (apiResult.success && apiResult.payload == null)
            {
              navigate('/otp-verifications'); 
              setApiErrorMessage(apiResult.message)
            }
            else if(apiResult.success &&  apiResult.payload !== null)
            {
                const res = apiResult.payload;
                const jsonString = JSON.stringify(res.token);
                const stringWithoutQuotes = JSON.parse(jsonString);
                console.log(stringWithoutQuotes);
                // const noQuotes = jsonString.replace(/"/g, '');
                // localStorage.setItem('JWT',noQuotes);

              if (res?.token) {
                //const tokenWithoutQuotes = res.token.replace(/"/g, '');
                localStorage.setItem('JWT', stringWithoutQuotes);
              } else {
                  console.error('Token not found in API response');
              }
              
              setApiErrorMessage(apiResult.message)
              dispatch(setPayload(apiResult.payload));
              switch (apiResult.payload.stepId) {
              case 1:
                return navigate('/aadhar-verifications');
              case 2:
                 return navigate('/pancard-verifications');
              case 3:
                 return navigate('/personal-details');
              case 4:
                 return navigate('/link-bank-account');
              case 5:
                 return navigate('/upload-photo');
              case 6:
              return navigate('/digi-locker');
              case 7:
              return navigate('/segment-details');
              case 8:
              return navigate('/upload-bank-details');
              case 9:
              return navigate('/add-nominee');
              case 10:
              return navigate('/digi-locker');
              case 11:
              return navigate('/signature-pad');
              default:
                  return null;
              }
            }
            else {
              setApiErrorMessage(apiResult.message)
              console.error('Failed to submit form:', apiResult.message);
            }
          } catch (error) {
            console.error('Error occurred while submitting the form:', error);
          } finally {
            setIsSubmitting(false)
          }
    }
 
 
    return (
        <div>
          <Typography textAlign='center' sx={{mb:2, backgroundColor: '#f0f0f0', padding: 1}} onClick={() => toggleDrawer(true)}>
            <InfoOutlinedIcon fontSize='small'   sx={{cursor:"pointer"}}/> Account opening steps /Required Documents
          </Typography>
          {infoError && (
            <Typography color='error'>{infoError}</Typography>
          )}
          <Box>
            <Box>
              <Typography variant='h5' textAlign='center'>Signup Now!!</Typography>
            </Box>
            <form onSubmit={handleSubmit(submitRegister)}>
              <Box sx={{padding:4}}>

              <RadioGroup
                row
                name="ResidenceStatus"
                value={residenceStatus || ""}
                onChange={e => setResidenceStatus(e.target.value)}
              >
                {loading ? (
                  <Typography>Loading resident types...</Typography>
                ) : residentTypes.length > 0 ? (
                  residentTypes.map(type => (
                    <FormControlLabel
                      key={type.id}
                      value={type.id.toString()}
                      control={<Radio />}
                      label={type.name}
                    />
                  ))
                ) : (
                  <Typography>No resident types available.</Typography>
                )}
              </RadioGroup>

                  <TextField
                  label="Email"
                  color="secondary"
                  fullWidth size="small"
                  sx={{mb: 3}}
                  type="text"
                  {...register("EmailAddress")}
                  error={!!errors.EmailAddress}
                  helperText={errors.EmailAddress?.message}
                  />

                  <TextField
                  label="Mobile"
                  fullWidth size="small"
                  sx={{mb: 3}}
                  type="tel"
                  error={!!errors.MobileNumber}
                  {...register("MobileNumber")}
                  helperText={errors.MobileNumber?.message}
                  />
                  <TextField
                  label="Refferal Code"
                  name="ReferralCode"
                  value={ReferralCode}
                  onChange={e=>setRefferalCode(e.target.value)}
                  color="secondary"
                  fullWidth size="small"
                  sx={{mb: 3}}
                  type="text" />
                  
                  <FormGroup>
                      <FormControlLabel
                      control={
                      <Checkbox
                      checked={IsVerified}
                      onChange={e=>setIsVerified(e.target.checked)}
                      name="IsVerified"
                      />
                  }
                      label="I authorise to open eKYC account" />
                  </FormGroup>
                {
                  apiErrorMessage && (
                    <Box>
                      <Typography color='error'>{apiErrorMessage}</Typography>
                    </Box>
                  )
                }
                <Button sx={{mt: 2}} color='primary' disabled={isSubmitting} type="submit" variant='contained' fullWidth>{isSubmitting ? '...Continue' : 'Continue'}</Button>
              </Box>
            </form>
          </Box>
          {
            infoModal && (
              <Drawer open={infoModal} onClose={()=>toggleDrawer(false)} anchor='bottom'>
                <div style={{padding:10, backgroundColor: 'black', color: '#fff'}} dangerouslySetInnerHTML={{ __html: htmlContent }} // Directly render the HTML content
                  />
              </Drawer>
            )
          }
        </div>
    )
}
export default Register;