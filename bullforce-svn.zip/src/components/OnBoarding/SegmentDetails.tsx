import React, { useState, useEffect } from 'react';
import { Box, LinearProgress, Typography, Button, FormControl, FormControlLabel, Checkbox } from "@mui/material";
import { setSegmentPayload } from '../../store/payloadSlice';
import { useDispatch } from 'react-redux';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useNavigate, useLocation } from 'react-router-dom';


interface OnboardingMasterPayload {
    success: boolean;
    payload: Array<{ id: number; name: string; parentId?: string }>;
}

interface SegmentType {
    id: number;
    name: string;
  }

const SegmentDetails: React.FC = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const location = useLocation()
    const [loading, setLoading] = useState(true);
    const [segmentTypes, setSegmentTypes] = useState<SegmentType[]>([]);
   const [selectedSegments, setSelectedSegments] = useState<number[]>(location.state?.selectedSegments || []);
    const [error, setError] = useState<string | null>(null);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
    
    // Event handler for checkbox change
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const segmentId = parseInt(event.target.value);
        if (event.target.checked) {
          setSelectedSegments((prev) => [...prev, segmentId]);          
        } else {
          setSelectedSegments((prev) => prev.filter((id) => id !== segmentId));
        }
    };


    
    const handleSubmit = async () => {
 
        const selectedSegmentIds = [...selectedSegments];
        const selectedSegmentNames = segmentTypes
            .filter((segment) => selectedSegments.includes(segment.id))
            .map((segment) => segment.name);
 
 
        if (selectedSegments === undefined || selectedSegments.length === 0) {
            setError('Please select Segment')
            return false;
        }
 
        const postBody = {
            SegmentIds: selectedSegments
        }
        try {
            const response = await makeApiRequest("submitSegment",postBody);
            if(response?.success && response.httpStatusCode === 200) {
                setError("")
                dispatch(setSegmentPayload({ segmentName: selectedSegmentNames, segmentId: selectedSegmentIds }));
                setSuccessMsg(response.message);
 
                setTimeout(() => {
                    if(location?.state?.fromEdit) {
                        navigate('/pay-account-opening-fee',{state: {amount: location?.state?.amount}} )
                    } else {
                        navigate('/upload-bank-details')
                    }
                   
                }, 1000);
            } else {
                console.log("API Error");
                setError(response.message)
            }  
        }
        catch (error) {
            console.error('Error making API request:', error);
        }
    }
    
    useEffect(() => {
    const fetchSegmentType = async () => {
        setLoading(true);
        try {
            const postData = {
                code: 'ST'
              }
              try {
                const response = await makeApiRequest<OnboardingMasterPayload>("getOnboardingMaster",postData);
                const payload = response.payload;
                if (Array.isArray(payload)) {
                    setSegmentTypes(payload);
                } else {
                    console.error('Unexpected response format');
                }
            } catch (error) {
                console.error('Error making API request:', error);
                setError('Failed to fetch segment types.');
                return null;
            }
        } finally {
        setLoading(false);
        }
    };

    fetchSegmentType();
    }, []);

    return (    
        <Box>
        <form>
            <Box sx={{padding:4}}>
                <Box sx={{mb:4}}>
                    <LinearProgress color='success' value={4} variant='determinate' />
                </Box>
                <Box textAlign='left' sx={{mb:2}}>
                    <Typography variant='h6'>Choose Segment</Typography>
                </Box>
                <Box>
                    <FormControl>
                    {loading ? (
                        <Typography>Loading segment types...</Typography>
                    )  : segmentTypes.length > 0 ? (
                        segmentTypes.map((type) => (
                        <FormControlLabel
                            key={type.id}
                            control={
                            <Checkbox
                                value={type.id.toString()}
                                checked={selectedSegments.includes(type.id)}
                                onChange={handleChange}
                                inputProps={{ 'aria-label': `segment-checkbox-${type.id}` }}
                            />
                            }
                            label={type.name}
                        />
                        ))
                    ) : (
                        <Typography>No segment types available.</Typography>
                    )}
                    </FormControl>
                    <Typography color="success">{successMsg}</Typography>
                    <Typography color="error">{error}</Typography>
                    <Button sx={{mt: 2}} color='primary' onClick={handleSubmit} variant='contained' fullWidth
                    disabled={loading}  
                    >Continue</Button>
                </Box>


            </Box>
        </form>
        </Box>
    )
}

export default SegmentDetails;
