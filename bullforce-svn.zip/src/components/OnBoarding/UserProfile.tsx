import React, { useState } from 'react';
import { Avatar, Box, Typography, LinearProgress, Button, FormGroup, FormControlLabel, Checkbox } from '@mui/material';
import { useNavigate } from 'react-router-dom';
 
interface ClientExchangeDetail {
  clientId: string;
  exchangeSegNumber: number;
  enabled: boolean;
  participantCode: string;
  lastUpdatedOn: string;
}
 
interface ClientExchangeDetailsList {
  NSECM: ClientExchangeDetail;
  NSEFO: ClientExchangeDetail;
  BSECM: ClientExchangeDetail;
  BSEFO: ClientExchangeDetail;
}
 
interface Payload {
  clientId: string;
  clientName: string;
  emailId: string;
  mobileNo: string;
  pan: string;
  dematAccountNumber: string;
  includeInAutoSquareoff: boolean;
  includeInAutoSquareoffBlocked: boolean;
  isProClient: boolean;
  isInvestorClient: boolean;
  residentialAddress: string;
  officeAddress: string;
  dateOfBirth: string;
  clientBankInfoList: any[];
  totpSecretKey: string;
  totpQRCode: string;
  clientExchangeDetailsList: ClientExchangeDetailsList;
  isPOAEnabled: boolean;
}
const UserProfile = () => {
    const navigate = useNavigate();
    const [IsVerified, setIsVerified] =useState<boolean>(false)
    const [planList] = useState<Payload>({
      clientId: "TEST003",
      clientName: "Abhay Korat",
      emailId: "abhay.korat@finoux.com",
      mobileNo: "9998529350",
      pan: "COHPK6447Q",
      dematAccountNumber: "",
      includeInAutoSquareoff: true,
      includeInAutoSquareoffBlocked: false,
      isProClient: false,
      isInvestorClient: true,
      residentialAddress: "",
      officeAddress: "",
      dateOfBirth: "1989-08-24T00:00:00",
      clientBankInfoList: [],
      totpSecretKey: "",
      totpQRCode: "",
      clientExchangeDetailsList: {
        NSECM: {
          clientId: "TEST003",
          exchangeSegNumber: 1,
          enabled: true,
          participantCode: "",
          lastUpdatedOn: "0001-01-01T00:00:00",
        },
        NSEFO: {
          clientId: "TEST003",
          exchangeSegNumber: 2,
          enabled: true,
          participantCode: "",
          lastUpdatedOn: "0001-01-01T00:00:00",
        },
        BSECM: {
          clientId: "TEST003",
          exchangeSegNumber: 11,
          enabled: true,
          participantCode: "",
          lastUpdatedOn: "0001-01-01T00:00:00",
        },
        BSEFO: { 
          clientId: "TEST003",
          exchangeSegNumber: 12,
          enabled: true,
          participantCode: "",
          lastUpdatedOn: "0001-01-01T00:00:00",
        },
      },
      isPOAEnabled: true,
    });

    const displayValue = (value: any) => (value ? value : "-");
 
    if (!planList) return <Typography>No user data available.</Typography>;
 
    return (
        <Box sx={{ p: 3 }}>
            <Box sx={{ mb: 5 }}>
            <LinearProgress color='success' value={8} variant='determinate' />
            </Box>

            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                <Avatar alt="Profile Picture" src="" sx={{ width: 100, height: 100 }} />
            </Box>

            <Box sx={{ display: 'grid',  gridTemplateColumns: 'repeat(2, 1fr)',  gap: 1 }}>
                <Box>
                <Typography variant="body2">Client Name:</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.clientName)}</Typography>
                </Box>
                <Box>
                <Typography variant="body2">Client Id:</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.clientId)}</Typography>
                </Box>
                <Box> 
                    <Typography variant="body2">Email ID:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.emailId)}</Typography>
                </Box>
                <Box> 
                    <Typography variant="body2">Phone No:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.mobileNo)}</Typography>
                </Box>
                <Box> 
                    <Typography variant="body2">PAN Number:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.pan)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Demat Account Number:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.dematAccountNumber)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Include in Auto Squareoff:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{planList.includeInAutoSquareoff ? "Yes" : "No"}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Include in Auto Squareoff Blocked:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}> {planList.includeInAutoSquareoffBlocked ? "Yes" : "No"}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Is Pro Client:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{planList.isProClient ? "Yes" : "No"}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Is Investor Client:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{planList.isInvestorClient ? "Yes" : "No"}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Residential Address:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.residentialAddress)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Office Address:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.officeAddress)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">Date of Birth:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                        {new Date(planList.dateOfBirth).toLocaleDateString()}
                    </Typography>
                </Box>
                <Box>
                    <Typography variant="body2">TOTP Secret Key:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.totpSecretKey)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">TOTP QR Code:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{displayValue(planList.totpQRCode)}</Typography>
                </Box>
                <Box>
                    <Typography variant="body2">POA Enabled:</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{planList.isPOAEnabled ? "Yes" : "No"}</Typography>
                </Box>
            </Box>

            <FormGroup>
                          <FormControlLabel
                          control={
                          <Checkbox
                          checked={IsVerified}
                          onChange={e=>setIsVerified(e.target.checked)}
                          name="IsVerified"
                          />
                      }
                          label="I agree with Pricing & Terms and Condition" />
                      </FormGroup>
            <Button
                        fullWidth
                        variant="contained"
                        color="primary"
                        size="large"
                        onClick={() => navigate('/subscription-plan')}
                    >
                        Confirm
                    </Button>
        </Box>
    );
};
 
export default UserProfile;