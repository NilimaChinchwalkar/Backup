import React from 'react'
import {Box, Typography } from '@mui/material';


const Congratulations = () => {
  return (
    <Box sx={{p:5, textAlign: 'center'}}>
       <Typography variant='h6'>Congratulations !</Typography> 
       <Typography variant='body2'>Your account opening is under process.</Typography>
       <Typography variant='body2'>You will be able to invest shortly</Typography>
    </Box>
  )
}

export default Congratulations