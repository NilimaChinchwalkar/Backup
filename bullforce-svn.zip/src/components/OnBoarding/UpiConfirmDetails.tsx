import {
    Box,
    LinearProgress,
    Typography,
    Button,
    Radio,
    Card
} from "@mui/material";
import ImageIcon from "@mui/icons-material/Image";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../../store/store";
import { makeApiRequest } from "../../backendapi/apiutils";
import { clearRequestId, setBankDetailsPayload } from "../../store/payloadSlice";

interface PostData {
    requestId: string;
}

interface ApiResponse {
    userId: number|null;
    bankName: string;
    branchName: string;
    bankAddress: string;
    accountType: string;
    ifsc_Code: string;
    name: string;
    accountNumber: number;
    requestId?: string;
}

const UpiConfirmDetails: React.FC = () => {
    const [selectedBank, setSelectedBank] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const token = useSelector((state: RootState) => state.payload?.registerapiPayload?.token);
    const requestId = useSelector((state: RootState) => state.payload?.upiApiPayload?.requestid) ?? '';
    const bankName = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.bankName) ?? '';
    const branchName = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.branchName) ?? '';
    const accountType = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.accountType) ?? '';
    const ifsc_Code = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.ifsc_Code) ?? '';
    const name = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.name) ?? '';
    const accountNumber = useSelector((state: RootState) => state.payload?.bankDetailsPayload?.accountNumber) ?? '';
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedBank(event.target.value);
    };

    useEffect(() => {
        const fetchBankDetails = async () => {
            setLoading(true);
            setError("");
            const postData: PostData = { requestId };
            try {
                const result = await makeApiRequest<ApiResponse>("upiPaymentConfirmation",postData);
                if (result.success) {
                    dispatch(setBankDetailsPayload(result.payload));
                } else {
                    dispatch(clearRequestId());
                    setError(result.message || "Failed to fetch bank details");
                }
            } catch (error) {
                console.error("Error fetching bank details:", error);
                setError("An error occurred while fetching bank details.");
            }
            setLoading(false);
        };

        if (requestId && token) fetchBankDetails();
    }, [requestId, token, dispatch]);

    if (loading) {
        return <LinearProgress color="success" />;
    }

    return (
        <Box sx={{ padding: 4 }}>
            {error ? (
                <Box>
                    <Typography color="error">{error}</Typography>
                    <Button
                        variant="contained"
                        color="primary"
                        size="large"
                        onClick={() => navigate('/cancel-cheque')}
                       
                    >OK</Button>
                    <Button
                        variant="outlined"
                        size="large"
                        sx={{ml:2}}
                        onClick={() => navigate('/capture-photo')}
                        
                    >CLOSE</Button>
                </Box>
            ) : (
                <>
                    <Box sx={{ mb: 4 }}>
                        <LinearProgress color="success" value={4} variant="determinate" />
                    </Box>

                    <Box textAlign="left" sx={{ mb: 2 }}>
                        <Typography variant="h6">Link Bank Account</Typography>
                        <Typography variant="subtitle2">
                            Please provide your bank account to transfer funds for trading.
                        </Typography>
                    </Box>

                    <Card sx={{ mb: 2 }}>
                        <Box sx={{ p: 3 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <ImageIcon color="primary" aria-label="Bank Icon" />
                                    <Box sx={{ ml: 4 }}>
                                        <Typography variant="body1">
                                            {bankName || 'Bank Name'} ******{String(accountNumber).slice(-4)}
                                        </Typography>
                                        <Typography variant="body2"> {accountType} </Typography>
                                    </Box>
                                </Box>

                                <Radio
                                    value={accountNumber?.toString() ?? ''}
                                    color="primary"
                                    checked={selectedBank === accountNumber?.toString()}
                                    onChange={handleChange}
                                />
                            </Box>

                            <Typography variant="body2">Name:</Typography>
                            <Typography variant="subtitle1"><strong>{name}</strong></Typography>

                            <Typography variant="body2" sx={{ mt: 2 }}>Bank Account:</Typography>
                            <Typography variant="subtitle1"><strong>{accountNumber}</strong></Typography>

                            <Typography variant="body2" sx={{ mt: 2 }}>IFSC Code:</Typography>
                            <Typography variant="subtitle1"><strong>{ifsc_Code}</strong></Typography>

                            <Typography variant="body2" sx={{ mt: 2 }}>Account Type:</Typography>
                            <Typography variant="subtitle1"><strong>{accountType}</strong></Typography>

                            <Typography variant="body2" sx={{ mt: 2 }}>Branch:</Typography>
                            <Typography variant="subtitle1"><strong>{branchName}</strong></Typography>
                        </Box>
                    </Card>

                    <Button
                        fullWidth
                        variant="contained"
                        color="primary"
                        size="large"
                        onClick={() => navigate('/bank-linked')}
                        disabled={!selectedBank}
                    >
                        Continue
                    </Button>
                </>
            )}
        </Box>
    );
};

export default UpiConfirmDetails;
