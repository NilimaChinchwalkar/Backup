import React, { useState } from "react";
import { Button, Typography, Box, FormControl, FormLabel, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';
import MaleIcon from '@mui/icons-material/Male';
import FemaleIcon from '@mui/icons-material/Female';
import TransgenderIcon from '@mui/icons-material/Transgender';
import { useNavigate } from 'react-router-dom';
import { useForm } from '../../context/FormContext';

const PersonalDetail: React.FC = () => {

  const { formData, updateFormData } = useForm();
    const navigate = useNavigate();
    const [genderErr, setGenderErr] =useState<string>()
    const [marritalStatusErr, setMarritalStatusErr] =useState<string>()

    const fnContinue = () => {
      if(!(formData?.genderDetails.options.find((o) => o.isSelected))) {
        setGenderErr('Please select gender')
      }else if(!(formData?.maritalDetails.options.find((o) => o.isSelected))) {
        setMarritalStatusErr('Please select marrital status')
      } else {
        navigate('/qualification')
      }       
    }

    const handleGenderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const selectedAnswerId = parseInt(event.target.value);
      if (!formData?.genderDetails?.options) {
        return; 
      }
      const updatedOptions = formData?.genderDetails.options.map((option) => ({
        ...option,
        isSelected: option.answerId === selectedAnswerId, 
      }));
      setGenderErr("")

      updateFormData({
        genderDetails: {
          ...formData?.genderDetails,
          options: updatedOptions,
        },
      });
    };
    const handleMaritalStatusChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      if (!formData?.maritalDetails?.options) {
        console.error('Gender details options are not available.');
        return; 
      }
      setMarritalStatusErr("")
      const selectedValue = event.target.value;
      const updatedOptions = formData?.maritalDetails.options.map((option) =>
        option.answerName === selectedValue ? { ...option, isSelected: true } : { ...option, isSelected: false }
      );
      updateFormData({ maritalDetails: { ...formData?.maritalDetails, options: updatedOptions } });
    };

    return (
      <Box sx={{ padding: 4 }}>
      {formData && formData?.genderDetails?.questionId!==0 && formData?.maritalDetails?.questionId!==0 ? (
        <Box>
          <Box sx={{ mb: 5 }}>
            <LinearProgress color='success' value={8} variant='determinate' />
          </Box>
          <Box textAlign='left' sx={{ mb: 2 }}>
            <Typography variant='h6'>Personal Details</Typography>
            <Typography variant='subtitle2'>{formData.genderDetails?.subtitle}</Typography>
          </Box>
    
          {/* Gender Details */}
          <Box sx={{ mb: 2 }}>
            {formData.genderDetails ? (
              <FormControl>
                <FormLabel id="demo-row-radio-buttons-group-label">{formData.genderDetails?.title}</FormLabel>
                <RadioGroup
                  row
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="radio-row-buttons-group"
                  value={formData.genderDetails.options.find((o) => o.isSelected)?.answerId || ''} // Fallback to empty string
                  onChange={handleGenderChange}
                >
                  {formData.genderDetails.options.map((gender: any, index: number) => (
                    <FormControlLabel
                      key={gender.answerId}
                      sx={{
                        border: '1px solid #f0f0f0',
                        borderRadius: 2,
                        padding: '5px 10px',
                        '&.Mui-checked': {
                          border: '1px solid #1976d2',
                          backgroundColor: '#e3f2fd',
                          color: '#1976d2',
                        },
                      }}
                      value={gender.answerId} // Use answerId for value
                      control={<Radio sx={{
                          color: '#1976d2',
                          '&.Mui-checked': {
                            color: '#1976d2',
                          },
                        }} 
                      />}
                      label={
                        <span style={{ display: 'flex', alignItems: 'center' }}>
                          {gender.answerName.toLowerCase() === 'female' ? <FemaleIcon style={{ marginRight: 8 }} /> :
                          gender.answerName.toLowerCase() === 'male' ? <MaleIcon style={{ marginRight: 8 }} /> :
                          <TransgenderIcon style={{ marginRight: 8 }} />} {gender.answerName}
                        </span>
                      }
                      labelPlacement="start"
                    />
                  ))}
                </RadioGroup>
                {genderErr && (
                <Typography color="error">{genderErr}</Typography>
                )}
              </FormControl>
            ) : (
              <p>Loading gender details...</p>
            )}
          </Box>
    
          {/* Marital Status Details */}
          <Box sx={{ mb: 2 }}>
            {formData.maritalDetails ? (
              <FormControl>
                <FormLabel id="demo-controlled-radio-buttons-group">{formData.maritalDetails.title}</FormLabel>
                <RadioGroup
                  aria-labelledby="demo-controlled-radio-buttons-group"
                  value={formData.maritalDetails.options.find((o) => o.isSelected)?.answerName || ''} // Use answerName
                  onChange={handleMaritalStatusChange}
                  name="controlled-radio-buttons-group"
                >
                  {formData.maritalDetails.options.map((msDetail: any, index: number) => (
                    <FormControlLabel
                      key={index}
                      value={msDetail.answerName} // Ensure consistency
                      label={msDetail.answerName}
                      control={<Radio sx={{
                        color: '#1976d2',
                        '&.Mui-checked': {
                          color: '#1976d2',
                        },
                      }} />}
                    />
                  ))}
                </RadioGroup>
                {marritalStatusErr && (
                <Typography color="error">{marritalStatusErr}</Typography>
                )}
              </FormControl>
            ) : (
              <Typography>Loading marital details...</Typography> // Change loading message
            )}
          </Box>
    
          <Button variant='contained' fullWidth onClick={fnContinue}>Continue</Button>
        </Box>
      ) : (
        <p>Loading personal details...</p> // General loading state
      )}
      </Box>     
    )
}
export default PersonalDetail