import React, { useState, useEffect } from 'react';
import { Box, Typography, Button } from '@mui/material';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useNavigate } from 'react-router-dom';

interface Payload {
}
const SignatureCapture: React.FC = () => {

  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [signatureDataURL, setSignatureDataURL] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedSignature = localStorage.getItem('signature');
    if (storedSignature) {
      setSignatureDataURL(JSON.parse(storedSignature));
    }
  }, []);

  
  // Helper function to remove the Base64 prefix
  const getBase64ImageWithoutPrefix = (base64String: string) => {
    return base64String.replace(/^data:image\/[a-z]+;base64,/, '');
  };
  const submitSignature = async() => {
    if (signatureDataURL) {
      const base64Image = signatureDataURL ? getBase64ImageWithoutPrefix(signatureDataURL) : null;
      const postData = {
        signatureImagefile: base64Image
      };
      try {
          setLoading(true)
          const result = await makeApiRequest<Payload>("submitSignature",postData);
          if (result.success && result.payload == null)
          {
              setError(result.message)
          }
          else if(result.success && result.payload !== null)
          {
              setSuccessMsg(result.message)
              setLoading(false)
              setTimeout(() => navigate('/user-profile'), 1000);
          }
          else {
              setError(result.message)
              setTimeout(() => navigate('/user-profile'), 1000);
          }
      } catch (error) {
        console.error('Error occurred while submitting the form:', error);
      } finally {
          setLoading(false)
      }
    } else {
        console.log("Signature is empty");
    }
  };

  return (
    <Box>
        <Box sx={{padding:1}}>
            <Typography variant='h6'>Captured Signature</Typography>
        </Box>
        <Box>
        {signatureDataURL ? (
            <Box style={{ padding: '50px', margin: '20px',  width: '500px' }} sx={{ marginTop: 2 }}>
              <img src={signatureDataURL} alt="Signature" style={{ border: '1px solid black', height: '250px' }} />
            </Box>
          ) : (
            <Typography color="error" variant="body2">
              No signature found.
            </Typography>
          )}
        </Box>
        <Box sx={{ textAlign: 'center' }}>
          <Typography variant="body1">Is Signature Image clear ?</Typography>
          <Typography variant="body2">Ensure to have well-it and clearly visible.</Typography>
          <Typography color="success">{successMsg}</Typography>
          <Typography color="error">{error}</Typography>
          <Button 
            sx={{mt: 2,mb: 1}} 
            color='primary' 
            variant='contained'
            fullWidth 
            onClick={submitSignature} 
            disabled={loading} >Continue
            
          </Button>
          
          <Typography color="error">OR</Typography>
          <Button 
            sx={{mt: 1}} 
            color='primary' 
            variant='outlined'
            fullWidth            
            onClick={() => navigate('/signature-pad')}>Re-Capture Signature
          </Button>
        </Box>
          
        
    </Box>

  );
};

export default SignatureCapture;
