import React, { useState } from "react";
import { Button, Typography, Box, FormControl, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import { useNavigate } from 'react-router-dom';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { makeApiRequest } from '../../backendapi/apiutils';
import LinearProgress from '@mui/material/LinearProgress';
import { useForm } from '../../context/FormContext';
const DISDepository = () => {

    const { formData, updateFormData } = useForm();

    const navigate = useNavigate();
    const [isSubmitAPI, setIsSubmitAPI] = useState<boolean>(false)

    const goBack = () => {
        navigate('/trading-investment')
    }
  const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>, questionId: number) => {
    const selectedAnswerName = event.target.value;
  
    if (!formData?.disDepositoryDetails) {
      console.error('Gender details options are not available.');
      return; 
    }
    const updatedDisDepositoryDetails = formData.disDepositoryDetails.map((detail: any) =>
      detail.questionId === questionId
        ? {
            ...detail,
            options: detail.options.map((option: any) => ({
              ...option,
              isSelected: option.answerName === selectedAnswerName,
            })),
          }
        : detail
    );
  
    // Update using a partial update (only for disDepositoryDetails)
    updateFormData({
      disDepositoryDetails: updatedDisDepositoryDetails,
    });
  };

  
  const getSelectedQuesAndAnswers = () => {
    const selectedAnswers = [];
    const findSelectedOption = (details:any) => {
      const selected = details.options.find((option:any) => option.isSelected);
      return selected ? { questionId: details.questionId, answerId: selected.answerId } : null;
    };
    if(formData?.genderDetails) selectedAnswers.push(findSelectedOption(formData.genderDetails))
    if(formData?.maritalDetails) selectedAnswers.push(findSelectedOption(formData.maritalDetails))
    if(formData?.qualificationDetails) selectedAnswers.push(findSelectedOption(formData.qualificationDetails))
    if(formData?.occupationDetails) selectedAnswers.push(findSelectedOption(formData.occupationDetails))
    if(formData?.annualIncomeDetails) selectedAnswers.push(findSelectedOption(formData.annualIncomeDetails))
    if(formData?.tradingExperienceDetails) selectedAnswers.push(findSelectedOption(formData.tradingExperienceDetails))
      formData?.disDepositoryDetails.forEach(detail => {
        const result = findSelectedOption(detail);
        if (result) selectedAnswers.push(result);
      });
      return selectedAnswers.filter(answer => answer !== null)
  }


  const fnContinue = async () => { 
      setIsSubmitAPI(true)
        try {
            const formData = getSelectedQuesAndAnswers()
            navigate('/link-bank-account')
            const response = await makeApiRequest<any>("submitQuestionAnswer",formData);
            if(response?.success) {
                setIsSubmitAPI(false)
                navigate('/link-bank-account') 
            } 
            else {
            setIsSubmitAPI(false)
            }
            
        } catch (error) {
            setIsSubmitAPI(false)
        }
        
}

  return (
    <Box sx={{padding:4}}>
        <Box>
            <Button sx={{mb: 5}} variant='contained' color='primary' onClick={goBack}>
                <KeyboardBackspaceIcon/>
            </Button>
          </Box>
            <Box sx={{mb: 5}}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb: 2}}>
                <Typography variant='h6' >DIS Depository</Typography>
                <Typography variant='subtitle2'>Select Below Options</Typography>
            </Box>
            <Box sx={{ mb: 4 }}>
          {formData?.disDepositoryDetails ? (
            formData?.disDepositoryDetails.map((disdetail: any, index: number) => (
              <Box key={disdetail.questionId}>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  {disdetail.title}
                </Typography>

                <FormControl>
                  <RadioGroup
                    row
                    aria-labelledby={`radio-group-${disdetail.questionId}`}
                    value={disdetail.options.find((o: any) => o.isSelected)?.answerName}  
                    onChange={(event) => handleRadioChange(event, disdetail.questionId)} 
                    name={`row-radio-buttons-group-${index}`} // Ensure unique name for each group
                  >
                    {disdetail.options.map((option: any, optionIndex: number) => (
                      <FormControlLabel
                        sx={{
                          ...(disdetail.questionId === 6 || disdetail.questionId === 8
                            ? {
                                display: 'flex',
                                justifyContent: 'space-between',
                                border: '1px solid #e3f2fd',
                                borderRadius: 2,
                                padding: '0px 20px',
                                margin: '0 5px 5px 0',
                              }
                            : {}),
                          '&.Mui-checked': {
                            border: '1px solid #1976d2',
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2',
                          },
                        }}
                        key={option.answerId}
                        value={option.answerName}
                        control={
                          <Radio
                            sx={{
                              color: '#1976d2',
                              '&.Mui-checked': {
                                color: '#1976d2',
                              },
                            }}
                          />
                        }
                        label={<span>{option.answerName}</span>}
                        labelPlacement="start"
                      />
                    ))}
                  </RadioGroup>
                </FormControl>
              </Box>
            ))
          ) : (
            <Box>
              <Typography>Loading DIS Depository details ...</Typography>
            </Box>
          )}
    </Box>

        <Button variant='contained' fullWidth onClick={fnContinue} disabled={isSubmitAPI}>{isSubmitAPI ? 'Proceeding...' : 'Agree & Proceed'}</Button>
    </Box>
  )
}

export default DISDepository