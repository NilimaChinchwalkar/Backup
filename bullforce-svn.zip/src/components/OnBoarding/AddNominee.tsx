import { Box,LinearProgress, Typography,TextField,Button, FormControl, InputLabel, Select, MenuItem } from '@mui/material'
import React, {useState} from 'react'
import { makeApiRequest } from '../../backendapi/apiutils';
import { useNavigate } from 'react-router-dom';
 
 
interface Payload {
}
const AddNominee: React.FC = () => {
   
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [nameError, setNameError] = useState<string | null>(null);
    const [aadharError, setAadharError] = useState<string | null>(null);
    const [pincodeError, setPincodeError] = useState<string | null>(null);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
    const [nomineeName, setNomineeName] = useState<string>('');
    const [nomineeRelation, setNomineeRelation] = useState<string>('');
    const [nomineeAadhar, setNomineeAadhar] = useState<string>('');
    const [nomineePincode, setNomineePincode] = useState<string>('');
    const navigate = useNavigate();
 
   
    const handleNomineeNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setNomineeName(value);        
        if (!value) {
            setNameError('Nominee Name is required');
        } else {
            setNameError('');
        }
    };
   
    const handleNomineeAadharChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const rawValue = e.target.value;
        const numericValue = rawValue.replace(/\D/g, ""); 
        const trimmedValue = numericValue.slice(0, 12);

        setNomineeAadhar(trimmedValue);

        if (rawValue !== numericValue) {
            setAadharError("Only numeric characters are allowed.");
        } else if (!trimmedValue) {
            setAadharError("Nominee Aadhar is required."); 
        } else if (trimmedValue.length < 12) {
            setAadharError("Aadhar number must be exactly 12 digits long."); 
        } else {
            setAadharError(""); 
        }
    };

    const handleNomineePincodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        const pinCodeRegex = /^\d{6}$/;
        if (!value) {
            setPincodeError('Nominee Pincode is required');
        } else if (!pinCodeRegex.test(value)) {
            setPincodeError('Invalid Pincode format');
        } else {
            setNomineePincode(value);
            setPincodeError('');
        }
    };
   
    const onSubmit = async () => {
        const postData = {
            NomineeName: nomineeName,
            NomineeRelation: nomineeRelation,
            NomineeAadhar: nomineeAadhar,
            NomineeAddressPinCode: nomineePincode,
        };
        try {
            setLoading(true)
            const result = await makeApiRequest<Payload>("addNominee",postData);
            if (result.success && result.payload == null)
            {
                setError(result.message)
            }
            else if(result.success && result.payload !== null)
            {
                setSuccessMsg(result.message)
                setLoading(false)
                setTimeout(() => navigate('/signature-pad'), 1000);
            }
            else {
                setError(result.message)
                console.error('Failed to submit form:', result.message);
            }
        } catch (error) {
            console.error('Error occurred while submitting the form:', error);
        } finally {
            setLoading(false)
        }
  }
 
  return (
   
    <Box>
    <form>
        <Box sx={{padding:4}}>
            <Box sx={{mb:4}}>
                <LinearProgress color='success' value={4} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb:2}}>
                <Typography variant='h6'>Add Nominee</Typography>
                <Typography variant='subtitle2'>Provide below information</Typography>
            </Box>
            <Box>
                <TextField
                label="Enter Nominee Name"
                color="secondary"
                fullWidth size="medium"          
                onChange={handleNomineeNameChange}
                error={!!nameError && !nomineeName}
                helperText={nameError && !nomineeName ? "Nominee Name is required" : ""}
                sx={{mb: 2}}
                type="text"  
                />
               
 
                <FormControl fullWidth sx={{mb: 2}}>
                <InputLabel id="demo-simple-select-label">Nominee Relation</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    label="Nominee Relation"
                    value={nomineeRelation}
                    onChange={(e) => setNomineeRelation(e.target.value as string)}
                    error={!nomineeRelation}
                >
                    <MenuItem value={'Son'}>Son</MenuItem>
                    <MenuItem value={'Daughter'}>Daughter</MenuItem>
                    <MenuItem value={'Father'}>Father</MenuItem>
                    <MenuItem value={'Mother'}>Mother</MenuItem>
                    <MenuItem value={'Brother'}>Brother</MenuItem>
                    <MenuItem value={'Sister'}>Sister</MenuItem>
                    <MenuItem value={'Grand-Son'}>Grand-Son</MenuItem>
                    <MenuItem value={'Grand-Daughter'}>Grand-Daughter</MenuItem>
                    <MenuItem value={'Grand-Father'}>Grand-Father</MenuItem>
                    <MenuItem value={'Grand-Mother'}>Grand-Mother</MenuItem>
                    <MenuItem value={'Not Provided'}>Not Provided</MenuItem>
                    <MenuItem value={'Others'}>Others</MenuItem>
                </Select>
                </FormControl>
 
                <TextField
                    label="Nominee Aadhar Number"
                    color="secondary"
                    fullWidth
                    size="medium"
                    value={nomineeAadhar} 
                    onChange={handleNomineeAadharChange}
                    type="text" 
                    error={!!aadharError} 
                    helperText={aadharError}
                    sx={{ mb: 2 }}
                />
                <TextField
                label="Enter Pincode"
                color="secondary"
                fullWidth size="medium"  
                onChange={handleNomineePincodeChange}
                error={!!pincodeError}
                helperText={pincodeError} 
                sx={{mb: 2}}
                type="tel"  
                />
           
                <Typography color="success">{successMsg}</Typography>                
                <Typography color="error">{error}</Typography>
                {loading ? (
                        <Typography>Loading ...</Typography>
                    )  : (
                <Button
                sx={{mt: 2}} color='primary' variant='contained'
                  fullWidth                  
                  onClick={onSubmit}
                  disabled={ !nomineeName || !nomineeRelation || !nomineeAadhar || !nomineePincode}>
                    Continue</Button>
                    )}
            </Box>
            <Box>
        </Box>
        </Box>
    </form>
     
    </Box>
  )
}
 
export default AddNominee