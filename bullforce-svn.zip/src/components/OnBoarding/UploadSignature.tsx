import { Box, Button, Typography, CircularProgress  } from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import Cropper from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { makeApiRequest } from '../../backendapi/ApiService';
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { useNavigate } from 'react-router-dom';


interface Payload {
}

const UploadSignature: React.FC = () => {
  const uploadedSignature = localStorage.getItem('uploadedSignature') || null;
  const cropperRef = useRef<any>(null); 
  const [signatureDataURL, setSignatureDataURL] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true); 
  const [error, setError] = useState<string | null>(null); 
  const [croppedImage, setCroppedImage] = useState<string | null>(null);
  const token = useSelector((state: RootState) => state.payload?.registerapiPayload?.token);
  const navigate = useNavigate();

  useEffect(() => {
    const storedSignature = localStorage.getItem('uploadedSignature');

    setTimeout(()=>{
        if (storedSignature) {
            setSignatureDataURL(storedSignature);
          } else {
            setError('No signature found in storage.');
          }
    }, 1000)
    
    setLoading(false); // Set loading to false after checking
  }, []);


  const cropImage = () => {
    const cropper = cropperRef.current?.cropper;
    if (cropper) {
      const croppedDataUrl = cropper.getCroppedCanvas().toDataURL();
      console.log(croppedDataUrl); // Handle the cropped image here
      // Get cropped image from Cropper
      setCroppedImage(cropper.getCroppedCanvas().toDataURL('image/png'))
    }
  };

  // Helper function to remove the Base64 prefix
  const getBase64ImageWithoutPrefix = (base64String: string) => {
    return base64String.replace(/^data:image\/[a-z]+;base64,/, '');
  };

  const submitSignature = async() => {
    if (croppedImage) {
      const base64Image = croppedImage ? getBase64ImageWithoutPrefix(croppedImage) : null;
      const postData = {
        signatureImagefile: base64Image
      };
      const headers ={
          "Content-Type": "application/json",
          "X-Api-Key" : process.env.REACT_APP_X_API_KEY || '',
          "Authorization": 'Bearer' + ' ' + token
      };
      const url: string = process.env.REACT_APP_SUBMITSIGNATURE || '';
      try {
          setLoading(true)
          const result = await makeApiRequest<Payload>(url, 'POST', postData, headers);
          if (result.success && result.payload == null)
          { 
              setError(result.message)
          }
          else if(result.success && result.payload !== null)
          {
              const res = result.payload;
              setLoading(false)
              setTimeout(() => navigate('/subscription-plan'), 1000);
          }
          else {
              setError(result.message)
          }
      } catch (error) {
        console.error('Error occurred while submitting the form:', error);
      } finally {
          setLoading(false)
      }
    } else {
        console.log("Signature is empty");
    }
  };


  return (
    <>
      <Box>
      {loading ? (
        <CircularProgress />
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : (
        <>
          {signatureDataURL && (
            <>
              <Typography variant="h6">Crop the image</Typography>
              <Box mt={2} mb={2}>
              <Cropper
                src={signatureDataURL}
                style={{ height: 400, width: '100%' }}
                aspectRatio={2} // 1:1 aspect ratio
                guides={false}
                ref={cropperRef}
              />
              <Button 
                variant="contained"
                sx={{ mt: 2, ml: 2 }}
                color="primary"
                onClick={cropImage}
              >
                Crop Image
              </Button>
              </Box>
              {croppedImage && (
                <Box mt={2} mb={2} display="flex" justifyContent="center" alignItems="center">
                  <img
                    src={croppedImage}
                    alt="Cropped Signature"
                    style={{ height: 200, width: 200 }}
                  />
                  <Button 
                    variant="contained"
                    sx={{ mt: 2, ml: 2 }}
                    color="primary" 
                    onClick={submitSignature}
                >Submit</Button>
                </Box>
              )}
            </>
          )}
        </>
      )}
    </Box>
    </>
  );
};

export default UploadSignature;
