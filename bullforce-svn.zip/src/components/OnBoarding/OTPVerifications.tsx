import React, { useState, useEffect } from "react";
import { TextField, Grid, Button, Typography, Box } from '@mui/material';
import { validateEmailOtp, validateMobileOtp } from "../../zod/validationSchema";
import { setPayload } from '../../store/payloadSlice';
import { useDispatch } from 'react-redux';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { useNavigate } from 'react-router-dom';


interface Payload {
  userId: number;
  stepId: number;
  token: string;
  refreshToken: string;
}

  const OTPVerifications: React.FC = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate();
    
    const userData =  useSelector((state: RootState) => state.payload?.registerFormData);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [merrors, setmErrors] = useState<{ [key: string]: string }>({});
    const [emailOtp, setEmailOtp] = useState<string[]>(new Array(4).fill(''))
    const [mobileOtp, setMobileOtp] = useState<string[]>(new Array(4).fill(''))    
    const [emotp, setemOtp] = useState<string>('');
    const [motp, setmOtp] = useState<string>('');
    const [isOtpValid, setIsOtpValid] = useState<boolean>(false); 
    const [ismobileOtpValid, setIsmobileOtpValid] = useState<boolean>(false);
    const [resendTimer, setResendTimer] = useState<number>(0)
   
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, index: number) => {
        const value = e.target.value
        if (/^\d*$/.test(value)) { 
            const newOtpParts = [...emailOtp];
            newOtpParts[index] = value;
            setEmailOtp(newOtpParts);
      
            if (index < emailOtp.length - 1 && value) {
              const nextInput = document.getElementById(`otp-input-${index + 1}`) as HTMLInputElement;
             
              nextInput?.focus();
            }
      
            setemOtp(newOtpParts.join('')); 
            if (index === emailOtp.length - 1 && newOtpParts.join('').length === 4) {
                handleVerifyEmail(newOtpParts.join(''));
              }
          }
    }
    const handleVerifyEmail = async (otp: string) => {
        const postData = {
            email: userData?.EmailAddress,
            otp: otp
        }
        
        try {
            const response = await makeApiRequest<Payload>("verifyEmailOtp", postData);
            
            if (response.status) {
                setIsOtpValid(true);
                setErrors({ emotp: response.message })
                const nextInput = document.getElementById(`motp-input-0`) as HTMLInputElement;
                nextInput?.focus();
            } else {
                setIsOtpValid(false);
                setErrors({ emotp: response.message })
            }
          } catch (err) {
             setIsOtpValid(false);
          }

    }
    const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>, index: number) => {
        if (e.key === 'Backspace' && !emailOtp[index] && index > 0) {
            const prevInput = document.getElementById(`otp-input-${index - 1}`) as HTMLInputElement;
            setErrors({})
            prevInput?.focus();
        }
    }
    const handleVerifyMobile = async (otp: string) => {
        const postData = {
            userId: "0",
            mobileNo: userData?.MobileNumber,
            otp: otp
        }        
        try {
            const response = await makeApiRequest<Payload>("verifyMobOtp", postData);
            if (response.success) {
              setIsmobileOtpValid(true); 
              setmErrors({motp: response.message})                  
            } else {
              setIsmobileOtpValid(false);
              setmErrors({ motp: response.message})
            }
           
          } 
          catch (err) {
          }

    }
    const handleChangeMobile = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, index: number) => {
        const value = e.target.value
        if (/^\d*$/.test(value)) { 
            const newOtpParts = [...mobileOtp];
            newOtpParts[index] = value;
            setMobileOtp(newOtpParts);
      
            if (index < mobileOtp.length - 1 && value) {
              const nextInput = document.getElementById(`motp-input-${index + 1}`) as HTMLInputElement;
             
              nextInput?.focus();
            }
      
            setmOtp(newOtpParts.join('')); 
            if (index === mobileOtp.length - 1 && newOtpParts.join('').length === 4) {
                handleVerifyMobile(newOtpParts.join(''));
              }
          }
    }
    const handleKeyDownMobile = (e: React.KeyboardEvent<HTMLDivElement>, index: number) => {
        if (e.key === 'Backspace' && !mobileOtp[index] && index > 0) {
            const prevInput = document.getElementById(`motp-input-${index - 1}`) as HTMLInputElement;
            setmErrors({})
            prevInput?.focus();
        }
    }

    const successForm = async () => {
      const emailotpVal = validateEmailOtp(emotp)
      const mobileotpVal = validateMobileOtp(motp)
      if(!emailotpVal.success) {
        setErrors({emotp: emailotpVal.error.errors[0].message});
      } else if(!mobileotpVal.success) {
        setmErrors({motp: mobileotpVal.error.errors[0].message});
      } else {
        setErrors({})
        setmErrors({})
        try {
          await registerAPICall('')
        } catch (error) {
          console.log('error', error)
        }        
      }
    }

    const registerAPICall = async (string: any) =>{
      const postData = {
        EmailAddress: userData?.EmailAddress,
        MobileNumber: userData?.MobileNumber,
        ReferralCode: userData?.ReferralCode,
        IsVerified: string === 'resend' ? false : true,
        ResidenceStatus: userData?.ResidenceStatus,
        AllowDublicateMobile: false
      }
      try {
        const response = await makeApiRequest<Payload>("Register", postData);
        if(response.success) {
          localStorage.setItem('JWT',JSON.stringify(response.payload.token))
          dispatch(setPayload(response.payload))
          navigate('/aadhar-verifications');
          
        } 
        else {
        }  
      } catch (error) {
        console.log('error', error)
      }
    }

    const resendOtp = async () => {
      setResendTimer(60)
      try {
        registerAPICall('resend')
      } catch (error) {
        console.log(error)
      }
    }

    useEffect(()=>{
      let timer: NodeJS.Timeout | null = null;
      if(resendTimer > 0) {
          timer = setTimeout(() => {
              setResendTimer(resendTimer-1)
          }, 1000);
      }
      return () => {
          if (timer) clearTimeout(timer);
        };

    }, [resendTimer])

    return (
        <Box sx={{padding:4}} textAlign='center'>
          <Box sx={{mb:4}}>
            <Typography variant="h6" style={{marginBottom:10}}>Please Enter OTP</Typography>
          </Box>
          <Box sx={{mb:4}}>
            <Box textAlign='center' sx={{mb:2}}>
              <Typography variant='subtitle1'>Please provide us the OTP sent on your Email ID </Typography>
              <Typography variant='subtitle1'>{userData?.EmailAddress}</Typography>
            </Box>
            <Grid container spacing={1} justifyContent="center">
              {emailOtp.map((_, index) => (
                <Grid item key={index}>
                  
                  <TextField
                  id={`otp-input-${index}`}
                    type="text"
                    variant="outlined"
                    style={{ width: '40px', height:'40px' }}
                    value={emailOtp[index]}
                    onChange={(e) => handleChange(e, index)}
                    onKeyDown={(e) => handleKeyDown(e, index)}
                    error={!!errors.emotp && !isOtpValid}
                    disabled={isOtpValid}
                    inputProps={{
                      maxLength: 1,
                      inputMode: 'numeric',
                    }}
                    sx={{
                      borderColor: isOtpValid ? 'green' : 'default', // Green border on success
                    }}
                  />
                </Grid>
              ))}
            </Grid>
          </Box>
            {errors && (
              <Typography color="error" sx={{
                color: isOtpValid && errors.emotp ? 'green' : 'red',
                marginTop: '25px',
                textAlign: 'center'
              }} variant="body2" textAlign='center'>
              {errors.emotp}
              </Typography>  
            )}
          <Box sx={{mt:4}}>
            <Box textAlign='center' sx={{mb:2}}>
              <Typography variant='subtitle1'>Please provide us the OTP sent on your Phone Number </Typography>
              <Typography variant='subtitle1'>{userData?.MobileNumber}</Typography>
            </Box>
          <Grid container spacing={1} justifyContent="center">
          {mobileOtp.map((_, index) => ( 
              <Grid item key={index}>
                <TextField
                  type="text"
                  id={`motp-input-${index}`}
                  variant="outlined"
                  value={mobileOtp[index]}
                  onChange={(e) => handleChangeMobile(e, index)}
                  error={!!merrors.motp && !ismobileOtpValid}
                  style={{ width: '40px', height: '40px' }}
                  disabled={ismobileOtpValid}
                  onKeyDown={(e) => handleKeyDownMobile(e, index)}
                  inputProps={{
                    maxLength: 1, 
                    inputMode: 'numeric', 
                  }}
                />
              </Grid>
          ))}
          </Grid>
          {merrors && (
            <Typography variant="body2" textAlign='center' sx={{
              color: ismobileOtpValid && errors.motp ? 'red' : 'green',
              marginTop: '25px',
              textAlign: 'center'
            }} >
            {merrors.motp}
            </Typography> 
          )}

          
        <Button fullWidth variant="contained" disabled={!isOtpValid || !ismobileOtpValid} color="primary" style={{ marginTop: '25px' }} onClick={successForm}>
        Submit
      </Button>
        </Box>
      
      <Box textAlign='center' sx={{mt:2}}>
          <Button type="button" variant='text' disabled={resendTimer > 0} onClick={resendOtp}>Resend OTP</Button>
          <span style={{color:'red'}}>{resendTimer > 0 ? resendTimer + 's' : ''}</span>
      </Box>
    </Box>
    )
}
export default OTPVerifications