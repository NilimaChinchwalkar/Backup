import React, { useState } from "react";
import { Box, LinearProgress,CircularProgress, Typography, TextField, Button, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio } from "@mui/material";
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';
import { makeApiRequest } from '../../backendapi/apiutils';
import { useDispatch } from "react-redux";
import { useNavigate } from 'react-router-dom';
import { setUpiPayload, setBankConfirmPayload } from '../../store/payloadSlice';


interface Payload {
    requestid: string;
    shortUrl: string;
    upiLink: string;
}
interface PostData {
    upiId: string;
    returnURL: string;
}
interface AccountPostData {
    AccountNumber: string;
    Ifsc_Code: string;
}

interface BankConfirmPayload {
    message: string,
}
const LinkBankAccount: React.FC = () => {
    const[error,setError] = useState<string>('');
    const[apiError,setApiError] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);
    const [selectedValue, setSelectedValue] = useState<string>('upiRadio');
    const [upiId, setUpiIdValue] = useState<string>('');
    const [accNo, setAccountNo] = useState<string>('');
    const [ifscCode, setIfscCode] = useState<string>('');
    const [acc_type, setSelectedAccType] = useState<string>('savings');
    const [confirmAccNo, setConfirmAccountNo] = useState<string>('');
    const [accountError, setAccountError] = useState<string>('');
    const [submitAttempted, setSubmitAttempted] = useState(false);
    const [cancelChequeBtn, setCancelChequeBtn] = useState(false);
    
    
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setError("")
        setApiError("")
        setUpiIdValue("")
        setAccountNo("")
        setIfscCode("")
        setSelectedAccType("")
        setConfirmAccountNo("")
        setAccountError("")
        setSubmitAttempted(false)
        setSelectedValue((event.target as HTMLInputElement).value);
    };
    
    const UPI_REGEX = /^[\w.-]+@[a-zA-Z]+$/;
    const IFSC_REGEX = /^[A-Z]{4}0[A-Z0-9]{6}$/;

    const handleUpiIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setUpiIdValue(value);
        
        if (!UPI_REGEX.test(value)) {
            setError('Invalid UPI Id');
        } else {
            setError(''); 
        }
    };

    const handleIfscChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setIfscCode(value);
        if (!IFSC_REGEX.test(value)) {
            setError('Invalid IFSC Code');
        } else {
            setError(''); 
        }
    };

    const handleRadioAccountTypeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSelectedAccType(value);
    };

    
    const handleUpiSubmit = async () => {
        if (upiId) {
            setLoading(true);
            try {            
                const postData: PostData = {upiId: upiId, returnURL : 'http://localhost:3000/get-bank-details'};                
                
                const result = await makeApiRequest<Payload>("upiDetailSubmit",postData);
                if (result.success && result.payload==null) {
                    console.log('Form submitted successfully:', result.payload);
                } else if(result.success &&  result.payload !== null)
                    {
                    if (result.payload) {
                        dispatch(setUpiPayload(result.payload));
                        const shortUrl = result.payload.shortUrl;

                        // Customize the popup window dimensions
                        const screenWidth = window.screen.width;
                        const screenHeight = window.screen.height;
    
                        // Customize the popup window dimensions based on the device
                        const width = Math.min(700, screenWidth * 0.9); 
                        const height = Math.min(600, screenHeight * 0.9);
                        const left = (screenWidth - width) / 2;
                        const top = (screenHeight - height) / 2;
    
                        // Open the popup window with custom size
                        const popup = window.open(shortUrl,  
                        'DigiLockerPopup',
                        `width=${width},height=${height},top=${top},left=${left}`
                        );

                        
                        // Set a timeout to auto-close the popup after 30 seconds
                        const closeTimeout = setTimeout(() => {
                            if (popup && !popup.closed) {
                                popup.close();
                                console.log('Popup closed automatically after 30 seconds.');
                                navigate('/upi-confirm-details');
                            }
                        }, 30000); 

                        // Monitor if the popup closes before the timeout
                        const popupInterval = setInterval(() => {
                            if (popup && popup.closed) {
                                clearInterval(popupInterval);
                                clearTimeout(closeTimeout); 
                                console.log('Popup closed by the user before the timeout.');
                            }
                        }, 500);
                    }
                    console.log('Payload stored in Redux:', result.payload);
                }
                else {
                    console.error('Failed to submit form:', result.message);
                }
            } catch (error) {
            console.error('Error occurred while submitting the form:', error);
            } finally {
            setLoading(false);
            }
        } else {
            alert('Please fill in all required fields.');
        }
    };

    const handleBankDetailSubmit = async () => {
        setSubmitAttempted(true);
        if (!accNo || !ifscCode) {
            setError("All fields are required.");
            return;
        }
        if (accNo !== confirmAccNo) {
            setAccountError('Account numbers do not match.');
            return;
        }

        setLoading(true);
        try {         
            const postData: AccountPostData = {AccountNumber:accNo, Ifsc_Code:ifscCode };
            const result = await makeApiRequest<BankConfirmPayload>("bankDetailSubmit",postData);
            if (result.success && result.payload==null) {
                navigate('/otp-validations', { state: { upiId } });
            } 
            else if(result.success &&  result.payload !== null)
            {
                if (result.payload) {
                    console.log("Payload Result :"+result.payload)
                    dispatch(setBankConfirmPayload(result.payload));
                }
                navigate('/get-bank-details');
                console.log('Payload stored in Redux:', result.payload);
            }
            else {
                setApiError(result.message);
                setCancelChequeBtn(true);
                console.error('Failed to submit form:', result.message);
            }
        } catch (error) {
            console.error('Error occurred while submitting the form:', error);
        } finally {
        setLoading(false);
        }
        
    }

    return (
        <Box>
            <form>
                <Box sx={{padding:4}}>
                    <Box sx={{mb:4}}>
                        <LinearProgress color='success' value={4} variant='determinate' />
                    </Box>
                    <Box textAlign='left' sx={{mb:2}}>
                        <Typography variant='h6'>Link Bank Account</Typography>
                        <Typography variant='subtitle2'>Please provide bank account to transfer fund for trading</Typography>
                    </Box>
                    <Box>
                        <FormControl>
                            <FormLabel id="demo-radio-buttons-group-label">Choose Method</FormLabel>
                            <RadioGroup
                                row
                                aria-labelledby="demo-radio-buttons-group-label"
                                value={selectedValue}
                                name="radio-buttons-group"
                                onChange={handleRadioChange}
                            >
                                <FormControlLabel
                                    sx={{
                                        border: '1px solid #f0f0f0',
                                        borderRadius: 2,
                                        padding: '5px 55px',
                                        margin: '2px',
                                        '&.Mui-checked': { 
                                            border: '1px solid #1976d2',
                                            backgroundColor: '#e3f2fd',
                                            color: '#1976d2',
                                        },
                                    }}
                                    value="upiRadio"
                                    control={<Radio />}
                                    label="UPI" />
                                
                                <FormControlLabel                                 
                                    sx={{
                                        border: '1px solid #f0f0f0',
                                        borderRadius: 2,
                                        padding: '5px 51px',
                                        margin: '2px',
                                        '&.Mui-checked': { 
                                            border: '1px solid #1976d2',
                                            backgroundColor: '#e3f2fd',
                                            color: '#1976d2',
                                        },
                                    }}
                                    value="bankRadio" 
                                    control={<Radio />} 
                                    label="Bank Detail Manually" />
                            </RadioGroup>
                        </FormControl>
                    </Box>

                   
                    {selectedValue === 'upiRadio' && (
                        <Box>
                            <TextField
                            label="Enter UPI ID"
                            color="secondary"
                            fullWidth size="medium"
                            sx={{mb: 3, mt:3}}
                            type="text"                            
                            onChange={handleUpiIdChange}
                            error={!!error}
                            helperText={error || "e.g. example@upi"}
                            />
                        
                            <Typography sx={{mb: 3}}  variant='subtitle2'>
                                <CurrencyRupeeIcon style={{ marginRight: 2, fontSize: 12 }} /> 1 will be debited from your account to verify bank detail. it will be refunded within 3 working days.
                            </Typography>
                            <Button
                                fullWidth
                                variant='contained'
                                color='primary'
                                size="large"
                                onClick={handleUpiSubmit}
                                disabled={!!error || !upiId || loading} 
                            >
                                {loading ? <CircularProgress size={24} color="inherit" /> : "Send ₹1 to verify bank"} 
                            </Button>
                        </Box>
                    )}

                    {selectedValue === 'bankRadio' && (
                        <Box>
                            <FormControl sx={{mb: 3, mt:3}} fullWidth>
                                <FormLabel id="demo-row-radio-buttons-group-label">Select Account Type</FormLabel>
                                
                                <RadioGroup
                                    row
                                    aria-labelledby="demo-row-radio-buttons-group-label"
                                    name="row-radio-buttons-group"
                                    value={acc_type}
                                    onChange={handleRadioAccountTypeChange}
                                >
                                    <FormControlLabel value="savings" control={<Radio />} label="Savings" />
                                    <FormControlLabel value="current" control={<Radio />} label="Current" />
                                    <FormControlLabel value="cash_credit" control={<Radio />} label="Cash Credit" />
                                </RadioGroup>

                                <TextField
                                    label="IFSC Code"
                                    margin="dense"
                                    color="secondary"
                                    sx={{ mb: 1, mt: 1 }}
                                    value={ifscCode}                 
                                    onChange={handleIfscChange}
                                    error={!!error && !ifscCode && submitAttempted} 
                                    helperText={error && !ifscCode && submitAttempted ? "IFSC Code is required" : ""}
                                />
                                <TextField
                                    label="Account Number"
                                    margin="dense"
                                    color="secondary"
                                    value={accNo}
                                    onChange={(e) => {
                                        setAccountNo(e.target.value);
                                        setAccountError(confirmAccNo && e.target.value !== confirmAccNo ? 'Account numbers do not match.' : '');
                                    }}
                                    error={!accNo && submitAttempted}
                                    helperText={!accNo && submitAttempted ? "Account Number is required" : ""}
                                />
                                <TextField
                                    label="Confirm Account Number"
                                    margin="dense"
                                    color="secondary"
                                    value={confirmAccNo}
                                    onPaste={(e) => e.preventDefault()} 
                                    onChange={(e) => {
                                        setConfirmAccountNo(e.target.value);
                                        setAccountError(accNo && e.target.value !== accNo ? 'Account numbers do not match.' : '');
                                    }}
                                    error={!!accountError}
                                    helperText={accountError || "Re-enter your account number"}
                                />
                            </FormControl> 
                            {apiError && (
                            <Typography color="error" variant="subtitle1" align="center">
                                {apiError}
                            </Typography>
                            )}      
                            {
                                cancelChequeBtn && (
                                    <Button
                                        fullWidth
                                        variant='outlined'
                                        color='primary'
                                        size="large"
                                        onClick={() => navigate('/cancel-cheque')}
                                    >
                                        Submit Cancel Cheque
                                    </Button>
                                )
                            }
                           {!cancelChequeBtn && (
                            <Button
                                fullWidth
                                variant='contained'
                                color='primary'
                                size="large"
                                onClick={handleBankDetailSubmit}
                                disabled={loading}  
                            >
                                {loading ? <CircularProgress size={24} color="inherit" /> : "Continue"}
                            </Button>
                        )}
                        </Box>
                    )}
                </Box>
            </form>
        </Box>
    )
}


export default LinkBankAccount;