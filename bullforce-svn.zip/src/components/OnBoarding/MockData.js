const data = [
    {id: 1, name:"John Doe", age:28, email:"johndoe@gmail.com", contact:"9876543210"},
    {id: 2, name:"John Doe", age:28, email:"johndoe@gmail.com", contact:"9876543210"},
    {id: 3, name:"John Doe", age:28, email:"johndoe@gmail.com", contact:"9876543210"},
    {id: 4, name:"John Doe", age:28, email:"chinchwalkarnilima@gmail.com", contact:"9876543210"},
    {id: 5, name:"Nilima Prathamesh Mosamkar", age:28, email:"johndoe@gmail.com", contact:"9876543210"},
    {id: 6, name:"John Doe", age:28, email:"johndoe@gmail.com", contact:"9876543210"},
    {id: 7, name:"John Doe", age:28, email:"johndoe@gmail.com", contact:"9876543210"}
];

export const getData = () => {
    return data;
}