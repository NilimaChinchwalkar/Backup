import React, { useState, useEffect } from 'react';
import { getData } from './MockData';
import { Box, Button, Paper } from "@mui/material";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import * as ExcelJS from 'exceljs';
import * as FileSaver from "file-saver";
import BFlogo from './BFlogo.png';

interface RowData {
    id: number;
    name: string;
    age: number;
    email: string;
    contact: string;
}

const ExportExcelSheet: React.FC = () => {
    const [sheetData, setSheetData] = useState<RowData[]>([]);

    useEffect(() => {
        const data = getData() as RowData[];
        setSheetData(data);
    }, []);

    const handleExportToExcel = async () => {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet("Sheet 1");
    
        // Fetch and add the logo
        const imageResponse = await fetch(BFlogo);
        const imageBlob = await imageResponse.blob();
        const imageBuffer = await imageBlob.arrayBuffer();
        const imageId = workbook.addImage({
            buffer: imageBuffer,
            extension: "png",
        });
    
        // Merge a large range of cells for the logo (entire header width)
        worksheet.mergeCells("A1:E5"); // Adjust the column range to match the table width
    
        // Add the logo to the merged area
        worksheet.addImage(imageId, {
            tl: { col: 2, row: 1 }, // Precisely center the logo horizontally and vertically
            ext: { width: 200, height: 80 }, // Adjust logo dimensions
        });
    
        // Add spacing below the logo
        worksheet.mergeCells("A6:E6"); // Empty row below the logo
        worksheet.getCell("A6").value = ""; // Keep it empty
    
        // Add company name below the logo
        worksheet.mergeCells("A7:E7"); // Merge cells for company name
        worksheet.mergeCells("A8:E8"); // Empty row below the company name
        const companyNameCell = worksheet.getCell("A7");
        companyNameCell.value = "Bull Force India Pvt Ltd";
        companyNameCell.font = { bold: true, size: 16 };
        companyNameCell.alignment = { horizontal: "center", vertical: "middle" };
    
        // Add column headers
        const headers = ["ID", "Name", "Age", "Email", "Contact"];
        const headerRow = worksheet.addRow(headers);
        headerRow.font = { bold: true };
        headerRow.eachCell((cell) => {
            cell.alignment = { horizontal: "center", vertical: "middle" };
        });
    
        // Add data rows
        sheetData.forEach((row) => {
            const dataRow = worksheet.addRow([row.id, row.name, row.age, row.email, row.contact]);
            dataRow.eachCell((cell) => {
                cell.alignment = { horizontal: "center", vertical: "middle" };
            });
        });
    
        // Auto-adjust column widths
        worksheet.columns.forEach((column) => {
            let maxLength = 10; // Minimum column width
            if (column && column.eachCell) {
                column.eachCell({ includeEmpty: true }, (cell) => {
                    if (cell.value) {
                        const cellValue = cell.value.toString();
                        maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
                    }
                });
            }
            column.width = maxLength;
        });
    
        // Save the workbook
        const buffer = await workbook.xlsx.writeBuffer();
        FileSaver.saveAs(new Blob([buffer]), "MyExcelWithCenteredLogo.xlsx");
    };

    return (
        <Box>
            <Button variant="outlined" color="warning" onClick={handleExportToExcel}>
                Export 
            </Button>
            <div>
                <TableContainer component={Paper}>
                    <Table aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="center">ID</TableCell>
                                <TableCell align="center">Name</TableCell>
                                <TableCell align="center">Age</TableCell>
                                <TableCell align="center">Email</TableCell>
                                <TableCell align="center">Contact</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {sheetData.map((row) => (
                                <TableRow key={row.id}>
                                    <TableCell align="center">{row.id}</TableCell>
                                    <TableCell align="center">{row.name}</TableCell>
                                    <TableCell align="center">{row.age}</TableCell>
                                    <TableCell align="center">{row.email}</TableCell>
                                    <TableCell align="center">{row.contact}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
        </Box>
    );
};

export default ExportExcelSheet;
