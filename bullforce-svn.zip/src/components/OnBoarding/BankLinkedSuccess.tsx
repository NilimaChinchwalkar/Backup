import React from "react";
import { Box, Typography, Button } from "@mui/material";
import VerifiedIcon from '@mui/icons-material/CheckCircle';
import { useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import { RootState } from "../../store/store";

interface BankLinkedSuccessProps {
    accountEnding?: string; 
}

const BankLinkedSuccess: React.FC<BankLinkedSuccessProps> = ({ accountEnding }) => {
    const navigate = useNavigate();
    const message = useSelector((state: RootState) => state.payload?.bankConfirmApiPayload?.message);
    
    const nextStep = () => {
        navigate('/capture-photo')
    }

    return (
        <Box 
            sx={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                p: 3,
                borderRadius: 2,
                boxShadow: 3,
            }}
            aria-live="polite"
        >
            <VerifiedIcon sx={{ color: 'green' }} fontSize="large" />
            <Typography variant='h6' sx={{ mt: 2 }}>
                Bank linked Successfully to Bullforce
            </Typography>
            <Typography variant='subtitle2' sx={{ mt: 1 }}>
                For DBS Digi Bank Ltd. {accountEnding ? `Account ending in ${accountEnding}` : ''} {message && `- ${message}`}
            </Typography>
            
            <Button fullWidth variant='contained' color='primary' size="large" sx={{ mt: 3 }} onClick={nextStep}>
                Continue 
            </Button>
        </Box>
    );
};

export default BankLinkedSuccess;
