import React, { useState, useRef, useEffect } from "react";
import { TextField, Button, Typography, Box  } from "@mui/material";
import { AadhaarOTPFormData, getSchema } from "../../zod/validationSchema"; // Import the schema
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import { makeApiRequest } from '../../backendapi/apiutils';
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';


interface generateAadhaarOtpPayload {
    reqId: string;
}
interface verifyAadhaarOtpPayload {
    message: string;
}

    const Aadharcard: React.FC = () => {
    const [isAPIsuccess, setIsAPIsuccess] = useState<boolean>(false)
    const [isOTPsuccess, setOTPsuccess] = useState<boolean>(false)
    const [isOTPVerify, setIsOTPVerify] = useState<boolean>(false)
    const [isOtpStep, setIsOtpStep] = useState<boolean>(false); 
    const [clientId, setAdharClientID] = useState<string>('')
    const otpRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

    const [resendTimer, setResendTimer] = useState<number>(0)
    const navigate = useNavigate();
    const {
        register,
        control,
        handleSubmit,
        setError,
        formState: { errors },
        clearErrors,
        getValues, setValue
      } = useForm<AadhaarOTPFormData>({
        resolver: zodResolver(getSchema(isOtpStep)),
      });
   

    const onSubmitAadhar:SubmitHandler<AadhaarOTPFormData> = async (data) => {
        const postData = {
            aadhaarNumber: data.aadharNumber
        }
        setIsAPIsuccess(true)
        try {
            const response = await makeApiRequest<generateAadhaarOtpPayload>("generateAadharOtp",postData);
            if(response.success && response.httpStatusCode === 200) {
                setError("aadharNumber", {
                    type: "manual",
                    message: response?.message,
                });
                setIsAPIsuccess(false)
                setAdharClientID(response.payload?.reqId)
                setIsOtpStep(true)
            } 
            else {
                setIsAPIsuccess(true)
                setTimeout(() => {
                    setIsAPIsuccess(false)       
                    setError("aadharNumber", {
                        type: "manual",
                        message: "",
                    });          
                }, 60000);

                setError("aadharNumber", {
                type: "manual",
                message: response?.message || "API request failed",
                });
            }        
        } catch (error) {
            console.error('Error making API request:', error);
            setError("aadharNumber", {
                type: "manual",
                message: "Something went wrong, please try again.",
            });
            setIsAPIsuccess(false)
        }
    }
    const onSubmitOTP: SubmitHandler<AadhaarOTPFormData> = async (data) => {
        
        const postData = {
            ClientId: clientId,
            OTP: data.aadharOTP 
        }
        try {
            setIsOTPVerify(true)
            const response = await makeApiRequest<verifyAadhaarOtpPayload>("verifyAadharOtp",postData);
            if(response?.success) {
                setIsOTPVerify(false)
                setOTPsuccess(true)
                setError("aadharOTP", {
                    type: "manual",
                    message: response?.message,
                  });
                  navigate('/pancard-verifications')
            } else {
                setIsOTPVerify(false)
                setOTPsuccess(false)
                    setError("aadharOTP", {
                      type: "manual",
                      message: response?.message || "API request failed",
                    });
                  }
            
            } catch (error) {
                setIsOTPVerify(false)
                setOTPsuccess(false)
                console.error('Error making API request:', error);
                setError("aadharOTP", {
                    type: "manual",
                    message: "Something went wrong, please try again.",
                  });
                
            }
    }
    const handleOtpChange = (index: number,e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { value } = e.target;
        if (/^\d?$/.test(value)) { 
          clearErrors('aadharOTP'); 
          const currentOtp = getValues("aadharOTP") || "";  
          const otpArray = currentOtp.split("");  
          otpArray[index] = value;  
      
          const updatedOtp = otpArray.join(""); 
          setValue("aadharOTP", updatedOtp);
      
          if (value !== "" && index < 5) {
            otpRefs[index + 1].current?.focus();
          } else if (value === "" && index > 0) {
            otpRefs[index - 1].current?.focus();
          }
        }
      };
      const handleSubmitForm: SubmitHandler<AadhaarOTPFormData> = async (data) => {
        if (isOtpStep) {
          await onSubmitOTP(data);
        } else {
          await onSubmitAadhar(data);
        }
      };
      const handleResendOTP = async () => {
        setResendTimer(60)
        setIsAPIsuccess(true);
        try {
            setValue("aadharOTP", "");
            otpRefs[0].current?.focus();
            await onSubmitAadhar(getValues())
            setIsAPIsuccess(false);
        } catch(error) {
            console.error("Error resending OTP:", error);
            setIsAPIsuccess(false);
        }
      }
      useEffect(()=>{
        let timer: NodeJS.Timeout | null = null;
        if(resendTimer > 0) {
            timer = setTimeout(() => {
                setResendTimer(resendTimer-1)
            }, 1000);
        }
        return () => {
            if (timer) clearTimeout(timer);
          };

      }, [resendTimer])
      
    return (
        <Box>
            <form onSubmit={handleSubmit(handleSubmitForm)}>
                {!isOtpStep && (
                    <Box sx={{padding:4}}>
                        <Box sx={{mb:4}}>
                            <LinearProgress color='success' value={4} variant='determinate' />
                        </Box>
                        <Box textAlign='left' sx={{mb:2}}>
                            <Typography variant='h6'>Aadhar Card Detail</Typography>
                        </Box>
                        <Box>
                            <TextField 
                            label="Enter your Aadhar card" 
                            color="secondary" 
                            fullWidth size="small" 
                            sx={{mb: 1}} 
                            type="text"
                            {...register('aadharNumber')} 
                            error={!!errors.aadharNumber} 
                            helperText={errors.aadharNumber?.message}
                            />
                            {isOtpStep && (
                                <Typography color='success'>OTP sent, you will redirect to verify otp</Typography>
                            )}
                             {!isAPIsuccess && (
                            <Typography sx={{mb: 10}}  variant='subtitle2'>You will receive an OTP on your Aadhar card Linked to your mobile number</Typography>
                             )}
                            <Button fullWidth type="submit" variant='contained' color='primary' disabled={isAPIsuccess}>{isAPIsuccess ? 'Sending OTP...' : 'Continue'}</Button>
                        </Box>
                    </Box>
                )}
                {isOtpStep && ( 
                    <Box sx={{padding: 4}}>
                        <Typography variant= 'h6'>Verify with OTP</Typography>
                        <Typography variant= 'subtitle2' sx={{mb: 5}}>Please provide us the OTP, sent on your Phone Number </Typography>
                        <Box textAlign='center'>
                        {Array.from({ length: 6 }).map((_, index) => (
                            <Controller
                                key={index}
                                name="aadharOTP"
                                control={control}
                                defaultValue=""
                                render={({ field }) => {
                                const otpArray = field.value ? field.value.split('') : ['', '', '', '', '', ''];
                                return (
                                    <TextField 
                                    inputRef={otpRefs[index]} 
                                    value={otpArray[index] || ""} 
                                    onChange={(e) => handleOtpChange(index, e)} 
                                    sx={{ width: 40 , marginRight: 2 }}
                                    error={!!errors.aadharOTP}
                                    />
                                );
                                }}
                            />
                            ))}
                        </Box>
                            {(errors.aadharOTP && !isOTPsuccess) && (<Typography color="error" textAlign="center">{errors.aadharOTP.message}
                            </Typography>)}
                        <Button sx={{mt: 5}} fullWidth type="submit" variant='contained' color='primary' disabled={isOTPVerify}>{isOTPVerify ? 'Verifying OTP...' : 'Submit'}</Button>
                        <Typography sx={{marginTop: 2, textAlign:"center"}}>
                            <Button type="button" disabled={resendTimer > 0} onClick={handleResendOTP} variant='text'>Resend OTP</Button>
                            <span style={{color:'red'}}>{resendTimer > 0 ? resendTimer + ' in sec' : ''}</span>
                        </Typography>
                    </Box>
                )}
            </form>
        </Box>
)
}
export default Aadharcard