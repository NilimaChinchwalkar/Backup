import React, { useState } from 'react'
import { Button, Box, Typography, Dialog, DialogActions, DialogContent, DialogContentText, CircularProgress} from '@mui/material';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import LockIcon from '@mui/icons-material/Lock';
import { makeApiRequest } from '../../backendapi/apiutils';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
 
interface ApiResponsePayload {
    requestId: string; // Exists here
    consentDocAuthenticationURL: string;
    message?: string | null;
}
 
interface ApiResponse {
    success: boolean;
    payload: ApiResponsePayload; // Nested inside `payload`
}
function isApiResponsePayload(payload: any): payload is ApiResponsePayload {
    return (
        typeof payload === "object" &&
        payload !== null &&
        typeof payload.requestId === "string" &&
        typeof payload.consentDocAuthenticationURL === "string"
    );
}
const UploadBankDetails = () => {
 
    const navigate = useNavigate()
    const usersSegmentName = useSelector((state: RootState) => state.payload?.segmentDetailsPayload?.segmentName || []);
    const [loader, setLoader] = useState<boolean>(false)
    const [loading, setLoading] = useState<boolean>(false)
    const [successMsg, setSuccessMsg] = useState<string>("")
    const [successMsgAPI, setSuccessMsgAPI] = useState({
        isSuccess: false,
        msg: ''
    });
    const [open, setOpen] = useState<boolean>(false)
 
    const fnContinue = async () => {
        setLoader(true);
   
        const postBody = {
            aaType: "ONEMONEY_SETU"
        };
   
        try {
            const response = await makeApiRequest<ApiResponse>("getbankstatementprovider", postBody);
   
            if (response?.success && isApiResponsePayload(response.payload)) {
                const payload = response.payload;
                const redirectionURL = payload.consentDocAuthenticationURL;
   
                console.log("Before setting Consent ID:", payload.requestId);
                const requestId = payload.requestId
   
                // Open the popup
                const popup = window.open(
                    redirectionURL,
                    '_blank',
                    `width=800,height=600,left=200,top=200,resizable=yes,scrollbars=yes`
                );
   
                const closeTimeout = setTimeout(() => {
                    if (popup && !popup.closed) {
                        popup.close();
                        console.log('Popup closed automatically after 2 minutes.');
                        if (requestId) {
                            fetchBankStatement(requestId);
                        }
                    }
                }, 120000);
   
                const popupInterval = setInterval(() => {
                    if (popup && popup.closed) {
                        console.log('Popup manually closed. Request ID:', requestId);
                        clearInterval(popupInterval);
                        clearTimeout(closeTimeout);
                        if (requestId) {
                            fetchBankStatement(requestId);
                        }
                        console.log('Popup closed by the user before the timeout.');
                    }
                }, 1000);
            } else {
                navigate('/');
            }
            setLoader(false);
        } catch (error) {
            console.error("Error making API request:", error);
            setLoader(false);
        }
    };
 
    const fetchBankStatement = async (consentId: string) => {
        try {
            setLoading(true)
            if (!consentId) {
                console.error("Consent ID is not set.");
                return;
            }
   
            const formData: { consentId: string; format: string } = {
                consentId: consentId,
                format: 'json',
            };
   
            const result = await makeApiRequest("getbankstatement", formData);
 
            if (result && result.success === false) {
                setLoading(false)
                setOpen(true);
                setSuccessMsgAPI({
                    isSuccess: result.success,
                    msg: "Failed to fetch the bank statement. Please try again.",
                });
            } else {
                setLoading(false)
                setOpen(true);
                setSuccessMsgAPI({
                    isSuccess: result.success,  
                    msg: "Document Uploaded",
                });
            }
        } catch (error) {
            setLoading(false)
            console.error('Error fetching bank statement:', error);
            setSuccessMsgAPI({
                isSuccess: false,
                msg: "An error occurred while fetching the bank statement.",
            });
        }
    };
   
 
    const goBack = () => {
        navigate('/dis-depository')
    }
    const fnSkip = () => {
        navigate('/add-nominee')
    }
    const handleClose = () => {
        setOpen(false)
    }
    const handleCloseSuccessPopup = () => {
        setOpen(false)
        navigate('/add-nominee')
    }
   
    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        setLoading(true)
        const file = event.target.files?.[0];
 
        if (file?.type === "application/pdf") {
            //API
            const formData = new FormData();
            formData.append("file", file);
 
            try {
                const response = await makeApiRequest<ApiResponse>("uploadbankstatement",formData);
                if(response?.success) {
                    setTimeout(() => {
                        navigate('/add-nominee')
                    }, 5000);      
                    setLoading(false)
                } else {
                   
                    setLoading(false)
                }
                setSuccessMsg(response.message)  
            } catch (error) {
                console.error('Error making API request:', error);
                //setLoader(false)   
                setLoading(false)         
            }
 
        } else {
            alert("Please select a PDF file.");
            setLoading(false)
        }
 
       
    };
 
   
    return (
    <Box sx={{ padding: 4 }}>
        <Box sx={{mb:4}}>
            <Button variant='contained' color='primary' onClick={goBack}>
            <KeyboardBackspaceIcon/>
            </Button>
        </Box>
        <Box sx={{mb: 5}}>
            <LinearProgress color='success' value={8} variant='determinate' />
        </Box>
        <Box textAlign='left' sx={{mb: 2}}>
            <Typography variant='h5' sx={{mb:2}} >Account Information</Typography>
            <Typography variant='body2'>As per the regulatory requirements, we would need six months bank statement of the applicant. Can we have your consent to digitally get the same from the bank identified by you.</Typography>
           
        </Box>
        <Box sx={{mb: 5}}>
            <img src='' alt='Onemoney-logo' />
        </Box>
     
        {loader ? (
        <CircularProgress color="secondary" size={24} />
    ) : (
        <>
           <input
            accept="pdf/*"
            id="file-upload"
            type="file"
            style={{ display: 'none' }}
            onChange={handleFileChange}
        />
        <label htmlFor="file-upload">
            <Button variant="outlined" color="primary" component="span" fullWidth sx={{mb:4}}>
            <CloudUploadIcon></CloudUploadIcon>   Upload 6 months back details
            </Button>
        </label>
        </>
 
           
    )}
    {(successMsg &&
    <Typography color="success">{successMsg} wait! you will redirect to next step</Typography>
    )}
 
        <Box>
            <Typography sx={{pb:1}}>
                <LockIcon fontSize='small' />
                Your data is safe and secured with us
            </Typography>
        <Button variant='contained' fullWidth sx={{mb:2}} onClick={fnContinue }>I agree & continue with  {usersSegmentName.join(', ')}
             
            </Button>
        <Button variant='text' fullWidth onClick={fnSkip}>Skip, I'll Do It Later</Button>
       
        </Box>
        <Box sx={{mt:2}}>
            {open && (
                <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
              >
                <DialogContent>
                  <DialogContentText id="alert-dialog-description">
                  {successMsgAPI && successMsgAPI.isSuccess ? (
                        <>
                            <Typography color="success">{successMsgAPI.msg}</Typography>
                            <Typography color="success">You will be redirected to the next step.</Typography>
                        </>
                    ) : (
                        <Typography color="error">{successMsgAPI.msg}</Typography>
                    )}
                   
                  </DialogContentText>
                </DialogContent>
                <DialogActions>
                    {successMsgAPI.isSuccess ? (
                        <Button  onClick={handleCloseSuccessPopup}>Continue</Button>
                    ) :
                    <Button onClick={handleClose}>Close</Button>
                }
               
               
                </DialogActions>
              </Dialog>
            )}
       
        </Box>
        {(loading &&  
        <Box
            sx={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100vw',
                height: '100vh',
                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                zIndex: 1300,
            }}
        >
            <CircularProgress />
        </Box>
        )}
    </Box>
  )
}
 
export default UploadBankDetails