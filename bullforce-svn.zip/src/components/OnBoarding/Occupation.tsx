import React, {useState} from "react";
import { Button, Typography, Box, FormControl, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from '../../context/FormContext';


const Occupation: React.FC = () => {
    const { formData, updateFormData } = useForm();
    const [occupationErr, setOccupationErr] =useState<string>()

 
    const navigate = useNavigate();

    const goBack = () => {
        navigate('/qualification')
    }
    const fnContinue = () => { 
        if(!formData?.occupationDetails.options.find((o) => o.isSelected)) {
            setOccupationErr("Please select occupation")
            return
        }
        navigate('/annual-income')
    }
    const handleOccupationChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedqualifiaction = event.target.value;
        if (!formData?.occupationDetails?.options) {
            console.error('Gender details options are not available.');
            return; 
          }
          setOccupationErr("")
        const updatedOptions = formData.occupationDetails.options.map((option:any) =>
          option.answerName === selectedqualifiaction ? { ...option, isSelected: true } : { ...option, isSelected: false }
        );
        updateFormData({ occupationDetails: { ...formData.occupationDetails, options: updatedOptions } });
      };
 
    return (
        <Box sx={{padding:4}}>
            <Box sx={{mb:4}}>
                <Button variant='contained' color='primary' onClick={goBack}>
                <KeyboardBackspaceIcon/>
                </Button>
            </Box>
            <Box sx={{mb: 5}}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb: 2}}>
                <Typography variant='h6' >{formData?.occupationDetails.title}</Typography>
                <Typography variant='subtitle2'>{formData?.occupationDetails.subtitle}</Typography>
            </Box>
 
            <Box sx={{mb:4}}>
                {formData?.occupationDetails ? (
                <FormControl>
               
                <RadioGroup
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    value={formData?.occupationDetails.options.find((o:any) => o.isSelected)?.answerName}
                    onChange={handleOccupationChange}
                    name="radio-row-buttons-group"
                >
                    
                    {formData.occupationDetails.options.map((occupation:any, index:number) => (
                    <FormControlLabel
                    key={occupation.answerId}
                    sx={{
                        border: '1px solid #f0f0f0',
                        borderRadius: 2,
                        padding: '5px 100px',
                        margin: '2px',
                        '&.Mui-checked': {
                            border: '1px solid #1976d2',
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2',
                        },
                        }}
                    value={occupation.answerName}
                    control={<Radio sx={{
                        color: '#1976d2',
                        '&.Mui-checked': {
                            color: '#1976d2',
                        },
                        }}
                        
                        />}
                    label={
                        <span>
                            {occupation.answerName}
                        </span>
                    }
                    labelPlacement="start"
                    />
                    ))}
                   
                    </RadioGroup>
                    {occupationErr && (
                <Typography color="error">{occupationErr}</Typography>
                )}
                </FormControl>            
                ) : (
                <p>Loading gender details...</p>
                )}
            </Box>
            <Button variant='contained' fullWidth onClick={fnContinue}>Continue</Button>
 
        </Box>
    )
}
export default Occupation;