import React, { useState } from 'react';
import { Box, Button, Checkbox, FormControlLabel, Typography } from '@mui/material';
import CameraAltOutlinedIcon from '@mui/icons-material/CameraAltOutlined';
// @ts-ignore
import SignatureCanvas from 'react-signature-canvas';
import { useNavigate } from 'react-router-dom';


const SignaturePad: React.FC= () => {
    const navigate = useNavigate();
    const [signature, setSignature] = useState<any>(null); 
    const [checked, setChecked] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const clearSignature = () => {
        if (signature) {
            signature.clear();
            setError("")
        }
    };

    const saveSignature = () => {
        if (signature && !signature.isEmpty()) {            
            const dataURL = signature.toDataURL('image/png');
            localStorage.setItem('signature', JSON.stringify(dataURL));
            setTimeout(() => navigate('/capture-signature'), 1000);
        } else {
            setError("Please draw signature.")
        }
    };

    const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setChecked(event.target.checked);
      };

      
    // Handle file upload from the PC
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            localStorage.removeItem('uploadedSignature');
            const reader = new FileReader();
            reader.onloadend = () => {
                if (reader.result) {
                    localStorage.setItem('uploadedSignature', reader.result as string);
                    navigate('/upload-signature');
                }
            };
            reader.readAsDataURL(file);
            event.target.value = ''; // Clear the input
        } else {
            console.error("No file selected or unsupported file type.");
        }
    };
    
    return (
        <Box>
           <Box sx={{ display: 'flex', padding: 1 }}>
                <Typography variant="h6">Signature</Typography>
                <label htmlFor="upload-signature">
                    <CameraAltOutlinedIcon 
                        sx={{ marginLeft: '410px', cursor: 'pointer' }}
                    /> 
                    <input 
                        id="upload-signature"
                        type="file" 
                        accept="image/*" 
                        hidden 
                        onChange={handleFileChange} 
                    />
                </label>
            </Box>
            <Box style={{ border: '1px solid #000', padding: '30px', margin: '20px',  width: '450px' }}>
            <SignatureCanvas 
            ref = {(ref:any) => setSignature(ref)}
            penColor='grey'
            canvasProps={{width: 400, height: 250, className: 'sigCanvas'}} />
            </Box>
            
            <Box style={{ padding: '30px', margin: '20px',  width: '450px' }}>
            <FormControlLabel
                control={
                    <Checkbox
                    checked={checked}
                    onChange={handleCheckboxChange}
                    inputProps={{ 'aria-label': 'controlled-checkbox' }}
                    />
                }
                label="I am an Indian citizen, for tax purpose I am not resident in any jurisdiction(s) outside India (FATCA/CRS Declaration)"
                            labelPlacement="end"
                />

                <Button 
                sx={{mb: 2}} 
                color='primary' 
                variant='outlined'
                fullWidth onClick={clearSignature}>Clear</Button>
                <Typography color="error">{error}</Typography>
                <Button 
                sx={{mt: 2}} 
                color='primary' 
                variant='contained'
                fullWidth onClick={saveSignature}>Continue</Button>

            </Box>
        </Box>
      );
}

export default SignaturePad
