import React from 'react'
import { Box, Button, LinearProgress,Typography } from "@mui/material";
import { useNavigate } from 'react-router-dom';

const Onemoney: React.FC = () => {
    const navigate = useNavigate();
    const handleSubmit = async () => { 
        setTimeout(() => navigate('/add-nominee'), 1000);
    }

    return (
    <Box>
        <form>
            <Box sx={{padding:4}}>
                <Box sx={{mb:4}}>
                    <LinearProgress color='success' value={4} variant='determinate' />
                </Box>
                <Box textAlign='left' sx={{mb:2}}>
                    <Typography variant='h6'>Onemoney</Typography>
                    <Typography variant='subtitle2'>Provide below information</Typography>
                </Box>
                <Button sx={{mt: 2}} color='primary' onClick={handleSubmit} variant='contained' fullWidth>Continue</Button>
            </Box>
        </form>
        </Box>
    )
}

export default Onemoney
