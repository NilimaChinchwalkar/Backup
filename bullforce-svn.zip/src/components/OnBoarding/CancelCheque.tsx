import {
    Box,
    LinearProgress,
    Typography,
    Button,
    CircularProgress,
} from "@mui/material";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { makeApiRequest } from "../../backendapi/apiutils";

interface ApiResponse {
    success: boolean;
    message: string;
    payload: {
        message: string; 
    };
}

const CancelCheque: React.FC = () => {
    const [chequeImage, setChequeImage] = useState<string | null>(null);
    const [chequeFile, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string>('');
    const [successMsg, setSuccess] = useState<string>('');

    const token = useSelector((state: RootState) => state.payload?.registerapiPayload?.token);
    const navigate = useNavigate();

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files?.[0];
    
        if (selectedFile) {
            setFile(selectedFile);
            const reader = new FileReader();
            reader.onloadend = () => {
                if (reader.result) {
                    setChequeImage(reader.result as string); 
                }
            };
            reader.readAsDataURL(selectedFile);
        } else {
            setChequeImage(null);
        }
    };
    
    

    const handleSubmit = async () => {
        if (!token) {
            setError("Authentication failed. Please login.");
            return;
        }
    
        setLoading(true);
        setError("");
    
        try {
            if (!chequeFile) {
                setError("No file selected. Please upload a valid cheque image.");
                return;
            }
    
            const formData = new FormData();
            formData.append("File", chequeFile);
    
            const result = await makeApiRequest<ApiResponse>("cancelCheckSubmit",formData);
    
            if (result && result.success) {
                const payload = result.payload;
                setSuccess(result.message + ' ' + (payload?.message || ''));
                setTimeout(() => {
                    navigate('/capture-photo'); 
                }, 5000);
            } else {
                setError("Failed to submit cheque. Please try again.");
            }
        } catch (error) {
            console.error('Error uploading image:', error);
            setError("An error occurred while uploading the image.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box sx={{ padding: 4 }}>
            <Box sx={{ mb: 4 }}>
                <LinearProgress color="success" value={4} variant="determinate" />
            </Box>
            <Box textAlign="left" sx={{ mb: 2 }}>
                <Typography variant="h6">Cancel Cheque</Typography>
                <Typography variant="subtitle2">Please provide cancel cheque</Typography>
            </Box>

            <Box>
                <Button fullWidth variant="outlined" component="label">
                    Upload Cheque
                    <input type="file" accept="image/*" hidden onChange={handleFileChange} />
                </Button>

                {chequeImage && (
                    <Box sx={{ width: '100%', maxWidth: 500, height: 'auto', boxShadow: 3, marginTop: '10px' }}>
                        <img
                            src={chequeImage}
                            alt="Cancel Cheque"
                            style={{ width: '100%', height: 'auto' }}
                        />
                        <Button
                            fullWidth
                            variant="contained"
                            color="primary"
                            size="large"
                            onClick={handleSubmit}
                            disabled={loading}
                            sx={{ marginTop: 2 }} 
                        >
                            {loading ? <CircularProgress size={24} color="inherit" /> : "Continue"}
                        </Button>
                    </Box>
                )}

                {error && (
                    <Typography variant="body2" color="error" sx={{ mt: 2 }}>
                        {error}
                    </Typography>
                )}
                {successMsg && (
                    <Typography variant="body2" color="success" sx={{ mt: 2 }}>
                        {successMsg}
                    </Typography>
                )}
            </Box>
        </Box>
    );
};

export default CancelCheque;
