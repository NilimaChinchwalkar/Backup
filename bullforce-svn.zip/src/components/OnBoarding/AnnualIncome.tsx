import React, {useState} from "react";
import { Button, Typography, Box, FormControl, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from '../../context/FormContext';

const AnnualIncome = () => {

    const { formData, updateFormData } = useForm();
    const navigate = useNavigate();
    const [annualIncomeErr, setAnnualIncomeErr] = useState<string>()

    const handleAnnualIncomeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const selectedqualifiaction = event.target.value;
      if (!formData?.annualIncomeDetails?.options) {
        console.error('Gender details options are not available.');
        return; 
      }
      setAnnualIncomeErr("")
      const updatedOptions = formData?.annualIncomeDetails.options.map((option) =>
        option.answerName === selectedqualifiaction ? { ...option, isSelected: true } : { ...option, isSelected: false }
      );
      updateFormData({ annualIncomeDetails: { ...formData?.annualIncomeDetails, options: updatedOptions } });
    };
    const fnContinue = () => {
      if(!formData?.annualIncomeDetails.options.find((o) => o.isSelected)) {
        setAnnualIncomeErr("Please select annual income")
        return
    }
        navigate('/trading-investment')
    }
    const goBack = () => {
        navigate('/occupation')
    }

  return (
    <Box sx={{padding:4}}>
            <Box sx={{mb:4}}>
                <Button variant='contained' color='primary' onClick={goBack}>
                <KeyboardBackspaceIcon/>
                </Button>
            </Box>
            <Box sx={{mb: 5}}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb: 2}}>
                <Typography variant='h6' >{formData?.annualIncomeDetails.title}</Typography>
                <Typography variant='subtitle2'>{formData?.annualIncomeDetails.subtitle}</Typography>
            </Box>

            <Box sx={{mb:2}}>
            {formData?.annualIncomeDetails ? (
              <FormControl>
              <RadioGroup
                  aria-labelledby="demo-radio-buttons-group-label"
                  value={formData?.annualIncomeDetails.options.find((o:any) => o.isSelected)?.answerName}
                  onChange={handleAnnualIncomeChange}
                  name="radio-buttons-group"
              >
                
                {formData?.annualIncomeDetails.options.map((income:any, index:number) => (
                  <FormControlLabel
                  key={income.answerId}
                  
                   sx={{
                      border: '1px solid #f0f0f0',
                      borderRadius: 2,
                      width: '300px',
                      mb: 2,
                      padding: '5px 10px',
                      '&.Mui-checked': { 
                        border: '1px solid #1976d2',
                        backgroundColor: '#e3f2fd',
                        color: '#1976d2',
                      },
                    }}
                  value={income.answerName}
                  control={<Radio sx={{
                      color: '#1976d2', 
                      '&.Mui-checked': {
                        color: '#1976d2', 
                      },
                    }}
                    />}
                  label={income.answerName}
                  labelPlacement="start"
                  />
                ))}
                
                </RadioGroup>
                {annualIncomeErr && (
                <Typography color="error">{annualIncomeErr}</Typography>
                )}
               </FormControl>             
            ) : (
              <p>Loading gender details...</p>
            )}
            </Box>
            <Button variant='contained' fullWidth onClick={fnContinue}>Continue</Button>
        </Box>
  )
}

export default AnnualIncome