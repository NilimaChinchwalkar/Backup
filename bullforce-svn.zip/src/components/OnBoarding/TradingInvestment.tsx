import React, {useState} from "react";
import { Button, Typography, Box, FormControl, RadioGroup, FormControlLabel , Radio } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';
import { useNavigate } from 'react-router-dom';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from '../../context/FormContext';

const Occupation: React.FC = () => {
    const { formData, updateFormData } = useForm();    
    const [tradingInvstErr, setTradingInvstErr] =useState<string>() 
    const navigate = useNavigate();
    const goBack = () => {
        navigate('/annual-income')
    }

    const fnContinue = () => { 
        if(!formData?.tradingExperienceDetails.options.find((o) => o.isSelected)) {
            setTradingInvstErr("Please select trading & investment")
            return
        }
        navigate('/dis-depository')
    }

    const handleTradingInvestmentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedqualifiaction = event.target.value;
        if (!formData?.tradingExperienceDetails?.options) {
            return; // Early return to prevent further execution
          }
          setTradingInvstErr("")
        const updatedOptions = formData?.tradingExperienceDetails.options.map((option) =>
          option.answerName === selectedqualifiaction ? { ...option, isSelected: true } : { ...option, isSelected: false }
        );
        updateFormData({ tradingExperienceDetails: { ...formData?.tradingExperienceDetails, options: updatedOptions } });
    };
 
    return (
        <Box sx={{padding:4}}>
            <Box sx={{mb:4}}>
                <Button variant='contained' color='primary' onClick={goBack}>
                <KeyboardBackspaceIcon/>
                </Button>
            </Box>
            <Box sx={{mb: 5}}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{mb: 2}}>
                <Typography variant='h6' >{formData?.tradingExperienceDetails.title}</Typography>
                <Typography variant='subtitle2'>Select below option</Typography>
            </Box>
 
            <Box sx={{mb:4}}>
                {formData?.tradingExperienceDetails ? (
                <FormControl>
               
                <RadioGroup
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    value={formData?.tradingExperienceDetails.options.find((o:any) => o.isSelected)?.answerName}
                    onChange={handleTradingInvestmentChange}
                    name="radio-row-buttons-group"
                >
                    {formData?.tradingExperienceDetails.options.map((trading:any, index:number) => (
                    <FormControlLabel
                    key={trading.answerId}
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        border: '1px solid #f0f0f0',
                        borderRadius: 2,
                        padding: '5px 20px',
                        margin: '2px',
                        '&.Mui-checked': {
                            border: '1px solid #1976d2',
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2',
                        },
                        }}
                    value={trading.answerName}
                    control={<Radio sx={{
                        color: '#1976d2',
                        '&.Mui-checked': {
                            color: '#1976d2',
                        },
                        }}
                        />}
                    label={
                        <span>
                            {trading.answerName}
                        </span>
                    }
                    labelPlacement="start"
                    />
                    ))}
                   
                    </RadioGroup>
                    {tradingInvstErr && (
                <Typography color="error">{tradingInvstErr}</Typography>
                )}
                </FormControl>            
                ) : (
                <p>Loading trading details...</p>
                )}
            </Box>
            <Button variant='contained' fullWidth onClick={fnContinue}>Continue</Button>
 
        </Box>
    )
}
export default Occupation;