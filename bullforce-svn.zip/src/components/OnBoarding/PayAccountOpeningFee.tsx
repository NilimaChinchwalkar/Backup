import React, { useState } from 'react';
import { Button, Box, Typography, Dialog, DialogActions, DialogContent, DialogContentText, RadioGroup, FormControlLabel, Radio, LinearProgress } from '@mui/material';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useNavigate, useLocation } from 'react-router-dom';
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { makeApiRequest } from '../../backendapi/apiutils';  


interface stateOrderType {
    amount: number;
    currency: string;
    orderId: string;
    selectedPlans: any;
}

interface payloadStatus {
    applicationStatus: string;
    message: string;
    success: boolean;
}

interface RazorpayOptions {
    key: string;
    name: string;
    description: string;
    order_id?: string;
    handler: (response: any) => void;
    theme: {
        color: string;
    };
}
// Helper function to validate the payload status response
function isPayloadStatus(response: any): response is payloadStatus {
    return (
        response &&
        typeof response.applicationStatus === 'string' &&
        typeof response.message === 'string' &&
        typeof response.success === 'boolean'
    );
}

const PayAccountOpeningFee: React.FC = () => {
    const navigate = useNavigate();
    const [open, setOpen] = useState<boolean>(false);
    const location = useLocation();
    const state = location.state as stateOrderType | undefined;
    const usersSegmentName = useSelector((state: RootState) => state.payload?.segmentDetailsPayload?.segmentName || []);
    const usersSegmentid = useSelector((state: RootState) => state.payload?.segmentDetailsPayload?.segmentId || []);
    const [apiStatus, setAPIStatusRes] = useState<payloadStatus | null>(null); // Refine type here
    


    const loadRazorpayScript = (): Promise<boolean> => {
        return new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = 'https://checkout.razorpay.com/v1/checkout.js';
            script.onload = () => resolve(true);
            script.onerror = () => resolve(false);
            document.body.appendChild(script);
        });
    };

    const handlePayment = async () => {
        const res = await loadRazorpayScript();
        if (!res) {
            alert('Razorpay SDK failed to load. Please check your internet connection.');
            return;
        }

        const options: RazorpayOptions = {
            key: 'rzp_live_9w9xFvRrpy6wCQ',
            name: 'Bull Force',
            description: 'Test Transaction',
            order_id: state?.orderId,
            handler: (response) => {
                checkSubscriptionStatus();
            },
            theme: {
                color: '#cccc33',
            },
        };

        const paymentObject = new (window as any).Razorpay(options);
        paymentObject.open();
    };

    const checkSubscriptionStatus = async () => {
        try {
            const body = { orderId: state?.orderId };
            
            const response = (await makeApiRequest("getSubscriptionStatus",body)) as any;
            if (isPayloadStatus(response)) {
                setAPIStatusRes(response);
                setOpen(true); // Open dialog if successful
            } else {
                // Handle non-matching response structure with defaults
                setAPIStatusRes({
                    applicationStatus: response.applicationStatus ?? "Failed",
                    message: response.message ?? "Unexpected response structure",
                    success: false,
                } as payloadStatus);
                setOpen(true); // Open dialog if successful
                console.error("Response structure does not match payloadStatus", response);
            }
        } catch (error) {
            console.error("Error checking subscription status:", error);
        }
    };

    const goBack = () => {
        navigate('/subscription-plan', { state: {selectedPlans: state?.selectedPlans} });
    };

    const handleCloseSuccessPopup = () => {
        setOpen(false);
        navigate('/congratulations');
    };
    const handleEdit = () => {
        setOpen(false);        
        navigate('/segment-details', { state: {selectedSegments: usersSegmentid, amount: state?.amount, fromEdit: true} });
    };
    


    return (
        <Box sx={{ padding: 4 }}>
            <Box sx={{ mb: 4 }}>
                <Button variant='contained' color='primary' onClick={goBack}>
                    <KeyboardBackspaceIcon />
                </Button>
            </Box>
            <Box sx={{ mb: 5 }}>
                <LinearProgress color='success' value={8} variant='determinate' />
            </Box>
            <Box textAlign='left' sx={{ mb: 2 }}>
                <Typography variant='h5' sx={{ mb: 2 }}>Pay account opening fee</Typography>
                <Typography variant='body2'>Amount</Typography>
                <Typography variant='h6' sx={{ mb: 2 }}>₹ {state?.amount}</Typography>

                <Typography variant='h6' sx={{ mb: 2 }}> 
                     {/* {matchedSegments.length > 0 
                    ? matchedSegments.map((segment) => segment.name).join(", ") // Join the names with commas
                    : 'No matching segment found'} */}
                     You have selected: {usersSegmentName.join(', ')}
                    
                    <Button variant='text' onClick={handleEdit}>Edit</Button>
                </Typography>
                <Typography variant='body2'>Pay using</Typography>
                <RadioGroup aria-label="plans" value='Razor pay'>
                    <FormControlLabel value='Razor pay' control={<Radio />} label={`Razor pay`} />
                </RadioGroup>
                <Button variant='contained' onClick={handlePayment} sx={{ mt: 2 }} fullWidth>
                    Pay & Continue
                </Button>
            </Box>
            <Box sx={{ mt: 2 }}>
                {open && (
                    <Dialog open={open} onClose={handleCloseSuccessPopup} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                        <DialogContent>
                            <DialogContentText id="alert-dialog-description">
                                <Typography variant='h6'>{apiStatus?.applicationStatus}</Typography>
                                <Typography>{apiStatus?.message}</Typography>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={handleCloseSuccessPopup}>Continue</Button>
                        </DialogActions>
                    </Dialog>
                )}
            </Box>
        </Box>
    );
};

export default PayAccountOpeningFee;
