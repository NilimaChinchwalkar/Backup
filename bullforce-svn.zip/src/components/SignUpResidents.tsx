import React, { useState } from 'react';
import { Card, Typography, TextField, CircularProgress, Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { makeApiRequest } from '../backendapi/ApiService';
import { useDispatch } from 'react-redux';
import { setPayload } from '../store/payloadSlice';

interface Payload {
  userId: number;
  stepId: number;
  token: string;
  refreshToken: string;
}
interface PostData {
  ResidenceStatus: number;
  EmailAddress: string;
  MobileNumber: string;
  ReferralCode: string;
  IsVerified: boolean;
  AllowDublicateMobile: boolean;
}

  const SignUpResidents = () => {
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const[error,setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setEmail(value);

    if (!emailRegex.test(value)) {
      setError('Invalid email address');
    } else {
      setError('');  // Clear the error if valid
    }
  };

  const handleSubmit = async () => {
    if (email && phone) {
      setLoading(true);

      const url = '/api/OnBoarding/register';
      const postData: PostData = {
        ResidenceStatus: 1,
        EmailAddress: email,
        MobileNumber: phone,
        ReferralCode: '',
        IsVerified: false,
        AllowDublicateMobile: false
      };

      const headers = {
        'X-Api-Key': process.env.REACT_APP_AUTH_KEY as string,
      };

      try {
        const result = await makeApiRequest<Payload>(url, 'POST', postData, headers);
        if (result.success && result.payload==null) {
          console.log('Form submitted successfully:', result.payload);
          navigate('/otp-validations', { state: { email, phone } });
        } else if(result.success &&  result.payload !== null){
          const res = result.payload;
          localStorage.setItem('JWT',JSON.stringify(res.token));
          dispatch(setPayload(result.payload));
          navigate('/adhar-details');
          console.log('Payload stored in Redux:', result.payload);
        }
        else {
          console.error('Failed to submit form:', result.message);
        }
      } catch (error) {
        console.error('Error occurred while submitting the form:', error);
      } finally {
        setLoading(false);
      }
    } else {
      alert('Please fill in all required fields.');
    }
  };

  return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
      <Card elevation={10}>
        <Typography variant="h5" align="center" gutterBottom>
          Sign Up Now!! 
        </Typography>

        <TextField
          fullWidth
          label="Enter your Email ID"
          variant="filled"
          value={email}
          onChange={handleEmailChange}
          error={!!error} 
          helperText={error}
        />
        <TextField
          fullWidth
          label="Enter your phone number"
          variant="filled"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          helperText="Make sure this phone number is linked with Aadhar"
        />

        {loading && <CircularProgress color="secondary" />}

        <Button fullWidth variant="contained" onClick={handleSubmit} disabled={loading}>
          Continue
        </Button>
      </Card>
    </Box>
  );
};

export default SignUpResidents;