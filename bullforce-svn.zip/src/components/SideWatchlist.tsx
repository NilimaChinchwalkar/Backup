import React,{useEffect,useState} from "react";
import { makeApiRequest } from "../backendapi/ApiService";
import { ToastContainer,toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";


interface WatchlistItem {
  isDefault: boolean,
  isEditable: boolean,
  watchlistName: string,
};

interface WatchlistDetail {
  symbol: string;
  exchangeInstrumentId: number;
  exchangeSegmentId:number;
  fullName: string;
  exchange: string;
  high:number;
  LTP?:number;
  close?:number;
  exchangeSegment: string;
  percentChange?: string;
  increaseChange?:string;
};
interface BidAsk {
  size: number;
  price: number;
  totalOrders: number;
  buyBackMarketMaker: number;
}

interface StockDetail {
  exchangeSegment: number;
  exchangeInstrumentID: number;
  lastTradedPrice: number;
  close: number;
  bids: BidAsk[];
  asks: BidAsk[];
  high: number;
  low: number;
  open: number;
  percentChange: number;
  totalTradedQuantity: number;
  lastTradedTime: number;
  totalBuyQuantity: number;
  totalSellQuantity: number;
  lastUpdateTime: number;
}
interface SubscriptionResponsePayload {
  stocksDetails: StockDetail[]; // Assuming this is an array of stock details
  xtsCode: number;
  quotesList: any[];
}

interface Payload{
  token:string;
  refreshToken: string;
  socketToken: string;
};

interface PostData{
  userId:string;
  password:string;
  isBiometric:boolean;
};

const SideWatchlist = ()=>{
    const [watchlists,setWatchlists] = useState<WatchlistItem[]>([]);
    const [selectedWatchlist, setSelectedWatchlist] = useState<string | null>(null);
    const [watchlistDetails, setWatchlistDetails] = useState<WatchlistDetail[]>([]);
    const [messages, setMessages] = useState<string[]>([]);
    const [connectionStatus, setConnectionStatus] = useState<string>("Disconnected");
    const [token, setToken] = useState<string | null>(null);
    const [socketToken,setSocketToken]=useState<string | null>(null);
    const [stockDetails, setStockDetails] = useState<StockDetail[]>([]);
    const [currentWatchlist,setCurrentWatchlist] = useState<string | null>(null);
    const [currentSubscription, setCurrentSubscription] = useState<any[]>([]);
    // const token = localStorage.getItem('JWT');

   
  const getValidatePin = async () =>{
    const url = '/api/v1/auth/login';
    const postData: PostData = {
      userId: "TEST013",
      password: "msiG&322",
      isBiometric: true,
     
    };

    const headers = {
      'X-Api-Key': process.env.REACT_APP_AUTH_KEY as string,
    };

    try {
      const authData = await makeApiRequest<Payload>(url,'POST',postData,headers);
       if(authData.success && authData.httpStatusCode==200){
        setToken(authData.payload.token);
        setSocketToken(authData.payload.socketToken);
        await getUserWatchlist(authData.payload.token);
       }
    } catch (error) {
      
    }

  }

const getUserWatchlist = async (token: string | null) =>{

  const url='/api/v1/Trading/watchlist';
  const headers = {
    Authorization: `Bearer ${token}`,
  };
  try {
    const response = await makeApiRequest(url,'GET',null,headers);
    if(response.httpStatusCode==200){
      const watchlistData = response.payload as WatchlistItem[];
      const filteredWatchlists = watchlistData.filter(
        (item: WatchlistItem) => ['NIFTY_50', 'BANK_NIFTY','WTCHLIST1', 'WTCHLIST2'].includes(item.watchlistName))
        .sort((a, b) => {
          if (a.watchlistName === 'NIFTY_50') return -1; // NIFTY_50 comes first
          if (b.watchlistName === 'NIFTY_50') return 1;
          return 0; // Keep the order for other items
        });
      setWatchlists(filteredWatchlists);
    }
    else{
      const msg = response.message;
      toast.error(`Error: ${msg}`, {
        position: "bottom-center",
        autoClose: 5000,  // 5 seconds
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  } catch (error) {
    toast.error('Something went wrong while fetching watchlists', {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      theme: "colored",
    });
  }
}
  

 const fetchWatchlistDetails = async (watchlistName: string) =>{
      const url = `/api/v1/Trading/watchlist/${watchlistName}`;
      const headers = {
        Authorization: `Bearer ${token}`,
      };

      try {
        const listData = await makeApiRequest(url,'GET',null,headers);
        if(listData.httpStatusCode==200){
          const _listDatas = listData.payload as WatchlistDetail[];
           


          if(_listDatas.length==0){
            toast.info(`No records found for ${watchlistName}`, {
              position: "bottom-center",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              theme: "colored",
            });
          }
          else{
            const sortedListDatas = _listDatas.sort((a,b)=>a.symbol.localeCompare(b.symbol));
            setWatchlistDetails(sortedListDatas);

            subscribeToInstruments(sortedListDatas);
          }

          
        }
        else{
          const msg = listData.message;
          toast.error(`Error: ${msg}`, {
        position: "bottom-center",
        autoClose: 5000,  // 5 seconds
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
        }
      } catch (error) {
        toast.error('Something went wrong while fetching watchlists', {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "colored",
        });
      }
    };
     // Subscription and WebSocket worker initialization
  const subscribeToInstruments = async (watchlist: WatchlistDetail[]) => {
    // const jwtToken = localStorage.getItem("SocketToken");
    const url='/api/v1/Trading/Subscription';
    // Subscription Request Body
    const instruments = watchlist.map((detail) => ({
      exchangeSegment: detail.exchangeSegmentId,
      exchangeInstrumentID: detail.exchangeInstrumentId,
    }));
  
    const subscriptionRequestBody = {
      instruments,
      xtsMessageCode: 1502,
    };

    const headers = {
      Authorization: `Bearer ${token}`, // Use the token from authentication
    };

    try {
      const subscriptionResponse = await makeApiRequest(url,'POST',subscriptionRequestBody,headers);
      const subscriptionResponsePayload = subscriptionResponse.payload as SubscriptionResponsePayload;

      if (subscriptionResponsePayload && subscriptionResponsePayload.stocksDetails) {
        const stockDetails = subscriptionResponsePayload.stocksDetails;
    
        console.log("Subscription successful:", stockDetails);
        setCurrentSubscription(instruments);
        setStockDetails(stockDetails);
        if (stockDetails && stockDetails.length > 0) {
          // Update watchlist details based on stockDetails received from the subscription
          setWatchlistDetails((prevDetails) =>
            prevDetails.map((item) => {
              // Find matching stock detail based on exchangeInstrumentID
              const matchingDetail = stockDetails.find(
                (detail) => detail.exchangeInstrumentID === item.exchangeInstrumentId
              );
      
              // If a matching detail is found, update the item fields (LTP, close, etc.)
              if (matchingDetail) {
                const lastTradedPrice = matchingDetail.lastTradedPrice;
                const close = matchingDetail.close;
      
                return {
                  ...item,
                  LTP: lastTradedPrice ?? item.LTP, // Update LTP if available
                  close: close ?? item.close, // Update close if available
                  percentChange: (((lastTradedPrice - close) * 100) / close).toFixed(2),
                  increaseChange: (lastTradedPrice - close).toFixed(2),
                };
              }
      
              // If no match is found, return the item as is
              return item;
            })
          );
        }

        // setWatchlistDetails((prev)=>
        //   prev.map((details)=>
        //   details.exchangeInstrumentID == stockDetails
        // ?
        //   )
        // );

        initializeWebSocketWorker();
      }


      else {
        console.error('Subscription failed:', subscriptionResponse.message);
      }
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.error("Axios network error:", error.message);
      } else {
        console.error("Unexpected error:", error);
      }
    }
      

      // Initialize the WebSocket worker
     
  };
  const unsubscribeFromInstruments = async (instruments: any[]) => {
    if (!instruments || instruments.length === 0) return;
  
    const url = '/api/v1/Trading/Subscription'; // Assuming there's an API endpoint for unsubscribing
    const requestBody = {
      instruments,
      xtsMessageCode: 1502,  // Assuming it's the same message code for unsubscription
    };
  
    const headers = {
      Authorization: `Bearer ${token}`,
    };
  
    try {
      await makeApiRequest(url, 'PUT', requestBody, headers);
      console.log('Unsubscription successful:', instruments);
    } catch (error) {
      console.error('Failed to unsubscribe:', error);
    }
  };
  
  const initializeWebSocketWorker = () =>{
    const worker = new Worker(
      new URL("../workers/EnterpriseSocketWorker.ts", import.meta.url),
      { type: "module" }
    );
  
    worker.onmessage = (event) => {
      const { type, message } = event.data;
  
      switch (type) {
        case "connect":
          setConnectionStatus("Connected");
          setMessages((prevMessages) => [...prevMessages, message]);
  
          // Subscribe to instrument data
          worker.postMessage({
            action: "subscribe",
            payload: { xtsMessageCode: 1502 },
          });
          break;
  
        case "joined":
          setMessages((prevMessages) => [...prevMessages, `Joined: ${message}`]);
          break;
  
        case "data":
          if (message.MessageCode === 1502) {
            const lastTradedPrice = message.LastTradedPrice || message.Touchline?.LastTradedPrice;
            const exchangeInstrumentID = message.ExchangeInstrumentID;
            const pClose = message.Close || message.Touchline?.Close;
  
            if (lastTradedPrice && exchangeInstrumentID && pClose) {
              const percentage = (((lastTradedPrice - pClose) * 100) / pClose).toFixed(2);
              const increaseBy = (lastTradedPrice - pClose).toFixed(2);
  
              setWatchlistDetails((prevDetails) =>
                prevDetails.map((detail) =>
                  detail.exchangeInstrumentId === exchangeInstrumentID
                    ? { ...detail, LTP: lastTradedPrice, percentChange: percentage, increaseChange: increaseBy }
                    : detail
                )
              );
            }
          }
  
          setMessages((prevMessages) => [...prevMessages, `1502 Data: ${JSON.stringify(message)}`]);
          break;
  
        case "disconnect":
          setConnectionStatus("Disconnected");
          setMessages((prevMessages) => [...prevMessages, message]);
          break;
  
        case "error":
          setMessages((prevMessages) => [...prevMessages, message]);
          break;
  
        default:
          console.log(`Unknown event type: ${type}`);
      }
    };
  
    // Connect WebSocket
    worker.postMessage({
      token: socketToken,
      userID: "TEST003", // Replace with actual userID
      action: "connect",
    });
  
    // Clean up on component unmount
    return () => {
      worker.postMessage({ action: "disconnect" });
      worker.terminate();
    };
  };
  const handleWatchlistClick = async (watchlistName: string) => {
    if (currentWatchlist === watchlistName) return;

    // Unsubscribe from current instruments if any
    if (currentSubscription.length > 0) {
      await unsubscribeFromInstruments(currentSubscription);
    }
   setCurrentWatchlist(watchlistName);
   setSelectedWatchlist(watchlistName);
   fetchWatchlistDetails(watchlistName); // Call the API to fetch details for the clicked watchlist
  //  subscribeToInstruments();
 };

    useEffect(()=>{
      let isMounted = true;
      if(isMounted){
        getValidatePin();
      }
      return () => {
        isMounted = false; // Cleanup function to prevent repeated calls
      };
    
    },[]);

   

    return (
      <div>
      {/* Watchlist tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        {watchlists.map((watchlist) => (
          <button
            key={watchlist.watchlistName}
            onClick={() => handleWatchlistClick(watchlist.watchlistName)}
            style={{
              padding: '10px',
              background: selectedWatchlist === watchlist.watchlistName ? 'lightblue' : 'white',
              border: '1px solid gray',
              cursor: 'pointer',
            }}
          >
            {watchlist.watchlistName}
          </button>
        ))}
      </div>

      {/* Display the watchlist details if available */}
      {watchlistDetails?.map((details)=>(
 <div key={details.exchangeInstrumentId}>
  
 <p>Full Name: {details.symbol}</p>
 <p>Tag: {details.exchange}</p>
 <p>LTP: 
 <span 
    style={{ color: Number(details?.increaseChange) >= 0 ? 'green' : 'red' }}
  >
    {details.LTP} | {details.increaseChange} ({details.percentChange}%)
  </span>
 </p>
 {/* Add more details as needed */}
</div>
      ))}
       
     
    </div>
        
    );
}

export default SideWatchlist;