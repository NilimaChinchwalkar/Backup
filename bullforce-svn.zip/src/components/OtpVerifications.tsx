import React, { useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, Card, Typography, TextField, Button, CircularProgress } from '@mui/material';
import { makeApiRequest } from '../backendapi/ApiService';



interface LocationState {
    email: string;
    phone: string;
  }

  interface Payload {
    userId: number;
    stepId: number;
    token: string;
    refreshToken: string;
  }
  
  const OtpVerifications = () => {
    const location = useLocation();
    const state = location.state as LocationState | undefined;
    const { email, phone } = state || {};
   
    const [emailOtp, setEmailOtp] = useState<string[]>(['', '', '', '']);
    const [phoneOtp, setPhoneOtp] = useState<string[]>(['', '', '', '']);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>(''); 
    const navigate = useNavigate();
  
    const emailOtpRefs = [
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
    ];
    const phoneOtpRefs = [
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
      useRef<HTMLInputElement>(null),
    ];
  
    const handleOtpChange = async (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
        index: number,
        type: 'email' | 'phone'
      ) => {
        const value = e.target.value;
        if (!/^\d*$/.test(value)) return; // Ensure only digits are entered
      
        if (type === 'email') {
          const updatedOtp = [...emailOtp];
          updatedOtp[index] = value;
          setEmailOtp(updatedOtp);
      
          if (value && index < emailOtpRefs.length - 1) {
            emailOtpRefs[index + 1].current?.focus();
          }
          if (index === 3 && value) {
            await verifyEmailOtp(updatedOtp.join(''));
          }
        } else if (type === 'phone') {
          const updatedOtp = [...phoneOtp];
          updatedOtp[index] = value;
          setPhoneOtp(updatedOtp);
      
          if (value && index < phoneOtpRefs.length - 1) {
            phoneOtpRefs[index + 1].current?.focus();
          }
          if (index === 3 && value) {
            await verifyPhoneOtp(updatedOtp.join(''));
          }
        }
      };
      
  
    const verifyEmailOtp = async (otp: string) => {
      const url = '/api/OnBoarding/VarifyEmailOTP';
      const postData = { email, otp };
  
      const headers = {
        "X-Api-Key": process.env.REACT_APP_AUTH_KEY as string
      };
  
      try {
        setLoading(true);
        const response = await makeApiRequest(url, 'POST', postData, headers);
        if (!response.success) {
          setError('Email OTP verification failed.');
        }
      } catch (err) {
        setError('Error during Email OTP verification.');
      } finally {
        setLoading(false);
      }
    };
  
    const verifyPhoneOtp = async (otp: string) => {
      const url = '/api/OnBoarding/VarifyMobileOTP';
      const postData = {
        userId: 0,
        mobileNo: phone,
        otp
      };
  
      const headers = {
        "X-Api-Key": process.env.REACT_APP_AUTH_KEY as string
      };
  
      try {
        setLoading(true);
        const response = await makeApiRequest(url, 'POST', postData, headers);
        if (!response.success) {
          setError('Phone OTP verification failed.');
        }
      } catch (err) {
        setError('Error during Phone OTP verification.');
      } finally {
        setLoading(false);
      }
    };
  
    const handleSubmit = async () => {
      const url = '/api/OnBoarding/register';
      const postData = {
        "ResidenceStatus": 1,
        "EmailAddress": email,
        "MobileNumber": phone,
        "ReferralCode": "",
        "IsVerified": true, 
        "AllowDublicateMobile": false
      };
  
      const headers = {
        "X-Api-Key": process.env.REACT_APP_AUTH_KEY as string
      };
  
      try {
        setLoading(true);
        const response = await makeApiRequest<Payload>(url, 'POST', postData, headers);
        if (response.success) {
          alert('Registration successful!');
          localStorage.setItem('JWT',JSON.stringify(response.payload.token))
          navigate('/adhar-details');
        } else {
          setError('Registration failed.');
        }
      } catch (err) {
        setError('Error during registration.');
      } finally {
        setLoading(false);
      }
    };
  
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh" bgcolor="#000">
        <Card elevation={10} sx={{ padding: 4, backgroundColor: '#071B2F', color: '#fff', width: 350 }}>
          <Typography variant="h5" align="center" gutterBottom>
            Please enter OTP
          </Typography>
  
          <Typography align="center">
            Please provide us the OTP sent to your Email ID
            <br />
            {email} <Button color="secondary" variant="text">Edit</Button>
          </Typography>
  
          <Box display="flex" justifyContent="center" marginBottom={2}>
            {emailOtp.map((digit, index) => (
              <TextField
                key={index}
                value={digit}
                onChange={(e) => handleOtpChange(e, index, 'email')}
                inputRef={emailOtpRefs[index]}
                variant="filled"
                inputProps={{ maxLength: 1, style: { textAlign: 'center', color: '#fff' } }}
                sx={{ width: 40, margin: 1, backgroundColor: '#0A2540' }}
              />
            ))}
          </Box>
  
          <Typography align="center">
            Please provide us the OTP sent to your Phone Number
            <br />
            +91 {phone} <Button color="secondary" variant="text">Edit</Button>
          </Typography>
  
          <Box display="flex" justifyContent="center" marginBottom={2}>
            {phoneOtp.map((digit, index) => (
              <TextField
                key={index}
                value={digit}
                onChange={(e) => handleOtpChange(e, index, 'phone')}
                inputRef={phoneOtpRefs[index]}
                variant="filled"
                inputProps={{ maxLength: 1, style: { textAlign: 'center', color: '#fff' } }}
                sx={{ width: 40, margin: 1, backgroundColor: '#0A2540' }}
              />
            ))}
          </Box>
  
          {loading ? (
            <Box display="flex" justifyContent="center" marginBottom={2}>
              <CircularProgress color="secondary" />
            </Box>
          ) : (
            <Button fullWidth variant="contained" onClick={handleSubmit} sx={{ backgroundColor: '#FFD700', color: '#000', marginTop: 2 }}>
              Submit
            </Button>
          )}
  
          {error && (
            <Typography color="error" align="center" marginTop={2}>
              {error}
            </Typography>
          )}
        </Card>
      </Box>
    );
  }

  export default OtpVerifications;