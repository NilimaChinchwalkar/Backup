import { io } from 'socket.io-client';

let socket;

self.onmessage = (event) => {
  console.log('Worker received message:', event.data); // Log to confirm reception
  const { token, userID, action, payload } = event.data;
  console.log('Connecting to WebSocket at URL:', `http://103.177.180.205:10151/enterprise/socket.io`);
  
  if (action === 'connect') {
    // Establish a new socket connection
    socket = io(`http://103.177.180.205:10151/enterprise/socket.io`, {
      query: {
        token: token,
        userID: userID,
        apiType: 'Enterprise',
      },
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 5000,
      timeout: 20000,
    });
    console.log('Socket initialized:', socket);
    // Listen for socket events and forward them to the main thread
    socket.on('connect', () => {
      console.log('Socket connected'); // Log connection status
      self.postMessage({ type: 'connect', message: 'Socket connected successfully' });
    });
    socket.on('connecting', () => {
        console.log('Socket is attempting to connect...');
      });
  
      socket.on('connect_error', (err) => {
        console.error('Socket connection error:', err);
        self.postMessage({ type: 'error', message: `Socket connection error: ${err.message}` });
      });
  
      socket.on('connect_timeout', () => {
        console.log('Socket connection timed out');
        self.postMessage({ type: 'error', message: 'Socket connection timed out' });
      });
    socket.on('joined', (data) => {
      console.log('Joined event:', data); // Log joined events
      self.postMessage({ type: 'joined', message: data });

      // Once joined, subscribe to the instruments
      if (payload) {
        socket.emit('1502-json-full', payload);
      }
    });

    socket.on('data', (data) => {
      console.log('Data received:', data); // Log incoming data
      self.postMessage({ type: 'data', message: data });
    });

    socket.on('error', (err) => {
      console.error('Socket error:', err); // Log errors
      self.postMessage({ type: 'error', message: err });
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected'); // Log disconnection
      self.postMessage({ type: 'disconnect', message: 'Socket disconnected' });
    });
  }

  if (action === 'subscribe') {
    if (socket && socket.connected && payload) {
      console.log('Subscribing to instruments:', payload); // Log subscription details
      socket.emit('1502-json-full', payload);
    }
  }

  if (action === 'disconnect') {
    if (socket) {
      console.log('Disconnecting socket'); // Log disconnect action
      socket.disconnect();
    }
  }
};
