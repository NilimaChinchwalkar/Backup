self.onmessage = (event) => {
    console.log("Worker received:", event.data);
    self.postMessage(`Hello from worker: ${event.data}`);
  };
  