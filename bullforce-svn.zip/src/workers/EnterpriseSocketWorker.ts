import io from 'socket.io-client';

let socket: any;

self.onmessage = (event) => {
  console.log('Worker received message:', event.data); // Log to confirm reception
  const { token, userID,action,payload } = event.data;
  console.log('Connecting to WebSocket at URL:', `http://103.177.180.205:10151/enterprise/socket.io`);
  if (action === 'connect') {
    // Establish a new socket connection //ws://103.177.180.205:10151/apimarketdata/socket.io/
    socket = io(`ws://103.177.180.205:10151`, {
      path: '/apimarketdata/socket.io',
      query: {
        token,
        userID,
        publishFormat: 'JSON',
        broadcastMode: 'Full',
      },
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 5000,
      timeout: 20000,
      forceNew: true,
      upgrade: false,
     
    });

    console.log('Socket initialized:', socket);
    // Listen for socket events and forward them to the main thread
    socket.on('connect', () => {
      console.log('Socket connected'); // Log connection status
      self.postMessage({ type: 'connect', message: 'Socket connected successfully' });
    });

    socket.on('connecting', () => {
        console.log('Socket is attempting to connect...');
      });
  
      socket.on('connect_error', (err:any) => {
        console.error('Socket connection error:', err);
        self.postMessage({ type: 'error', message: `Socket connection error: ${err.message}` });
      });
  
      socket.on('connect_timeout', () => {
        console.log('Socket connection timed out');
        self.postMessage({ type: 'error', message: 'Socket connection timed out' });
      });
      socket.on('joined', (data: any) => {
        console.log('Joined event received:', data);
        // Emit subscription request for "1502-json-full" after joining
        if (payload) {
          socket.emit('1502-json-full', JSON.stringify(payload));
        }
      });

    // socket.on('data', (data: any) => {
    //   // console.log('Data received:', data); // Log incoming data
    //   // self.postMessage({ type: 'data', message: data });
    //   console.log('Data received:', data);
    //   try {
    //     const eventName = data[0]; // e.g., "1502-json-full"
    //     const parsedData = JSON.parse(data[1]); // Second element contains actual data

    //     if (eventName === "1502-json-full") {
    //       // Log and post each tick data from 1502
    //       console.log('1502 Data received:', parsedData);
    //       self.postMessage({ type: 'data', message: parsedData });
    //     }
    //   } catch (error) {
    //     console.error('Error parsing incoming data:', error);
    //   }
    //   // try {
    //   //   // The first element is the event name, the second is the actual data
    //   //   const eventName = data[0];
    //   //   const eventData = data[1];  // This should be JSON string
        
    //   //   // Handle "joined" event
    //   //   if (eventName === "joined") {
    //   //     const parsedData = JSON.parse(eventData);
    //   //     console.log('Joined event received:', parsedData);
    //   //     self.postMessage({ type: 'joined', message: parsedData });
    //   //   }

    //   //   // Handle "1502-json-full" event
    //   //   if (eventName === "1502-json-full") {
    //   //     const parsedData = JSON.parse(eventData);
    //   //     if (parsedData.xtsMessageCode === 1502) {
    //   //       console.log('1502 Data received:', parsedData);
    //   //       self.postMessage({ type: 'data', message: parsedData });
    //   //     }
    //   //   }
    //   // } catch (error) {
    //   //   console.error('Error parsing incoming data:', error);
    //   // }
     
    // });

    socket.on('1502-json-full', (data: any) => {
      try {
        const parsedData = JSON.parse(data);
        // console.log('Parsed 1502-json-full data:', parsedData);
        self.postMessage({ type: 'data', message: parsedData });
      } catch (error) {
        console.error('Error parsing 1502 data:', error);
      }
    });
    // socket.on('data', (data:any) => {
    //   try {
    //     const eventName = data[0];
    //     const payload  = data[1];
    //     const parsedData = JSON.parse(payload);
    //     // Handle 1502-json-full data
    //     if (eventName === '1502-json-full') {
    //       console.log('1502 Data:', parsedData);
    //       self.postMessage({ type: 'data', message: parsedData }); // Send parsed data
    //     }

    //     // Handle 1105-json-partial data
    //     // if (eventName === '1105-json-partial') {
    //     //   const parsedPartialData = JSON.parse(payload);
    //     //   self.postMessage({ type: 'partial-data', message: parsedPartialData });
    //     // }
    //   } catch (error) {
    //     console.error('Error parsing WebSocket data:', error);
    //   }
    // });

    socket.on('error', (err: any) => {
      console.error('Socket error:', err); // Log errors
      globalThis.postMessage({ type: 'error', message: err });
    });

    socket.on('disconnect', (reason: any) => {
      console.log('Socket disconnected'); // Log disconnection
      console.log(reason);
      globalThis.postMessage({ type: 'disconnect', message: 'Socket disconnected' });
    });
  }

  if (action === 'subscribe') {
    if (socket && socket.connected && payload) {
      console.log('Subscribing to instruments:', payload); // Log subscription details
      socket.emit('1502-json-full', payload);
    }
  }

  if (action === 'disconnect') {
    if (socket) {
      console.log('Disconnecting socket'); // Log disconnect action
      socket.disconnect();
    }
  }
};
