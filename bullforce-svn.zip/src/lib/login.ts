import { z } from "zod";

export const loginSchema = z.object({
  UserID: z
    .string({ required_error: "UserID is required", message: "UserID is required" }),
  Password: z.string().min(8, {message: "Password must be at least 8 characters"})
});

export type LoginFormInputs = z.infer<typeof loginSchema>;
