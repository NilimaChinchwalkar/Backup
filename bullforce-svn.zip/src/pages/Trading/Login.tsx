import React from "react";
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  TextField,
  Typography,
} from "@mui/material";
import { VisibilityOffOutlined, VisibilityOutlined } from "@mui/icons-material";
import { FormProvider, useForm } from "react-hook-form";
import { LoginFormInputs, loginSchema } from "../../lib/login";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useNavigate } from "react-router-dom";
import logo from "../../assets/images/logo.png";
import { makeApiRequest } from "../../backendapi/ApiService";
import { useAppDispatch } from "../../store/hooks";
import { loginResponse } from "../../store/LoginSlice";

interface Payload {
    token: string,
    refreshToken: string,
    socketToken: string
}

const Login = () => {
  const [showPassword, setShowPassword] = React.useState(false);

  const methods = useForm<LoginFormInputs>({
    resolver: zodResolver(loginSchema),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = methods;

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event: React.MouseEvent) => {
    event.preventDefault();
  };

  const submitData = async (data: LoginFormInputs) => {
    const headers = {
      'X-Api-Key': process.env.REACT_APP_XAPI_KEY as string
    };
    const userData = {
      ...data,
      isBiometric: true
    };

    try {
      const response = await makeApiRequest<Payload>("/api/v1/auth/login", "POST", userData, headers)
      if(response.success) {
        dispatch(loginResponse(response.payload))
        navigate("/watchlist");
      } else {
        console.log(response.httpStatusCode)
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      bgcolor="#011222"
      minHeight="100vh"
    >
      <Box
        display="flex"
        p="24px"
        bgcolor="#162334"
        color="white"
        my="48px"
        border="1px solid #1d324c"
        width="100%"
        borderRadius={{ md: "24px" }}
        maxWidth={{
          xs: "100%",
          md: "384px",
          lg: "448px",
          xl: "512px",
          "2xl": "576px",
        }}
      >
        <FormProvider {...methods}>
          <Box
            component="form"
            onSubmit={handleSubmit(submitData)}
            display="flex"
            flexDirection="column"
            justifyContent="center"
            textAlign="center"
            width="100%"
            my="16px"
            sx={{
              gap: {
                xs: 2,
                "2xl": 3,
              },
            }}
          >
            <Link to="/" style={{ margin: "0 auto ", marginBottom: "32px" }}>
              <img src={logo} alt="bullforce-logo" />
            </Link>
            <Typography
              variant="h2"
              mb={3}
              textAlign="center"
              fontWeight="600"
              sx={{
                fontSize: {
                  xs: 24,
                  lg: 28,
                },
              }}
            >
              Login
            </Typography>
            <TextField
              type="text"
              label="Enter User ID"
              fullWidth
              variant="outlined"
              size="small"
              {...register("UserID")}
              error={!!errors.UserID}
              helperText={errors.UserID?.message}
              sx={{
                "& .MuiOutlinedInput-root": {
                  backgroundColor: "#0c1622",
                },
                "& .MuiInputBase-root": {
                  color: "white",
                },
                "& .MuiFormLabel-root": {
                  color: "#9ca3af",
                  fontSize: 16,
                },
              }}
            />
            <Box>
              <FormControl fullWidth variant="outlined">
                <InputLabel
                  size="small"
                  htmlFor="outlined-adornment-password"
                  sx={{ color: "#9ca3af" }}
                >
                  Enter Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={showPassword ? "text" : "password"}
                  size="small"
                  label="Enter Password"
                  {...register("Password")}
                  error={!!errors.Password}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                        size="small"
                        sx={{
                          color: "#9ca3af",
                        }}
                      >
                        {showPassword ? (
                          <VisibilityOffOutlined fontSize="inherit" />
                        ) : (
                          <VisibilityOutlined fontSize="inherit" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  sx={{
                    bgcolor: "#0c1622",
                    color: "white",
                  }}
                />
                <FormHelperText error>
                  {errors.Password?.message}
                </FormHelperText>
              </FormControl>
              <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                mt="4px"
              >
                <Link
                  to=""
                  style={{
                    color: "#9ca3af",
                    fontSize: "14px",
                    textDecoration: "none",
                  }}
                >
                  Forgot Password?
                </Link>
                <Link
                  to=""
                  style={{
                    color: "#9ca3af",
                    fontSize: "14px",
                    textDecoration: "none",
                  }}
                >
                  Unblock User
                </Link>
              </Box>
            </Box>
            <Button
              variant="contained"
              fullWidth
              type="submit"
              size="large"
              sx={{
                textTransform: "capitalize",
                fontWeight: 600,
                borderRadius: "4px",
                "&:hover": {
                  bgcolor: "#c2a02f",
                },
              }}
            >
              Validate
            </Button>
          </Box>
        </FormProvider>
      </Box>
    </Box>
  );
};

export default Login;
