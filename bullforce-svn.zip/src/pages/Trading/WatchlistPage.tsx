import { WatchlistProvider } from '../../context/WatchlistContext'
import { useAppSelector } from '../../store/hooks';
import Watchlist from './Watchlist';

const WatchlistPage = () => {
    const { token, socketToken } = useAppSelector((state) => state.login.loginData);

  return (
    <WatchlistProvider token={token} socketToken={socketToken}>
        <Watchlist />
    </WatchlistProvider>
  )
}

export default WatchlistPage