import React from "react";
import { Box } from "@mui/material";
import { useAppSelector } from "../../store/hooks";
import { WatchlistDetail } from "../../types/watchlist.types";
import { makeApiRequest } from "../../backendapi/ApiService";
import WatchlistHeader from "../../components/Trading/Watchlist/WatchlistHeader";
import WatchlistContent from "../../components/Trading/Watchlist/WatchlistContent";
import { useWatchlistContext } from "../../context/WatchlistContext";

const Watchlist = () => {
  const {
    watchlists,
    getUserWatchlist,
    getIndices,
    fetchWatchlistDetails,
    currentSubscription,
    unsubscribeFromInstruments,
  } = useWatchlistContext();

  const { token } = useAppSelector((state) => state.login.loginData)

  const [activeTab, setActiveTab] = React.useState<number>(0);
  const [activeWatchlistIndex, setActiveWatchlistIndex] =
    React.useState<number>(0);
  const [currentWatchlist, setCurrentWatchlist] = React.useState<string | null>(
    null
  );
  const [addModalOpen, setAddModalOpen] = React.useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = React.useState(false);
  const [selectedStock, setSelectedStock] = React.useState<WatchlistDetail[]>(
    []
  );
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);

  // Handle Add Modal
  const handleAddModalOpen = () => setAddModalOpen(true);
  const handleAddModalClose = () => setAddModalOpen(false);

  const handleAddWatchlist = async (watchlistName?: string) => {
    try {
      const headers = {
        accept: "*/*",
        contentType: "application/json",
        Authorization: `Bearer ${token}`,
      };
      const response = await makeApiRequest(
        `/api/v1/Trading/watchlist/${watchlistName}`,
        "POST",
        null,
        headers
      );
      if (response.status) {
        console.log(response.payload);
        fetchWatchlistDetails(activeWatchlistIndex);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setAddModalOpen(false);
    }
  };

  // Handle Delete Modal

  const handleDeleteModalOpen = (stock: WatchlistDetail[]) => {
    setSelectedStock(stock);
    setDeleteModalOpen(true);
  };

  const handleDeleteModalClose = () => setDeleteModalOpen(false);

  const handleDeleteStock = async () => {
    if (!selectedStock) return;
    try {
      const headers = {
        accept: "*/*",
        contentType: "application/json",
        Authorization: `Bearer ${token}`,
      };
      const body = selectedStock.map((stock) => ({
        exchangeInstrumentID: stock.exchangeInstrumentId,
        exchangeSegment: stock.exchangeSegmentId,
      }));
      const response = await makeApiRequest(
        `/api/v1/Trading/watchlist/${watchlists[activeWatchlistIndex]?.watchlistName}`,
        "DELETE",
        body,
        headers
      );

      if (response.status) fetchWatchlistDetails(activeWatchlistIndex);
    } catch (error) {
      console.error(error);
    } finally {
      setDeleteModalOpen(false);
      setSelectedStock([]);
    }
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => setActiveTab(newValue);

  const handleWatchlistTabChange = (
    event: React.SyntheticEvent,
    newIndex: number
  ) => {
    setActiveWatchlistIndex(newIndex);
  };

  const handleWatchlistClick = async (watchlistName: string) => {
    if (currentWatchlist === watchlistName) return;

    // Unsubscribe from current instruments if any
    if (currentSubscription.length > 0) {
      await unsubscribeFromInstruments(currentSubscription);
    }
    setCurrentWatchlist(watchlistName);
    const updatedWatchlistIndex = watchlists.findIndex(
      (watchlist) => watchlist.watchlistName === watchlistName
    );
    fetchWatchlistDetails(updatedWatchlistIndex);
  };
  
  React.useEffect(() => {
    getUserWatchlist();
    getIndices();
  }, []);
  
  React.useEffect(() => {
    fetchWatchlistDetails(activeWatchlistIndex);
  }, [activeWatchlistIndex, watchlists]);

  return (
    <Box
      display={{ md: "flex" }}
      justifyContent="center"
      bgcolor="#011222"
      minHeight="100vh"
    >
      <Box
        bgcolor="#162334"
        padding="24px"
        color="white"
        marginY="48px"
        width="100%"
        border="1px solid #1d324c"
        borderRadius="24px"
        sx={{ maxWidth: "448px" }}
      >
        <WatchlistHeader
          isSearchOpen={isSearchOpen}
          setIsSearchOpen={setIsSearchOpen}
          activeTab={activeTab}
          handleTabChange={handleTabChange}
        />

        {/* Child Tabs Of Equity */}
        <WatchlistContent
          activeTab={activeTab}
          activeWatchlistIndex={activeWatchlistIndex}
          addModalOpen={addModalOpen}
          deleteModalOpen={deleteModalOpen}
          handleWatchlistTabChange={handleWatchlistTabChange}
          handleWatchlistClick={handleWatchlistClick}
          handleAddWatchlist={handleAddWatchlist}
          handleDeleteStock={handleDeleteStock}
          handleAddModalOpen={handleAddModalOpen}
          handleDeleteModalOpen={handleDeleteModalOpen}
          handleAddModalClose={handleAddModalClose}
          handleDeleteModalClose={handleDeleteModalClose}
          selectedStock={selectedStock}
          setIsSearchOpen={setIsSearchOpen}
        />
      </Box>
    </Box>
  );
};

export default Watchlist;