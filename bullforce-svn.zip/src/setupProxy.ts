import { Application } from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';

module.exports = function (app: Application) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://219.91.228.145:8084',
      changeOrigin: true,
    })
  );
};
