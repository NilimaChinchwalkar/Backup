import { Method } from "axios";
import axiosInstance from "./axiosInstance"
 
export const makeApiRequest = async (
    url: string,
    method: Method,
    data?: any,
    headers?: Record<string, string>
) => {
    try {
        const response = await axiosInstance({
            url,
            method,
            data, // Request body (for GET, POST, PUT, DELETE)
            headers //Dynamic headers
            
        });
        return response.data
    } catch (error) {
        console.log("API call failed: ", error);
    }
}