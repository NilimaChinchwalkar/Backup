const { override } = require('customize-cra');
const Dotenv = require('dotenv-webpack');

module.exports = override((config) => {
  config.plugins = [
    ...config.plugins,
    new Dotenv({
      path: '.env.development', // Path to your environment file
    }),
  ];

  return config;
});
